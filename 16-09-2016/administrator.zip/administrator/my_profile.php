<?php
include_once '../db.php';

include_once 'header.php';
?>
<div class="main-content" autoscroll="true" bs-affix-target="" init-ripples="" style="">

 	<section class="forms-basic">
        <div class="page-header">
              <h1><i class="md md-input"></i>My Profile</h1>
        </div>
        
        <div class="well white">
            <form method='post' enctype="multipart/form-data" class="form-floating">
                <fieldset>
                    <div class="form-group">
                        <label class="control-label">User Name </label>
                        <input type="text" data-error="This field is user Name " name='user_name' required class="form-control" value="">
                        <div class="help-block with-errors"></div>
                    </div>
                    <div class="form-group">
                        <label class="control-label">Email Id </label>
                        <input type="text" data-error="This field is email" name='email' required class="form-control" value="">
                        <div class="help-block with-errors"></div>
                    </div>
                    <div class="form-group">
                        <label class="control-label">Mobile number </label>
                        <input type="text" data-error="This field is mobile " name='mobile' required class="form-control" value="">
                        <div class="help-block with-errors"></div>
                    </div>
                    <div class="form-group">
                         <label>Gender</label>
                    <div class="radio">
                        <div class="col-md-6">
                          <label>
                            <input type="radio" name="Gender" id="optionsRadios1" value="option1"> male </label>
                        </div>
                        <div class="col-md-6">
                          <label>
                            <input type="radio" name="Gender" id="optionsRadios1" value="option1"> Female </label>
                        </div>
                        </div>
                    </div>
                    <div class="col-md-12">
                <div class="form-group">
                  <button type="submit" class="btn btn-primary" name="btn-save">
    		<span class="glyphicon glyphicon-floppy-disk"></span> Save	</button>  
        <button type="submit" class="btn btn-info" name="">
    		 Cancel	</button> 
              </div>
            </div>
                 
                </fieldset>
            </form>
    
        </div>
        
    </section>
</div>