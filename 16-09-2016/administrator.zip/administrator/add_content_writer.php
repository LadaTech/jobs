<?php
include_once '../db.php';


include_once 'content_writer_model.php';

$content_writer = new content_writer($db);

if(isset($_POST['btn-save']))
{
	$First_name = $_POST['First_name'];
	$Last_name = $_POST['Last_name'];
	$Email_id = $_POST['Email_id'];
	$User_name = $_POST['User_name'];
	$Password = $_POST['Password'];
	$Confirm_password = $_POST['Confirm_password'];
	$Gender = $_POST['Gender'];
	$Alternate_email = $_POST['Alternate_email'];
	$Phone_No = $_POST['Phone_No'];
	$Address = $_POST['Address'];
	$Experience = $_POST['Experience'];
	$Domain = $_POST['Domain'];
	$Profile_summary = $_POST['Profile_summary'];
	$usertype_id = $_POST['usertype_id'];
	 // $imgFile = $_FILES['user_image']['name'];
  // $tmp_dir = $_FILES['user_image']['tmp_name'];
  // $imgSize = $_FILES['user_image']['size'];
  // $upload_dir = 'images/'; // upload directory
        
         $folder = "images/"; 
    $file = basename( $_FILES['image']['name']); 
    $full_path = $folder.$file; 
	$img = move_uploaded_file($_FILES['image']['tmp_name'], $full_path);
	//if(move_uploaded_file($_FILES['image']['tmp_name'], $full_path)) { 
	if($content_writer->create($First_name,$Last_name,$Email_id,$User_name,$Password,$Confirm_password,$Gender,$Alternate_email,$Phone_No,$Address,$Experience,$Domain,$Profile_summary,$usertype_id,$full_path))
	{
		
		header("Location: content_writer_master.php?inserted");
		
		//echo "Welcome To Content Writer Page";
	}
	else
	{
		header("Location: content_writer_master.php?failure");
	}
	//}
}
?>
    <?php include_once 'header.php'; ?>
        <div class="clearfix"></div>

        <div class="main-content" autoscroll="true" bs-affix-target="" init-ripples="" style="">

            <section class="forms-basic">
                <div class="page-header">
                    <h1>      <i class="md md-input"></i>      Create Contentwriter    </h1>
                </div>
                <div class="well white">
                    <form method='post' enctype="multipart/form-data" class="form-floating">

                        <div class="row">
                            <div class="col-md-6">

                                <fieldset>
                                    <div class="form-group">
                                        <label class="control-label">First Name </label>
                                        <input type="text" data-error="This field is First Name " name='First_name' required class="form-control" value="">
                                        <div class="help-block with-errors"></div>
                                    </div>
                                    <div class="form-group">
                                        <label class="control-label">Mobile Number </label>
                                        <input type="text" data-error="That email address is invalid" name='Phone_No' required class="form-control" value="">
                                        <div class="help-block with-errors"></div>
                                    </div>
                                    <div class="form-group">
                                        <label class="control-label">user name </label>
                                        <input type="text" data-error="This field is required" name='User_name' required class="form-control" value="">
                                        <div class="help-block with-errors"></div>
                                    </div>
                                    <div class="form-group">
                                        <label class="control-label">password </label>
                                        <input type="password" data-error="This field is required" name='Password' required class="form-control" value="">
                                        <div class="help-block with-errors"></div>
                                    </div>
                                    <div class="form-group">
                                        <label>Gender</label>
                                        <div class="radio">
                                            <label>
                                                <input type="radio" name="Gender" id="optionsRadios1" value="option1"> male </label>

                                            <label>
                                                <input type="radio" name="Gender" id="optionsRadios1" value="option1"> Female </label>
                                        </div>

                                    </div>
                                    <div class="form-group">
                                        <label class="control-label">Domain </label>
                                        <input type="text" data-error="This field is required" name='Domain' required class="form-control" value="">
                                        <div class="help-block with-errors"></div>
                                    </div>
                                    <div class="form-group">
                                        <label class="control-label">Address</label>
                                        <textarea id="textArea" rows="1" name='Address' class="form-control vertical"></textarea>
                                        <div class="help-block with-errors"></div>
                                    </div>
                                </fieldset>

                            </div>
                            <div class="col-md-6">

                                <fieldset>
                                    <div class="form-group">
                                        <label class="control-label">Last Name </label>
                                        <input type="text" data-error="This field is First Name " name='Last_name' required class="form-control">
                                        <div class="help-block with-errors"></div>
                                    </div>
                                    <div class="form-group">
                                        <label class="control-label">Email ID </label>
                                        <input type="email" data-error="That email address is invalid" name='Email_id' required class="form-control">
                                        <div class="help-block with-errors"></div>
                                    </div>
                                    <div class="form-group">
                                        <label class="control-label">Email ID (Alternate) </label>
                                        <input type="password" data-error="This field is required" name='Alternate_email' required class="form-control">
                                        <div class="help-block with-errors"></div>
                                    </div>
                                    <div class="form-group">
                                        <label class="control-label">Confirm password </label>
                                        <input type="password" data-error="This field is required" name='Confirm_password' required class="form-control" value="">
                                        <div class="help-block with-errors"></div>
                                    </div>
                                    <div class="form-group">
                                        <label>Gender</label>
                                        <br />
                                        <span class="btn btn-info fileinput-button">                <span>Upload profile pic</span>
                                        <input type="file" name="image" accept="image/*" multiple="" class="fileupload">
                                        <div class="ripple-wrapper"></div>
                                        </span>
                                    </div>
                                    <div class="form-group">
                                        <select class="form-control" name='Experience' data-error="This field is required" required>
                                            <option value="">Experience</option>
                                            <option value="">1 year</option>

                                        </select>
                                        <div class="help-block with-errors"></div>
                                    </div>
                                    <div class="form-group">
                                        <label class="control-label">Profile_summary</label>
                                        <textarea id="textArea" rows="1" name='Profile_summary' class="form-control vertical"></textarea>
                                        <div class="help-block with-errors"></div>
                                    </div>
                                </fieldset>

                            </div>


                            <div class="col-md-12">
                                <div class="form-group">
                                    <button type="submit" class="btn btn-primary" name="btn-save">
                                        <span class="glyphicon glyphicon-plus"></span> Submit </button>
                                    <a href="content_writer_master.php" class="btn btn-large btn-success"><i class="glyphicon glyphicon-backward"></i> &nbsp; Back</a>

                                </div>
                            </div>

                        </div>



                    </form>
                </div>
            </section>
        </div>
