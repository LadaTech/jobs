<?php
include_once '../db.php';

include_once 'content_writer_model.php';

$content_writer = new content_writer($db);

include_once 'header.php';
?>
    <div class="main-content" autoscroll="true" bs-affix-target="" init-ripples="" style="">

        <section class="forms-basic">
            <div class="page-header">
                <h1>      <i class="md md-input"></i>  jobseeker Enquiry Details  </h1>
            </div>
            <div class="well white">
                <?php 
                     $n = htmlspecialchars($_GET["n"]);
                    $stmtjs=$db->prepare("SELECT * FROM js_enquiries WHERE js_enquiry_id='".$n."'");

                    $stmtjs->execute();

                    $js=$stmtjs->fetch(PDO::FETCH_ASSOC);
                    $c_id=$js['js_content_writer_id'];
                    $stmtcw=$db->prepare("SELECT * FROM content_writer WHERE Content_writer_id='".$c_id."'");

                    $stmtcw->execute();

                    $cw=$stmtcw->fetch(PDO::FETCH_ASSOC);
                
                $update = $db->prepare("update js_enquiry_detail set is_read_ad=0 where is_read_ad=1 and js_enquiry_id='".$n."'");
                $update->execute();
                       
                    ?>
                    <div class="list-group">
                        <a href="#" class="list-group-item active">
                            <h4 class="list-group-item-heading"><?php echo $js['js_jobseeker_name']; ?></h4>
                            <p class="list-group-item-text">
                                <?php  echo $js['js_message']; ?>
                            </p>
                        </a>
                        <?php
                            $stmt=$db->prepare("SELECT * FROM js_enquiry_detail WHERE js_enquiry_id='".$n."'");
                                $stmt->execute(); if ($stmt->rowCount() > 0): while($row=$stmt->fetch(PDO::FETCH_ASSOC)): if($row['js_sender']== $js['js_job_seeker_id']): ?>

                            <a href="#" class="list-group-item">
                                <h4 class="list-group-item-heading"><?php echo $js['js_jobseeker_name']; ?></h4>
                                <p class="list-group-item-text">
                                    <?php  echo $row['js_message'] ?>
                                </p>
                            </a>
                            <?php else:  ?>
                                <a href="#" class="list-group-item">
                                    <h4 class="list-group-item-heading"><?php echo $cw['Email_id']; ?></h4>
                                    <p class="list-group-item-text">
                                        <?php  echo $row['js_message'] ?>
                                    </p>
                                </a>
                                <?php endif; endwhile; endif; ?>
                    </div>
            </div>
        </section>
    </div>
