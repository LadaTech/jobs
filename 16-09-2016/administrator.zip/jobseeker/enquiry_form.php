<?php 

include_once '../db.php';

ob_start(); 

include_once 'jobseeker_model.php';

$jobseeker = new jobseeker($db); 

?>

    <section class="colors">
        <div class="container-fluid">
            <div class="p-10 clearfix">
                <h4 class="grey-text"> <i class="md md-dashboard"></i> <span class="hidden-xs">Job Seeker Dashboard</span> </h4>
            </div>
            <div class="col-md-3">
                <div class="card">
                    <div style="  padding: 10px; ">
                        <div class="row">
                            <div class="col-md-6">
                                <p>Fresher</p>
                                <a href="#"> <img style=" width:100%; height: 150px; border: 1px #ccc solid; " src="assets/img/T1.png"> </a>
                            </div>
                            <div class="col-md-6">
                                <p>Experience</p>
                                <a href="#"> <img style=" width:100%; height: 150px; border: 1px #ccc solid; " src="assets/img/T2.png"> </a>
                            </div>
                        </div>
                    </div>
                    <div style="  padding: 10px; ">
                        <div class="row">
                            <div class="col-md-6">
                                <p>Fresher</p>
                                <a href="#"> <img style=" width:100%; height: 150px; border: 1px #ccc solid; " src="assets/img/T1.png"> </a>
                            </div>
                            <div class="col-md-6">
                                <p>Experience</p>
                                <a href="#"> <img style=" width:100%; height: 150px; border: 1px #ccc solid; " src="assets/img/T2.png"> </a>
                            </div>
                        </div>
                    </div>
                    <div style="  padding: 10px; ">
                        <div class="row">
                            <div class="col-md-6">
                                <a href="#"> <img style=" width:100%; height: 150px; border: 1px #ccc solid; " src="assets/img/T1.png"> </a>
                            </div>
                            <div class="col-md-6">
                                <a href="#"> <img style=" width:100%; height: 150px; border: 1px #ccc solid; " src="assets/img/T2.png"> </a>
                            </div>
                        </div>
                    </div>
                    <div style="  padding: 10px; ">
                        <div class="row">
                            <div class="col-md-6">
                                <a href="#"> <img style=" width:100%; height: 150px; border: 1px #ccc solid; " src="assets/img/T1.png"> </a>
                            </div>
                            <div class="col-md-6">
                                <a href="#"> <img style=" width:100%; height: 150px; border: 1px #ccc solid; " src="assets/img/T2.png"> </a>
                            </div>
                        </div>
                    </div>
                    <div style="  padding: 10px; ">
                        <div class="row">
                            <div class="col-md-6">
                                <a href="#"> <img style=" width:100%; height: 150px; border: 1px #ccc solid; " src="assets/img/T1.png"> </a>
                            </div>
                            <div class="col-md-6">
                                <a href="#"> <img style=" width:100%; height: 150px; border: 1px #ccc solid; " src="assets/img/T2.png"> </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="well white">
                            <?php
	 
                            if(isset($_POST['enq_frm']))
                            {

                            $js_email_id = $_POST['js_email_id'];	
                            $js_id = $_POST['js_id'];
                            $js_name = $_POST['js_name'];
                            $CW_ID = $_POST['CW_ID'];
                            $js_subject = $_POST['js_subject'];	
                            $js_message = $_POST['js_message'];

                            if($jobseeker->send_quiries($js_email_id, $js_id, $js_name, $CW_ID, $js_subject, $js_message))
                            {		//echo("add");
                                $msg = "<div class='alert alert-info'>
                                        your <strong>Query</strong>  successfully sent to Content Writer !
                                        </div>";	

                            }
                            else
                            {
                                $msg = "<div class='alert alert-warning'>
                                        <strong>SORRY!</strong> ERROR while inserting record !
                                        </div>";
                            }


                        }
                        $stmtje=$db->prepare("SELECT * FROM job_seeker WHERE Job_Seeker_Id ='".$_SESSION['Job_Seeker_Id']."'");

                        $stmtje->execute();

                        $js=$stmtje->fetch(PDO::FETCH_ASSOC);


                                // parse_str(urldecode($_SERVER['QUERY_STRING']));

                                 $n = htmlspecialchars($_GET["n"]);


                        //echo $email = $js['Email_id']; 


                        ?>
                                <form method="post" name="enq_frm" class="form-floating">
                                    <fieldset>
                                        <div class="">
                                            <?php
                                            if(isset($msg))
                                            {
                                                echo $msg;
                                            }   

                                            ?>
                                        </div>
                                        <div class="clearfix"></div>
                                        <div class="form-group">
                                            <label for="inputEmail" class="control-label">Email</label>
                                            <input type="text" name="js_email_id" value="<?php echo $js['Email_id']; ?>" readonly class="form-control"> </div>
                                        <div class="form-group">
                                            <label for="inputSubject" class="control-label">subject</label>
                                            <input type="text" name="js_subject" required value="" class="form-control" id="inputSubject">

                                            <input type="hidden" name="js_id" value="<?php echo $js['Job_Seeker_Id']; ?>" class="form-control" id="inputSubject">
                                            <input type="hidden" name="js_name" value="<?php echo $js['User_name']; ?>" class="form-control" id="inputSubject">
                                            <input type="hidden" name="CW_ID" value="<?php echo $n; ?>" class="form-control" id="inputSubject"> </div>


                                        <div class="form-group">
                                            <label for="textArea" class="control-label">Query</label>
                                            <textarea name="js_message" value="" required class="form-control vertical" rows="3" id="textArea"></textarea>
                                        </div>

                                        <div class="form-group">
                                            <button type="submit" name="enq_frm" class="btn btn-primary">Submit</button>
                                            <button type="reset" class="btn btn-default">Cancel</button>
                                        </div>
                                    </fieldset>
                                </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card">
                    <div class="card-header relative">
                        <div class="card-title"> Content Writers</div>
                    </div>
                    <div class="list-group">
                        <?php

                        // Retrieve the URL variables (using PHP).
   
		

                        $stmtje=$db->prepare("SELECT * FROM content_writer LIMIT 4");

                        $stmtje->execute();
                        //	$i=1;
                        while($row=$stmtje->fetch(PDO::FETCH_ASSOC))
                                    {
                        ?>
                            <form method="post">

                                <div class="list-group-item clearfix" href="#">
                                    <div class="pull-left m-r-10"> <img src="../administrator/<?php echo $row['Profile_picture_path']; ?>" class="img-responsive" style="  border-radius: 50%; "> </div>
                                    <div class="list-group-item-heading">
                                        <?php echo $row['User_name']; ?>
                                    </div>
                                    <span class="list-group-item-text">
                                    <p><?php echo $row['Profile_summary']; ?></p>
                                    </span>
                                    <div class="row">
                                        <div class="col-md-3">
                                            <p>Rating</p>
                                        </div>
                                        <div class="col-md-9"> <a href="#"><i class="md md-star-rate"></i></a> <a href="#"><i class="md md-star-rate"></i></a> <a href="#"><i class="md md-star-rate"></i></a> <a href="#"><i class="md md-star-rate"></i></a> <a href="#"><i class="md md-star-rate"></i></a> </div>
                                        <div class="pull-right"> <a title="" data-toggle="tooltip" class="btn btn-round-sm btn-link" target="_blank" href="pages-material-bird.html" data-original-title="Order now"><i class="fa fa-shopping-cart" aria-hidden="true"></i>
            <div class="ripple-wrapper"></div>
            </a>
                                            <a title="" data-toggle="tooltip" class="btn btn-round-sm btn-link" href="jobseeker.php?type=ef&n=<?php echo $row['Content_writer_id']; ?>" data-original-title="Send an enquiry">
                                                <i class="fa fa-paper-plane" aria-hidden="true"></i>
                                                <?php $_SESSION['CW_ID']=$row['Content_writer_id']; ?>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </form>
                            <?php   
                             } ?>

                    </div>
                </div>
            </div>
        </div>
    </section>
