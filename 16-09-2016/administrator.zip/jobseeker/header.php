<!DOCTYPE html>
<?php ob_start(); ?>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Resume Services</title>


    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>  <script src="//oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>  <script src="//oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>  <![endif]-->
    <link href="assets/css/vendors.min.css" rel="stylesheet">
    <link href="assets/css/styles.min.css" rel="stylesheet">
    <script charset="utf-8" src="//maps.google.com/maps/api/js?sensor=true"></script>
    <style type="text/css">
        .full {
            width: 100% !important;
        }
        
        .circle-mask {
            background-image: url(assets/img/icon_user.png);
            background-repeat: no-repeat;
            background-size: 96px auto;
            border-radius: 50%;
            display: block;
            height: 96px;
            margin-bottom: 10px;
            margin-left: auto;
            margin-right: auto;
            overflow: hidden;
            transition: opacity 0.075s ease 0s;
            width: 96px;
            z-index: 100;
        }
        
        #canvas {
            opacity: 0.01;
            transition: opacity 0.075s ease 0s;
        }
        
        .circle {
            background-position: center center;
            background-repeat: no-repeat;
            border-radius: 50%;
            height: 96px;
            opacity: 0.99;
            overflow: hidden;
            position: absolute;
            width: 96px;
            z-index: 101;
        }
        
        .header {
            background: #7ed1f6;
            width: 100%;
            border-bottom: 1px solid #001291;
        }
        
        h1 {
            font-size: 21px !important;
            padding-top: 10px !important;
            margin-top: 0PX !important;
        }
        
        .footer {
            position: fixed;
            bottom: 0px;
            left: 0px;
            background: #f4f4f4 none repeat scroll 0 0;
            border-top: 1px solid #cccccc;
            line-height: 25px;
            padding: 0 20px;
            width: 100%;
        }
        
        .card .card-header {
            padding: 10px !important;
        }
        
        .nav {
            width: 100%;
            float: left;
            margin: 0px;
            padding: 0px;
        }
        
        .nav li {
            float: left;
            list-style-type: none;
        }
        
        .nav li a {
            color: #000000;
        }
        
        .nav li a:hover {
            color: #020170;
        }

    </style>

</head>

<body init-ripples="">


    <?php
    include_once '../db.php';

    include_once 'jobseeker_model.php';

    $jobseeker = new jobseeker($db);
    session_start();

	$query = "SELECT * FROM job_seeker where Job_Seeker_Id='".$_SESSION['Job_Seeker_Id']."'";       
	
	//$jobseeker->dataview($query);
		
	$stmt = $db->prepare($query);
		
	$stmt->execute();
	
	//$stmt->rowCount();		
			
	$row=$stmt->fetch(PDO::FETCH_ASSOC);
		
	?>


        <?php  $stmt = $db->prepare('SELECT * FROM js_enquiries where is_read_js=1 and js_job_seeker_id="'.$_SESSION['Job_Seeker_Id'].'"'); $stmt->execute(); $ad=$stmt->fetch(PDO::FETCH_ASSOC); ?>






            <div class="container-fluid header">
                <div class="navbar-header pull-left">
                    <h1>Resume Services</h1>
                </div>
                <div class="pull-right">
                    <ul class="nav">
                        <li class="active"><a href="jobseeker.php?type=home">Dashboard</a></li>
                        <li><a href="jobseeker.php?type=res_tem">Resume Templates</a></li>
                        <li><a href="jobseeker.php?type=cwl">Get Resumes by Our Expert’s</a></li>
                        <li><a href="jobseeker.php?type=my_resumes">My Resume’s </a></li>
                        <li><a href="jobseeker.php?type=not">Notifications(<?php echo $stmt->rowCount(); ?>) </a></li>
                        <li id="profile-messages" class="dropdown">
                            <a class="dropdown-toggle" data-target="#profile-messages" data-toggle="dropdown" href="#" title="">
                                <div class="pull-left m-r-10"> <img style="  border-radius: 50%; width: 30px; height: 30px; " class="img-responsive" src="assets/img/icon_user.png"> </div> <span class="text">My Account </span><b class="caret"></b></a>
                            <ul class="dropdown-menu">
                                <li><a href="jobseeker.php?type=edit_profile"><i class="icon-user"></i> Edit Profile</a></li>
                                <li class="divider"></li>
                                <li><a href="jobseeker.php?type=change_password"><i class="icon-check"></i> Change Password</a></li>
                                <li class="divider"></li>
                                <li><a href="jobseeker.php?type=my_orders"><i class="icon-check"></i> My Orders </a></li>
                                <li class="divider"></li>
                                <li><a href="jobseeker.php?type=logout"><i class="icon-key"></i>Logout</a></li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
            <script charset="utf-8" src="assets/js/vendors.min.js"></script>
            <script charset="utf-8" src="assets/js/app.min.js"></script>
</body>

</html>
