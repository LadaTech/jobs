<?php
include_once '../db.php';

include_once 'jobseeker_model.php';

$jobseeker = new jobseeker($db);

?>
<?php include_once 'header.php'; ?>

<div class="clearfix"></div>

<div class="container">

		
</div>


<?php 
	$stmtjs=$db->prepare("SELECT * FROM job_seeker WHERE Job_Seeker_Id='".$_SESSION['Job_Seeker_Id']."'");
	
	$stmtjs->execute();
	
	$js=$stmtjs->fetch(PDO::FETCH_ASSOC);
	
	
		
	?>
<div class="clearfix"></div><br />

<div class="container">
	 
     <form method=''>
 
    <table class=''>
 
        
            First Name :
            <?php echo $js['First_name']; ?><br/>
       
            Last Name
            <?php echo $js['Last_name']; ?><br/>
        
 
        
            E-mail ID :<?php echo $js['Email_id']; ?>
        <br/>
            User name :<?php echo $js['User_name']; ?>
        <br/>
 
        
           
 		
            Contact No :<?php echo $js['Phone_No']; ?>
        
 		<br/>
            Experience_level :
			 <?php echo $js['Experience_level']; ?> 
   <br/>
        
 		
            Domain
             <?php echo $js['Domain']; ?>"
        
 
        
            
        
 
    </table>
</form>
     
     
</div>

<?php include_once 'footer.php'; ?>