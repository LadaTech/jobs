<!DOCTYPE html>

<?php ob_start(); ?>

<?php error_reporting(0); 
//include 'header.php'; ?>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="">
<meta name="author" content="">
<title>Resume Services</title>
<script src="assets/jquery-1.11.3.min.js"></script>
<script src="assets/woco.accordion.min.js"></script>
<link href="assets/woco-accordion.css" rel="stylesheet"><style>
.accordion { width: 100%; margin: 10px; float: left; }

@media (max-width: 350px) {
.accordion { width: 100%; }
}
h2 { text-align: center; margin-bottom: 0px; color: white; line-height: 2em; font-weight: 100; font-family: monospace; }
h3 { color: green; font-weight: 105; padding-top: 10px; margin-bottom: 0px; clear: both; }
hr { border: none; border-bottom: 1px solid green; }
code { display: block; margin: 5px 0px; padding: 0px 20px; font-size: 15px; color: gray; border-left: 3px solid green; background-color: rgba(248, 248, 248, 0.5); }
.dark-blue { color: #069; font-weight: bold; }
.string { color: blue; }
#intro { padding: 5px 10px; line-height: 1.4em; }
ul { -webkit-padding-start: 0px; -moz-padding-start: 0px; -khtml-padding-start: 0px; -o-padding-start: 0px; padding-start: 0px; }
ul code { padding-left: 40px; }
ul ul code { padding-left: 80px; }
.button { display: inline-block; border: 1px solid black; margin-right: 5px; padding: 5px; border-radius: 5px; text-decoration: none; background-color: rgb(240,240,240); color: black; box-shadow: -1px -1px 1px 0px black; }
.button:visited { color: black; }
.button:hover { box-shadow: -1px -1px 3px 1px black; }
a, a:visited { color: blue; }
</style>
<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!--[if lt IE 9]>  <script src="//oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>  <script src="//oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>  <![endif]-->

<style type="text/css">
.full { width: 100% !important; }
.circle-mask { background-image: url(assets/img/icon_user.png); background-repeat: no-repeat; background-size: 96px auto; border-radius: 50%; display: block; height: 96px; margin-bottom: 10px; margin-left: auto; margin-right: auto; overflow: hidden; transition: opacity 0.075s ease 0s; width: 96px; z-index: 100; }
#canvas { opacity: 0.01; transition: opacity 0.075s ease 0s; }
.circle { background-position: center center; background-repeat: no-repeat; border-radius: 50%; height: 96px; opacity: 0.99; overflow: hidden; position: absolute; width: 96px; z-index: 101; }
.header { background: #7ed1f6; width: 100%; border-bottom: 1px solid #001291; }
h1 { font-size: 21px !important; padding-top: 10px !important; margin-top: 0PX !important; }
.footer { position: fixed; bottom: 0px; left: 0px; background: #f4f4f4 none repeat scroll 0 0; border-top: 1px solid #cccccc; line-height: 25px; padding: 0 20px; width: 100%; }
.card .card-header { padding: 10px !important; }
.nav { width: 100%; float: left; margin: 0px; padding: 0px; }
.nav li { float: left; list-style-type: none; }
.nav li a { color: #000000; }
.nav li a:hover { color: #020170; }
</style>
<script type="text/javascript">
$(".accordion").accordion();

$(".accordion").accordion({

    //whether the first section is expanded or not
    firstChildExpand: true,
    //whether expanding mulitple section is allowed or not
    multiExpand: false,
    //slide animation speed
    slideSpeed: 500,
    //drop down icon
    dropDownIcon: "&#9660",

});
$(document).ready(function() {
//////////////////language////////////////////////////////////////
$('#add_lan').click(function() {
 $('#lan_row').before('<div id="details" class="col-md-12"><h5> Language Name</h5><div class="col-md-8"><div class="form-group"><input type="password" data-error="This field is required" required class="form-control"></div><div class="form-group "><label class="control-label">Beginner</label><select data-error="This field is required" required class="form-control"><option value=""> </option><option value="Select a pirate">Intermediate Level </option><option value="Expert">Expert </option><option value="Roronoa Zoro">Professional </option></select><div class="help-block with-errors"></div></div></div><div class="col-md-4"><div class="form-group"><div class="checkbox"><label><input type="checkbox" required>Read </label></div><div class="checkbox"><label><input type="checkbox" required>Write </label></div><div class="checkbox"><label><input type="checkbox" required>Speak </label></div></div></div></div>'); // Add new one below
});

$('#delete_lan').click(function() {
 $('#details').remove();
});
/////////////////////////education//////////////////////////////
$('#add_education').click(function() {
	 $('#edu_row').before('<div id="edu_details"><form name="edu_sub" id="form-validation" action="" method="post" class="form-floating" novalidate=""><div class="col-md-12"><div class="form-group"><label class="control-label">Choose Education</label><select class="form-control" name="profficiency_level" value=""><option value=""></option><option value="Post Graduation">Ph.D</option><option value="Post Graduation">Post Graduation</option><option value="Graduation">Graduation</option> <option value="Diploma">Diploma</option><option  value="Intermediate">Intermediate</option><option value="SSC">SSC</option> </select><div class="help-block with-errors"></div></div></div><div class="col-md-6"><fieldset><div class="form-group"><label class="control-label">Course</label><input data-error="This field is First Name " name="js_course" class="form-control" value="" type="text"><div class="help-block with-errors"></div></div><div class="form-group"><label class="control-label">Start Year </label><input name="js_start_date" class="form-control" value="" data-error="That email address is invalid" required="" type="date"><div class="help-block with-errors"></div></div><div class="form-group"> <label class="control-label">% or CGPA </label><input name="js_percentage" class="form-control" value="" type="text"> <div class="help-block with-errors"></div></div></fieldset></div><div class="col-md-6"> <fieldset><div class="form-group"><label class="control-label">Institute Name </label><input data-error="This field is First Name " required="" name="js_institution_name" class="form-control" value="" "="" type="text"><div class="help-block with-errors"></div><div class="form-group"><label class="control-label">End Year</label><input name="js_end_date" class="form-control" value="" data-error="That email address is invalid" required="" type="date"><div class="help-block with-errors"></div></div></div></fieldset></div></form></div>'); // Add new one below
});

$('#del_education').click(function() {
 $('#edu_details').remove();
});
 
 /////////////////////////////////////////////////////////////////
 ///////////////////////experience/////////////////////////////////
 $('#add_experiance').click(function() {
	 $('#exp_row').before('<div id="exp_details"><form id="form-validation" name="exp_sub" action="" method="post" class="form-floating" novalidate=""><div class="col-md-6"><fieldset><div class="form-group"><label class="control-label">Company Name</label><input data-error="This field is First Name " name="Company_Name" class="form-control" value="" type="text"><div class="help-block with-errors"></div></div><div class="form-group"><label class="control-label">Designation </label><input name="Designation" class="form-control" value="" data-error="That email address is invalid" required="" type="text"><div class="help-block with-errors"></div></div><div class="form-group"><label class="control-label">Start date </label><input name="Start_date" class="form-control" value="" type="date"><div class="help-block with-errors"></div></div></fieldset></div><div class="col-md-6"><fieldset><div class="form-group"><label class="control-label">Current CTC</label><input name="Current_CTC" class="form-control" value="" data-error="That email address is invalid" required="" type="text"><div class="help-block with-errors"></div></div> <div class="form-group"><label class="control-label">Expected CTC</label><input name="Expected_CTC" class="form-control" value="" data-error="That email address is invalid" required="" type="text"><div class="help-block with-errors"></div></div><div class="form-group"><label class="control-label">End date</label><input name="End_date" class="form-control" value="" data-error="That email address is invalid" required="" type="date"><div class="help-block with-errors"></div></div></fieldset></div></div></form></div>'); // Add new one below
});

$('#del_experiance').click(function() {
 $('#exp_details').remove();
});
 //////////////////////////////////////////////////////////////////
 });
</script>
</head>
<body init-ripples="">

<section class="colors">
<div class="container-fluid">
<div class="p-10 clearfix">
  <h4 class="grey-text"> <i class="md md-dashboard"></i> <span class="hidden-xs">Job Seeker Dashboard</span> </h4>
</div>
<div class="col-md-3">
  <div class="card">
    <div style="  padding: 10px; ">
      <div class="row">
        <div class="col-md-6">
          <p>Fresher</p>
          <a href="#"> <img style=" width:100%; height: 150px; border: 1px #ccc solid; " src="assets/img/T1.png"> </a> </div>
        <div class="col-md-6">
          <p>Experience</p>
          <a href="#"> <img style=" width:100%; height: 150px; border: 1px #ccc solid; " src="assets/img/T2.png"> </a> </div>
      </div>
    </div>
    <div style="  padding: 10px; ">
      <div class="row">
        <div class="col-md-6">
          <p>Fresher</p>
          <a href="#"> <img style=" width:100%; height: 150px; border: 1px #ccc solid; " src="assets/img/T1.png"> </a> </div>
        <div class="col-md-6">
          <p>Experience</p>
          <a href="#"> <img style=" width:100%; height: 150px; border: 1px #ccc solid; " src="assets/img/T2.png"> </a> </div>
      </div>
    </div>
    <div style="  padding: 10px; ">
      <div class="row">
        <div class="col-md-6"> <a href="#"> <img style=" width:100%; height: 150px; border: 1px #ccc solid; " src="assets/img/T1.png"> </a> </div>
        <div class="col-md-6"> <a href="#"> <img style=" width:100%; height: 150px; border: 1px #ccc solid; " src="assets/img/T2.png"> </a> </div>
      </div>
    </div>
    <div style="  padding: 10px; ">
      <div class="row">
        <div class="col-md-6"> <a href="#"> <img style=" width:100%; height: 150px; border: 1px #ccc solid; " src="assets/img/T1.png"> </a> </div>
        <div class="col-md-6"> <a href="#"> <img style=" width:100%; height: 150px; border: 1px #ccc solid; " src="assets/img/T2.png"> </a> </div>
      </div>
    </div>
    <div style="  padding: 10px; ">
      <div class="row">
        <div class="col-md-6"> <a href="#"> <img style=" width:100%; height: 150px; border: 1px #ccc solid; " src="assets/img/T1.png"> </a> </div>
        <div class="col-md-6"> <a href="#"> <img style=" width:100%; height: 150px; border: 1px #ccc solid; " src="assets/img/T2.png"> </a> </div>
      </div>
    </div>
  </div>
</div>
<div class="col-md-6">
  <div class="row">
    <div class="col-sm-12">
      <div class="accordion">
        <h1 style="padding:0px !important; margin:0px !important; "><i class="fa fa-user" aria-hidden="true"></i>
 Personal Details</h1>
<?php 
 if(isset($_POST['pd_sub']))
{
	$id = $_SESSION['Job_Seeker_Id'];
		
	$Alternate_email = $_POST['Alternate_email'];
	$Alternate_Phone_no = $_POST['Alternate_Phone_no'];
	$Address = $_POST['Address'];
	$Father_Name = $_POST['Father_Name'];
	
	
	$language_name = $_POST['language_name'];
	$profficiency_level = $_POST['profficiency_level'];
	$read = $_POST['read1'];
	$write = $_POST['write2'];
	$speak = $_POST['speak3'];
	
	if($jobseeker->profile_update($id,$Alternate_email,$Alternate_Phone_no,$Address,$Father_Name,$language_name,$profficiency_level,$read,$write,$speak))	
	{		
	
		 $msg = "<div class='alert alert-warning'>
				<strong>your Personal Details Inserted Sucessfully...</strong>
				</div>";
				
	
	}
	else
	{
			$msg = "<div class='alert alert-warning'>
				<strong>your Personal Details Inserted Sucessfully...</strong>
				</div>";	
	
	}
}

	$stmtjs=$db->prepare("SELECT * FROM job_seeker WHERE Job_Seeker_Id='".$_SESSION['Job_Seeker_Id']."'");
	
	$stmtjs->execute();
	
	$js=$stmtjs->fetch(PDO::FETCH_ASSOC);
		
	?>

        <div>
          <div class="row">
		   <form id="form-validation" name="pd_sub" method="post" action="" class="form-floating" novalidate>
            <div class="col-md-6">
             
                <fieldset>
                  <div class="form-group">
                    <label class="control-label">First Name </label>
                    <input type="text" data-error="This field is First Name " name='First_name' class='form-control' readonly value="<?php echo $js['First_name']; ?>" >
                    <div class="help-block with-errors"></div>
                  </div>
                  <div class="form-group">
                    <label class="control-label">Mobile Number </label>
                    <input type="text" data-error="That email address is invalid" required name='Phone_No' class='form-control' readonly value="<?php echo $js['Phone_No']; ?>">
                    <div class="help-block with-errors"></div>
                  </div>
                  <div class="form-group">
                    <label class="control-label">Mobile Number (Alternate) </label>
                    <input type="text" data-error="This field is required" name='Alternate_Phone_no' class='form-control' value="<?php echo $js['Alternate_Phone_no']; ?>" required>
                    <div class="help-block with-errors"></div>
                  </div>
                  <div class="form-group">
                    <label class="control-label">Father Name </label>
                    <input type='text' name='Father_Name' data-error="This field is required" class='form-control' value="<?php echo $js['Father_Name']; ?>" required>
                    <div class="help-block with-errors"></div>
                  </div>
                </fieldset>
             
            </div>
            <div class="col-md-6">
              
                <fieldset>
                  <div class="form-group">
                    <label class="control-label">Last Name </label>
                    <input type="text" data-error="This field is First Name " name='Last_name' class='form-control' readonly value="<?php echo $js['Last_name']; ?>">
                    <div class="help-block with-errors"></div>
                  </div>
                  <div class="form-group">
                    <label class="control-label">Email ID </label>
                    <input type="email" data-error="That email address is invalid" required name='Email_id' class='form-control' readonly value="<?php echo $js['Email_id']; ?>">
                    <div class="help-block with-errors"></div>
                  </div>
                  <div class="form-group">
                    <label class="control-label">Email ID (Alternate) </label>
                    <input type='email' name='Alternate_email' class='form-control' value="<?php echo $js['Alternate_email']; ?>"  data-error="This field is required" >
                    <div class="help-block with-errors"></div>
                  </div>
                  <div class="form-group">
                    <label class="control-label">Address</label>
					<textarea class='form-control vertical' id="textArea" rows="1" name="Address"><?php echo $js['Address']; ?>	</textarea>                  
                    <div class="help-block with-errors"></div>
                  </div>
                </fieldset>
             
            </div>
			
            <div class="col-md-12">
              <h5> Language Name </h5>
              <div class="col-md-8">
                <div class="form-group">
                  <input type="text" name="language_name" data-error="This field is required" value="<?php echo $js['language_name']; ?>" required class="form-control">
                </div>
                <div class="form-group ">
                  <label class="control-label">profficiency level</label> 
                  <select data-error="This field is required" required name="profficiency_level" class="form-control">
                    <option value="<?php echo $js['profficiency_level']; ?>"><?php echo $js['profficiency_level']; ?></option>
					<option value="Beginner">Beginner</option>
					<option value="Intermediate">Intermediate</option>
					<option value="Expert">Expert</option>
					<option value="Profossional">Profossional</option>
                  </select>
                  <div class="help-block with-errors"></div>
                </div>
              </div>
              <div class="col-md-4">
                <div class="form-group">
                  <div class="checkbox">
                    <label>
                      <input type="checkbox" name="read1" value="R" <?php if($js['lan_read']=="R") { echo "checked"; } s?> >
                      Read </label>
                  </div>
                  <div class="checkbox">
                    <label>
                      <input type="checkbox" name="write2" value="W" <?php if($js['lan_write']=="W") { echo "checked"; } ?> >
                      Write </label>
                  </div>
                  <div class="checkbox">
                    <label>
                      <input type="checkbox" name="speak3" value="S" <?php if($js['lan_speak']=="S") { echo "checked"; } ?> >
                      Speak </label>
                  </div>
                </div>
              </div>
            <div class="" id='lan_row'>
                    <div data-toggle="tooltip" data-title="Add Language" class="btn btn-primary btn-round btn-lg" data-original-title="" title=""  id="add_lan"><i class="md md-add"></i>
                      <div class="ripple-wrapper"></div>
                    </div>
                    <div id='delete_lan' data-toggle="tooltip" data-title="Delete" class="btn btn-primary btn-round btn-lg m-r-10 " data-original-title="" title=""><i class="md md-delete"></i></div>
                  </div>
			</div>
            <div class="col-md-12">
            <div class="form-group">
              <button class="btn btn-primary" href="" name="pd_sub" type="submit">Save
              <div class="ripple-wrapper"></div>
              </button>
              <button class="btn btn-default" type="reset">Cancel</button>
            </div>
          </div>
           
			</form>
          </div>
        </div>
    
	<h1 style="padding:0px !important; margin:0px !important; "> <i class="fa fa-book" aria-hidden="true"></i>
 Educational Details</h1>



 
 <?php // Educational information php functionality....
 
$stmtje=$db->prepare("SELECT * FROM js_educational_information");
	
$stmtje->execute();
	
$row_js=$stmtje->fetch(PDO::FETCH_ASSOC);

$row = $row_js['js_educational_information_id'];
 
if(empty($row)){
if(isset($_POST['edu_sub']))
{
	$id = $_SESSION['Job_Seeker_Id'];
		
	$js_qualification_name = $_POST['profficiency_level'];
	$js_course = $_POST['js_course'];
	$js_institution_name = $_POST['js_institution_name'];
	//$js_education_location = $_POST['js_education_location'];
	$js_start_date = $_POST['js_start_date'];
	$js_end_date = $_POST['js_end_date'];
	$js_percentage = $_POST['js_percentage'];
	//$js_university = $_POST['js_university'];
	if($jobseeker->Eduction_profile($id, $js_qualification_name, $js_course, $js_institution_name, $js_start_date,$js_end_date, $js_percentage))
	
	{		header("Location: jobseeker.php?type=home");		
	
	}
	else
	{
		$msg = "<div class='alert alert-warning'>
				<strong>SORRY!</strong> ERROR while inserted record !
				</div>";
	}
}

}
else {
 if(isset($_POST['edu_sub']))
{
	$id = $_SESSION['Job_Seeker_Id'];
		
	$js_qualification_name = $_POST['profficiency_level'];
	$js_course = $_POST['js_course'];
	$js_institution_name = $_POST['js_institution_name'];
	//$js_education_location = $_POST['js_education_location'];
	$js_start_date = $_POST['js_start_date'];
	$js_end_date = $_POST['js_end_date'];
	$js_percentage = $_POST['js_percentage'];
	//$js_university = $_POST['js_university'];
	if($jobseeker->Eduction_profile_update($id, $js_qualification_name, $js_course, $js_institution_name, $js_start_date,$js_end_date, $js_percentage))
	{	
		header("Location: jobseeker.php?type=home");		
	}
	else
	{
		$msg = "<div class='alert alert-warning'>
				<strong>SORRY!</strong> ERROR while updating record !
				</div>";
	}
}
}


$stmtje=$db->prepare("SELECT * FROM js_educational_information WHERE job_seeker_id ='".$_SESSION['Job_Seeker_Id']."'");
	
$stmtje->execute();
	
$js=$stmtje->fetch(PDO::FETCH_ASSOC);
?><!--// Educational  -->

        <div>
        <div class="row">
		<form name="edu_sub" id="form-validation" action="" method='post' class="form-floating" novalidate>
          <div class="col-md-12">
            <div class="form-group ">
              <label class="control-label">Choose Education</label>
             <select class='form-control' name="profficiency_level" value="<?php echo $js['profficiency_level']; ?>">
           <option value="<?php echo $js['js_qualification_name']; ?>"><?php echo $js['js_qualification_name']; ?></option>
            <option value="Post Graduation">Ph.D</option>
			<option value="Post Graduation">Post Graduation</option>
            <option value="Graduation">Graduation</option>
            <option value="Diploma">Diploma</option>
            <option value="Intermediate">Intermediate</option>
            <option value="SSC">SSC</option>
        </select>
              <div class="help-block with-errors"></div>
            </div>
          </div>
	
          <div class="col-md-6">
            
              <fieldset>
                <div class="form-group">
                  <label class="control-label">Course</label>
                  <input type="text" data-error="This field is First Name " name='js_course' class='form-control'  value="<?php echo $js['js_course']; ?>">
                  <div class="help-block with-errors"></div>
                </div>
                <div class="form-group">
                  <label class="control-label">Start Year </label>
                  <input  type='date' name='js_start_date' class='form-control'  value="<?php echo $js['js_start_date']; ?>"  data-error="That email address is invalid" required>
                  <div class="help-block with-errors"></div>
                </div>
                <div class="form-group">
                  <label class="control-label">% or CGPA </label>
                  <input type='text' name='js_percentage' class='form-control' value="<?php echo $js['js_percentage']; ?>">
                  <div class="help-block with-errors"></div>
                </div>
              </fieldset>
            
          </div>
          <div class="col-md-6">
            
              <fieldset>
                <div class="form-group">
                  <label class="control-label">Institute Name </label>
                  <input type="text" data-error="This field is First Name " required name='js_institution_name' class='form-control'  value="<?php echo $js['js_institution_name']; ?>" ">
                  <div class="help-block with-errors">
                </div>
                <div class="form-group">
                  <label class="control-label">End Year</label>
                  <input type='date' name='js_end_date' class='form-control'  value="<?php echo $js['js_end_date']; ?>" data-error="That email address is invalid" required >
                  <div class="help-block with-errors"></div>
                </div>
               
              </fieldset>
            
          </div> 
		  <div class="col-md-6" id='edu_row'>
            
              <fieldset>
                <div class="form-group">
				 <div class="" >
                  <div data-toggle="tooltip" data-title="New Item" class="btn btn-primary btn-round btn-lg" data-original-title="" title="" id="add_education"><i class="md md-add"></i>
                    <div class="ripple-wrapper"></div>
                  </div>
                  <div data-toggle="tooltip" data-title="Remove 0 item(s)" class="btn btn-primary btn-round btn-lg m-r-10 " data-original-title="" title="" id="del_education"><i class="md md-delete"></i></div>
                </div>
				 </div>
              </fieldset>
            
          </div> 
          <div class="col-md-12">
            <div class="form-group">
              <button class="btn btn-primary" href="" name="edu_sub" type="submit">Save
              <div class="ripple-wrapper"></div>
              </button>
              <button class="btn btn-default" type="reset">Cancel</button>
            </div>
          </div>
		  </form>
          </div>
		 </div>
       
		<!-- Exp-->
		<h1 style="padding:0px !important; margin:0px !important; "> <i class="fa fa-book" aria-hidden="true"></i>
 Experience Details</h1>	 
 <?php
$stmtje=$db->prepare("SELECT * FROM  js_work_experience");
	
$stmtje->execute();
	
$row_js=$stmtje->fetch(PDO::FETCH_ASSOC);

$row = $row_js['js_work_experience_id'];

if(empty($row)){
if(isset($_POST['exp_sub']))
{
	$id = $_SESSION['Job_Seeker_Id'];	
	$Company_Name = $_POST['Company_Name'];
	$Designation = $_POST['Designation'];
	$Start_date = $_POST['Start_date'];
	$End_date = $_POST['End_date'];
	$Current_CTC = $_POST['Current_CTC'];
	$Expected_CTC = $_POST['Expected_CTC'];

	if($jobseeker->Experience_profile($id,$Company_Name,$Designation,$Start_date,$End_date,$Current_CTC,$Expected_CTC))
	{		
		header("Location: jobseeker.php?type=home");		
	}
	else
	{
		$msg = "<div class='alert alert-warning'>
		<strong>SORRY!</strong> ERROR while inserted record !
		</div>";
	}
}

}
else {
 if(isset($_POST['exp_sub']))
{
	$id = $_SESSION['Job_Seeker_Id'];
		
	$Company_Name = $_POST['Company_Name'];
	$Designation = $_POST['Designation'];
	$Start_date = $_POST['Start_date'];
	$End_date = $_POST['End_date'];
	$Current_CTC = $_POST['Current_CTC'];
	$Expected_CTC = $_POST['Expected_CTC'];
	if($jobseeker->Experience_profile_update($id, $Company_Name, $Designation, $Start_date, $End_date, $Current_CTC, $Expected_CTC))
	{		
		
header("Location: jobseeker.php?type=home");			
	
	}
	else
	{
		$msg = "<div class='alert alert-warning'>
				<strong>SORRY!</strong> ERROR while updating record !
				</div>";
	}
}
}



$stmtje=$db->prepare("SELECT * FROM js_work_experience WHERE Job_Seeker_Id ='".$_SESSION['Job_Seeker_Id']."'");
	
$stmtje->execute();
	
$js=$stmtje->fetch(PDO::FETCH_ASSOC);
?>
        <div>
        <div class="row">
          
			<form id="form-validation" name="exp_sub" action="" method='post' class="form-floating" novalidate>
			<div class="col-md-6">
            
              <fieldset>
                <div class="form-group">
                  <label class="control-label">Company Name</label>
                  <input type="text" data-error="This field is First Name " name='Company_Name' class='form-control'  value="<?php echo $js['Company_Name']; ?>">
                  <div class="help-block with-errors"></div>
                </div>
                <div class="form-group">
                  <label class="control-label">Designation </label>
                  <input  type='text' name='Designation' class='form-control'  value="<?php echo $js['Designation']; ?>"  data-error="That email address is invalid" required>
                  <div class="help-block with-errors"></div>
                </div>
                <div class="form-group">
                  <label class="control-label">Start date </label>
                  <input type='date' name='Start_date' class='form-control' value="<?php echo $js['Start_date']; ?>">
                  <div class="help-block with-errors"></div>
                </div>
              </fieldset>
            
          </div>
          <div class="col-md-6">
           
              <fieldset>
                
                <div class="form-group">
                  <label class="control-label">Current CTC</label>
                  <input type='text' name='Current_CTC' class='form-control'  value="<?php echo $js['Current_CTC']; ?>" data-error="That email address is invalid" required >
                  <div class="help-block with-errors"></div>
                </div>
				 <div class="form-group">
                  <label class="control-label">Expected CTC</label>
                  <input type='text' name='Expected_CTC' class='form-control'  value="<?php echo $js['Expected_CTC']; ?>" data-error="That email address is invalid" required >
                  <div class="help-block with-errors"></div>
                </div>
				<div class="form-group">
                  <label class="control-label">End date</label>
                  <input type='date' name='End_date' class='form-control'  value="<?php echo $js['End_date']; ?>" data-error="That email address is invalid" required >
                  <div class="help-block with-errors"></div>
                </div></div>
                <div class="" id='exp_row'>
                  <div id="add_experiance" data-toggle="tooltip" data-title="New Item" class="btn btn-primary btn-round btn-lg" data-original-title="" title=""><i class="md md-add"></i>
                    <div class="ripple-wrapper"></div>
                  </div>
                  <div id="del_experiance" data-toggle="tooltip" data-title="Remove 0 item(s)" class="btn btn-primary btn-round btn-lg m-r-10 " data-original-title="" title=""><i class="md md-delete"></i></div>
                </div>
              </fieldset>
            
          
          <div class="col-md-12">
            <div class="form-group">
              <button class="btn btn-primary" name="exp_sub" type="submit">Save
              <div class="ripple-wrapper"></div>
              </button>
              <button class="btn btn-default" type="reset">Cancel</button>
            </div>
          </div>
		  </form>
          </div>
        </div>
        <h1 style="padding:0px !important; margin:0px !important; " > <i class="fa fa-magic" aria-hidden="true"></i> Skills</h1>
		
		<!-- Skills -->
		
<?php

$stmtje=$db->prepare("SELECT * FROM js_skills");
	
$stmtje->execute();
	
$row_js=$stmtje->fetch(PDO::FETCH_ASSOC);

 $row = $row_js['js_skills_id'];


if(empty($row)){
if(isset($_POST['sk_sub']))
{
	$id = $_SESSION['Job_Seeker_Id'];		
	$js_skill_description = $_POST['js_skill_description'];
	

	if($jobseeker->skills($id,$js_skill_description))
	{		
		  header("Location: jobseeker.php?type=home");	
//exit();		  
	}
	else
	{
		$msg = "<div class='alert alert-warning'>
		<strong>SORRY!</strong> ERROR while inserted record !
		</div>";
	}
}

}
else {
 if(isset($_POST['sk_sub']))
{
	$id = $_SESSION['Job_Seeker_Id'];
		
	$js_skill_description = $_POST['js_skill_description'];

	if($jobseeker->skills_update($id, $js_skill_description))
	{		
		  header("Location: jobseeker.php?type=home");		
	
	}
	else
	{
		$msg = "<div class='alert alert-warning'>
				<strong>SORRY!</strong> ERROR while updating record !
				</div>";
	}
}
}
?>
		
        <div>
        <div class="row">
          <div class="col-md-12">
		  <?php

$stmtje=$db->prepare("SELECT * FROM js_skills WHERE job_seeker_id ='".$_SESSION['Job_Seeker_Id']."'");
	
$stmtje->execute();
	
$js=$stmtje->fetch(PDO::FETCH_ASSOC);
?>
            <form id="form-validation" name="sk_sub" class="form-floating" method="post" novalidate>
              <fieldset>
                <div class="form-group">
                  <label class="control-label">Skills</label>
                  <textarea id="textArea" rows="1" name='js_skill_description' class="form-control vertical"><?php echo $js['js_skill_description']; ?></textarea>
                  <div class="help-block with-errors"></div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                    <button class="btn btn-primary"  name="sk_sub" type="submit">Save
                    <div class="ripple-wrapper"></div>
                    </button>
                    <button class="btn btn-default" type="reset">Cancel</button>
                  </div>
                </div>
              </fieldset>
            </form>
          </div>
          </div>
        </div>
        <h1 style="padding:0px !important; margin:0px !important; " ><i class="fa fa-object-group" aria-hidden="true"></i> Objective </h1>
		
		<?php

$stmtje=$db->prepare("SELECT * FROM js_carrer_objective");
	
$stmtje->execute();
	
$row_js=$stmtje->fetch(PDO::FETCH_ASSOC);

 $row = $row_js['carrer_objective_id'];


if(empty($row)){
if(isset($_POST['obj_sub']))
{
	$id = $_SESSION['Job_Seeker_Id'];		
	$career_objective_name = $_POST['career_objective_name'];
	

	if($jobseeker->Objective($id,$career_objective_name))
	{		
		  header("Location: jobseeker.php?type=home");		
	}
	else
	{
		$msg = "<div class='alert alert-warning'>
		<strong>SORRY!</strong> ERROR while inserted record !
		</div>";
	}
}

}
else {
 if(isset($_POST['obj_sub']))
{
	$id = $_SESSION['Job_Seeker_Id'];
		
	$career_objective_name = $_POST['career_objective_name'];

	if($jobseeker->Objective_update($id, $career_objective_name))
	{		
		  header("Location: jobseeker.php?type=home");		
	
	}
	else
	{
		$msg = "<div class='alert alert-warning'>
				<strong>SORRY!</strong> ERROR while updating record !
				</div>";
	}
}
}


?>



        <div>
        <div class="row">
          <div class="col-md-12"><?php

$stmtje=$db->prepare("SELECT * FROM js_carrer_objective WHERE job_seeker_id ='".$_SESSION['Job_Seeker_Id']."'");
	
$stmtje->execute();
	
$js=$stmtje->fetch(PDO::FETCH_ASSOC);
?>
            <form id="form-validation" name="obj_sub"action="" method="post" class="form-floating" novalidate>
              <fieldset>
                <div class="form-group">
                  <label class="control-label">Objective</label>
                  <textarea id="textArea" rows="1" class="form-control vertical"name='career_objective_name'  > <?php echo $js['career_objective_name']; ?></textarea>
                  <div class="help-block with-errors"></div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                    <button class="btn btn-primary" name="obj_sub" type="Save">Save
                    <div class="ripple-wrapper"></div>
                    </button>
                    <button class="btn btn-default" type="reset">Cancel</button>
                  </div>
                </div>
              </fieldset>
            </form>
          </div>
          </div>
        </div>
        <h1 style="padding:0px !important; margin:0px !important; " > <i class="fa fa-hourglass" aria-hidden="true"></i> Hobbies</h1>
		
<?php

$stmtje=$db->prepare("SELECT * FROM js_hobbies");
	
$stmtje->execute();
	
$row_js=$stmtje->fetch(PDO::FETCH_ASSOC);

$row = $row_js['hobby_name'];



if(empty($row)){
if(isset($_POST['ho_sub']))
{
	$id = $_SESSION['Job_Seeker_Id'];
	$hobby_name = $_POST['hobby_name'];
	

	if($jobseeker->hobbies($id,$hobby_name))
	{		
		  header("Location: jobseeker.php?type=home");		
	}
	else
	{
		$msg = "<div class='alert alert-warning'>
		<strong>SORRY!</strong> ERROR while inserted record !
		</div>";
	}
}

}
else {
 if(isset($_POST['ho_sub']))
{
	$id = $_SESSION['Job_Seeker_Id'];
		
	$hobby_name = $_POST['hobby_name'];

	if($jobseeker->hobbies_update($id, $hobby_name))
	{		
		  header("Location:jobseeker.php?type=home");		
	
	}
	else
	{
		$msg = "<div class='alert alert-warning'>
				<strong>SORRY!</strong> ERROR while updating record !
				</div>";
	}
}
}

?>
        <div>
        <div class="row">
          <div class="col-md-12"><?php

$stmtje=$db->prepare("SELECT * FROM js_hobbies WHERE job_seeker_id ='".$_SESSION['Job_Seeker_Id']."'");
	
$stmtje->execute();
	
$js=$stmtje->fetch(PDO::FETCH_ASSOC);
?>
            <form id="form-validation" name="ho_sub" action="" method="post" class="form-floating" novalidate>
              <fieldset>
                <div class="form-group">
                  <label class="control-label">Hobbies</label>
                  <textarea id="textArea" rows="1" name='hobby_name' class="form-control vertical"> <?php echo $js['hobby_name']; ?></textarea>
                  <div class="help-block with-errors"></div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                    <button class="btn btn-primary" name="ho_sub" type="Save">Save
                    <div class="ripple-wrapper"></div>
                    </button>
                    <button class="btn btn-default" type="reset">Cancel</button>
                  </div>
                </div>
              </fieldset>
            </form>
          </div>
          </div>
        </div>
        <!--<h1 style="padding:0px !important; margin:0px !important; " > <i class="fa fa-lightbulb-o" aria-hidden="true"></i> Domain</h1>
        <div>
        <div class="row">
          <div class="col-md-12">
            <form id="form-validation" class="form-floating" novalidate>
              <fieldset>
                <div class="form-group">
                  <label class="control-label">Domain</label>
                  <textarea id="textArea" rows="1" class="form-control vertical"></textarea>
                  <div class="help-block with-errors"></div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                    <button class="btn btn-primary" name="ho_sub" type="Save">Save
                    <div class="ripple-wrapper"></div>
                    </button>
                    <button class="btn btn-default" type="reset">Cancel</button>
                  </div>
                </div>
              </fieldset>
            </form>
          </div>
          </div>
        </div> -->
        <script>
      $(".accordion").accordion();
    </script> 
      </div>
       
    </div>
  </div>
</div>
<div class="col-md-3">
  <div class="card">
    <div class="card-header relative">
      <div class="card-title"> Content Writers</div>
    </div>
    <div class="list-group">
	<?php

$stmtje=$db->prepare("SELECT * FROM content_writer LIMIT 4");
	
$stmtje->execute();
//	$i=1;
while($row=$stmtje->fetch(PDO::FETCH_ASSOC))
			{
?>
	<form method="post">
	
      <div class="list-group-item clearfix" href="#">
        <div class="pull-left m-r-10"> <img src="<?php echo $row['Profile_picture_path']; ?>" class="img-responsive" style="  border-radius: 50%; "> </div>
        <div class="list-group-item-heading"><?php echo $row['User_name']; ?></div>
        <span class="list-group-item-text">
        <p><?php echo $row['Profile_summary']; ?></p>
        </span>
        <div class="row">
          <div class="col-md-3">
            <p>Rating</p>
          </div>
         <div class="col-md-9" > <a href="#"><i class="md md-star-rate"></i></a> <a href="#"><i class="md md-star-rate"></i></a> <a href="#"><i class="md md-star-rate"></i></a> <a href="#"><i class="md md-star-rate"></i></a> <a href="#"><i class="md md-star-rate"></i></a> </div>
          <div class="pull-right"> <a title="" data-toggle="tooltip" class="btn btn-round-sm btn-link" target="_blank" href="pages-material-bird.html" data-original-title="Order now"><i class="fa fa-shopping-cart" aria-hidden="true"></i>
            <div class="ripple-wrapper"></div>
            </a> <a title="" data-toggle="tooltip" class="btn btn-round-sm btn-link" target="_blank" href="pages-material-bird.html" data-original-title="Send an enquiry"><i class="fa fa-paper-plane" aria-hidden="true"></i> </a>  </div> 
        </div>
      </div>
	  </form>
			<?php 
  // $i=$i+1;
     }

	  ?>
    <!--  <div class="list-group">
        <div class="list-group-item clearfix" href="#">
          <div class="pull-left m-r-10"> <img src="assets/img/icon_user.png" class="img-responsive" style="  border-radius: 50%; "> </div>
          <div class="list-group-item-heading">Domala Rajamouli</div>
          <span class="list-group-item-text">
          <p>Risus sed vulputate odio ut enim blandit volutpat maecenas volutpat blandit aliquam etiam erat.</p>
          </span>
          <div class="row">
            <div class="col-md-3">
              <p>Rating</p>
            </div>
            <div class="col-md-9" style=" font-size: 22px !important; "> <a href="#"><i class="md md-star-rate"></i></a> <a href="#"><i class="md md-star-rate"></i></a> <a href="#"><i class="md md-star-rate"></i></a> <a href="#"><i class="md md-star-rate"></i></a> <a href="#"><i class="md md-star-rate"></i></a> </div>
          </div>
        </div>
        <div class="list-group">
          <div class="list-group-item clearfix" href="#">
            <div class="pull-left m-r-10"> <img src="assets/img/icon_user.png" class="img-responsive" style="  border-radius: 50%; "> </div>
            <div class="list-group-item-heading">Domala Rajamouli</div>
            <span class="list-group-item-text">
            <p>Risus sed vulputate odio ut enim blandit volutpat maecenas volutpat blandit aliquam etiam erat.</p>
            </span>
            <div class="row">
              <div class="col-md-3">
                <p>Rating</p>
              </div>
              <div class="col-md-9" style=" font-size: 22px !important; "> <a href="#"><i class="md md-star-rate"></i></a> <a href="#"><i class="md md-star-rate"></i></a> <a href="#"><i class="md md-star-rate"></i></a> <a href="#"><i class="md md-star-rate"></i></a> <a href="#"><i class="md md-star-rate"></i></a> </div>
            </div>
            <div class="pull-right"> <a title="" data-toggle="tooltip" class="btn btn-round-sm btn-link" target="_blank" href="pages-material-bird.html" data-original-title="Order now"><i class="fa fa-shopping-cart" aria-hidden="true"></i>
              <div class="ripple-wrapper"></div>
              </a> <a title="" data-toggle="tooltip" class="btn btn-round-sm btn-link" target="_blank" href="pages-material-bird.html" data-original-title="Send an enquiry"><i class="fa fa-paper-plane" aria-hidden="true"></i> </a>  </div>
          </div>
          <div class="list-group">
            <div class="list-group-item clearfix" href="#">
              <div class="pull-left m-r-10"> <img src="assets/img/icon_user.png" class="img-responsive" style="  border-radius: 50%; "> </div>
              <div class="list-group-item-heading">Domala Rajamouli</div>
              <span class="list-group-item-text">
              <p>Risus sed vulputate odio ut enim blandit volutpat maecenas volutpat blandit aliquam etiam erat.</p>
              </span>
              <div class="row">
                <div class="col-md-3">
                  <p>Rating</p>
                </div>
                <div class="col-md-9" style=" font-size: 22px !important; "> <a href="#"><i class="md md-star-rate"></i></a> <a href="#"><i class="md md-star-rate"></i></a> <a href="#"><i class="md md-star-rate"></i></a> <a href="#"><i class="md md-star-rate"></i></a> <a href="#"><i class="md md-star-rate"></i></a> </div>
              </div>
              <div class="pull-right"> <a title="" data-toggle="tooltip" class="btn btn-round-sm btn-link" target="_blank" href="pages-material-bird.html" data-original-title="Order now"><i class="fa fa-shopping-cart" aria-hidden="true"></i>
                <div class="ripple-wrapper"></div>
                </a> <a title="" data-toggle="tooltip" class="btn btn-round-sm btn-link" target="_blank" href="pages-material-bird.html" data-original-title="Send an enquiry"><i class="fa fa-paper-plane" aria-hidden="true"></i> </a> 
               </div>
            </div>
          </div>
        </div>
      </div>-->
    </div>
  </div>
</div>
</section>

<script charset="utf-8" src="assets/js/vendors.min.js"></script> 
<script charset="utf-8" src="assets/js/app.min.js"></script>
</body>

</html>
<?php 

include_once '../db.php';

session_start();

include_once 'jobseeker_model.php';

$jobseeker = new jobseeker($db); 

?>


 <?php // Educational Information PHP Code..



?>




