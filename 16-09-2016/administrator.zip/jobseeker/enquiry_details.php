<?php
include_once '../db.php';
ob_start(); 

include_once 'jobseeker_model.php';

$jobseeker = new jobseeker($db);

include_once 'header.php';
?>
    <section class="colors">
        <div class="container-fluid">
            <div class="p-10 clearfix">
                <h4 class="grey-text"> <i class="md md-dashboard"></i> <span class="hidden-xs">Change Password</span> </h4>
            </div>
            <div class="col-md-9">
                <h5></h5>
                <div class="card">

                    <?php 
                     $n = htmlspecialchars($_GET["n"]);
                    
                    $update = $db->prepare("update js_enquiry_detail set is_read=0 where is_read=1 and js_receiver='".$_SESSION['Job_Seeker_Id']."' and js_enquiry_id='".$n."'");
                            $update->execute();
                    
                    
                    $stmtjs=$db->prepare("SELECT * FROM js_enquiries WHERE js_enquiry_id='".$n."'");

                    $stmtjs->execute();

                    $js=$stmtjs->fetch(PDO::FETCH_ASSOC);
                    $c_id=$js['js_content_writer_id'];
                    $stmtcw=$db->prepare("SELECT * FROM content_writer WHERE Content_writer_id='".$c_id."'");

                    $stmtcw->execute();

                    $cw=$stmtcw->fetch(PDO::FETCH_ASSOC);
                       
                    ?>
                        <div class="list-group">
                            <a href="#" class="list-group-item active">
                                <p class="list-group-item-text">
                                    <?php  echo $js['js_message']; ?>
                                </p>
                            </a>
                            <?php
                            $stmt=$db->prepare("SELECT * FROM js_enquiry_detail WHERE js_enquiry_id='".$n."'");

                            
	 
                            if(isset($_POST['enq_frm']))
                            {
                            $js_message = $_POST['message'];
                            $js_enquiry_id = $js['js_enquiry_id'];
                            $js_sender = $_SESSION['Job_Seeker_Id'];
                            $js_receiver = $cw['Content_writer_id'];
                                
                                
                                
                            if($jobseeker->enquiry_details($js_enquiry_id, $js_sender, $js_receiver,$js_message))
                            {		//echo("add");
                                $stmt=$db->prepare("SELECT * FROM js_enquiry_detail WHERE js_enquiry_id='".$n."'");

                            }
                            else
                            {
                                $msg = "<div class='alert alert-warning'>
                                        <strong>SORRY!</strong> ERROR while inserting record !
                                        </div>";
                            }


                            }
                            if(isset($msg))
                            {
                                echo $msg;
                            } 
                            


                                $stmt->execute(); if ($stmt->rowCount() > 0) { while($row=$stmt->fetch(PDO::FETCH_ASSOC)) { if($row['js_sender']==$_SESSION['Job_Seeker_Id']) { ?>

                                <a href="#" class="list-group-item">
                                    <h4 class="list-group-item-heading"><?php echo 'me' ?></h4>
                                    <p class="list-group-item-text">
                                        <?php  echo $row['js_message'] ?>
                                    </p>
                                </a>
                                <?php
                                     }
                                     else
                                     {
                                         ?>
                                    <a href="#" class="list-group-item">
                                        <h4 class="list-group-item-heading"><?php echo substr_replace($cw['Email_id'], str_repeat("X", 10), 2, 5); ?></h4>
                                        <p class="list-group-item-text">
                                            <?php  echo $row['js_message'] ?>
                                        </p>
                                    </a>
                                    <?php
                                     }
                                 }
                            }
                                ?>
                        </div>
                </div>

                <form class="form-floating" name="enq_frm" method="post">
                    <fieldset>
                        <div class="form-group">
                            <label class="control-label">Reply </label>
                            <textarea class='form-control vertical' id="textArea" rows="1" name="message"></textarea>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <button type="submit" name="enq_frm" class="btn btn-primary pull-right">Submit</button>
                        </div>
                    </fieldset>
                </form>
            </div>
        </div>
    </section>
