
<?php 

include_once '../db.php';

ob_start(); 

include_once 'jobseeker_model.php';

$jobseeker = new jobseeker($db); 

?>
<section class="colors">
<div class="container-fluid">
<div class="p-10 clearfix">
  <h4 class="grey-text"> <i class="md md-dashboard"></i> <span class="hidden-xs">Job Seeker Dashboard</span> </h4>
</div>
<div class="col-md-3">
  <div class="card">
    <div style="  padding: 10px; ">
      <div class="row">
        <div class="col-md-6">
          <p>Fresher</p>
          <a href="#"> <img style=" width:100%; height: 150px; border: 1px #ccc solid; " src="assets/img/T1.png"> </a> </div>
        <div class="col-md-6">
          <p>Experience</p>
          <a href="#"> <img style=" width:100%; height: 150px; border: 1px #ccc solid; " src="assets/img/T2.png"> </a> </div>
      </div>
    </div>
    <div style="  padding: 10px; ">
      <div class="row">
        <div class="col-md-6">
          <p>Fresher</p>
          <a href="#"> <img style=" width:100%; height: 150px; border: 1px #ccc solid; " src="assets/img/T1.png"> </a> </div>
        <div class="col-md-6">
          <p>Experience</p>
          <a href="#"> <img style=" width:100%; height: 150px; border: 1px #ccc solid; " src="assets/img/T2.png"> </a> </div>
      </div>
    </div>
    <div style="  padding: 10px; ">
      <div class="row">
        <div class="col-md-6"> <a href="#"> <img style=" width:100%; height: 150px; border: 1px #ccc solid; " src="assets/img/T1.png"> </a> </div>
        <div class="col-md-6"> <a href="#"> <img style=" width:100%; height: 150px; border: 1px #ccc solid; " src="assets/img/T2.png"> </a> </div>
      </div>
    </div>
    <div style="  padding: 10px; ">
      <div class="row">
        <div class="col-md-6"> <a href="#"> <img style=" width:100%; height: 150px; border: 1px #ccc solid; " src="assets/img/T1.png"> </a> </div>
        <div class="col-md-6"> <a href="#"> <img style=" width:100%; height: 150px; border: 1px #ccc solid; " src="assets/img/T2.png"> </a> </div>
      </div>
    </div>
    <div style="  padding: 10px; ">
      <div class="row">
        <div class="col-md-6"> <a href="#"> <img style=" width:100%; height: 150px; border: 1px #ccc solid; " src="assets/img/T1.png"> </a> </div>
        <div class="col-md-6"> <a href="#"> <img style=" width:100%; height: 150px; border: 1px #ccc solid; " src="assets/img/T2.png"> </a> </div>
      </div>
    </div>
  </div>
</div>
<div class="col-md-6">
  <div class="row">
    <div class="col-sm-12">
     <div class="well white">
	 <?php
	 include '../functions.php';
	  $stmtjs=$db->prepare("SELECT * FROM job_seeker WHERE job_seeker_id ='".$_SESSION['Job_Seeker_Id']."'");
	
	$stmtjs->execute();
	
	$js=$stmtjs->fetch(PDO::FETCH_ASSOC);
	 
	 if(isset($_POST['submit']))
{
		
	$old_password = $_POST['old_password'];
	
	


	$new_password = $_POST['new_password'];
	
	
	$cfrm_password = $_POST['cfrm_password'];



	$id = $_SESSION['Job_Seeker_Id'];
	
	$errors = array();
	
	
	
	 if($jobseeker->change_password($new_password, $cfrm_password, $id))
	{		//echo("add");
		$msg = "<div class='alert alert-info'>
				your <strong>Password</strong>  successfully Changed, Please login with new Password!
				</div>";	
				
	}
	
	 
	
}

$stmtje=$db->prepare("SELECT * FROM job_seeker WHERE Job_Seeker_Id ='".$_SESSION['Job_Seeker_Id']."'");
	
$stmtje->execute();
	
$js=$stmtje->fetch(PDO::FETCH_ASSOC);
?>
        <form method="post" id="register-form" name="cp_frm" class="form-floating">
            <fieldset><div class="">
  <?php
if(isset($msg))
{
	echo $msg;
}   
	
?>		  </div> 
		 
	<input id="c_pswd" name="c_pswd" type="hidden" class="form-control"  value="<?php echo $js['Confirm_password']; ?>" >

			<div class="clearfix"></div>    <div class="form-group">
                        <label for="password"  class="control-label">Old Password</label>
                        <input id="old_password" type="password" name="old_password" value=""required class="form-control"> </div>
                      <div class="form-group">
                        <label for="password" class="control-label">New Password</label>
                        <input type="password" name="new_password"  value="" required class="form-control" id="inputSubject">
						
					
						 </div>
                     
                   
                      <div class="form-group">
                        <label for="password" class="control-label">Confirm Password</label>
                     <input type="password" name="cfrm_password" value="" required class="form-control" id="inputSubject">
					  </div>
					  
                      <div class="form-group">
                        <button type="submit" id="change_password" name="submit" class="btn btn-primary">Submit</button>
                        <button type="reset" class="btn btn-default">Cancel</button>
                      </div>
            </fieldset>
         </form>
        </div>
    </div>
  </div>
</div>
<div class="col-md-3">
  <div class="card">
    <div class="card-header relative">
      <div class="card-title"> Content Writers</div>
    </div>
    <div class="list-group">
	<?php

     
   // Retrieve the URL variables (using PHP).
   
		
   
$stmtje=$db->prepare("SELECT * FROM content_writer LIMIT 4");
	
$stmtje->execute();
//	$i=1;
while($row=$stmtje->fetch(PDO::FETCH_ASSOC))
			{
?>
	<form method="post">
	
      <div class="list-group-item clearfix" href="#">
        <div class="pull-left m-r-10"> <img src="../administrator/<?php echo $row['Profile_picture_path']; ?>" class="img-responsive" style="  border-radius: 50%; "> </div>
        <div class="list-group-item-heading"><?php echo $row['User_name']; ?></div>
        <span class="list-group-item-text">
        <p><?php echo $row['Profile_summary']; ?></p>
        </span>
        <div class="row">
          <div class="col-md-3">
            <p>Rating</p>
          </div>
         <div class="col-md-9" > <a href="#"><i class="md md-star-rate"></i></a> <a href="#"><i class="md md-star-rate"></i></a> <a href="#"><i class="md md-star-rate"></i></a> <a href="#"><i class="md md-star-rate"></i></a> <a href="#"><i class="md md-star-rate"></i></a> </div>
          <div class="pull-right"> <a title="" data-toggle="tooltip" class="btn btn-round-sm btn-link" target="_blank" href="pages-material-bird.html" data-original-title="Order now"><i class="fa fa-shopping-cart" aria-hidden="true"></i>
            <div class="ripple-wrapper"></div>
            </a> <a title="" data-toggle="tooltip" class="btn btn-round-sm btn-link" target="_blank" href="jobseeker.php?type=send_enquiry" data-original-title="Send an enquiry">
 <i class="fa fa-paper-plane" aria-hidden="true"></i><?php $_SESSION['CW_ID']=$row['Content_writer_id']; ?> </a>  </div> 
        </div>
      </div>
	  </form>
			<?php   
     }

	  ?>
    
    </div>
  </div>
</div>
</section>


<script type="text/javascript">
       $(document).ready(function(){
          $("#register-form").validate();
       });
    </script>
<style type="text/css">
     .error{
        color: red;
     }
    </style>