<?php 

include_once '../db.php';

ob_start(); 

include_once 'jobseeker_model.php';

$jobseeker = new jobseeker($db); 

?>

    <section class="colors">
        <div class="container-fluid">
            <div class="p-10 clearfix">
                <h4 class="grey-text"> <i class="md md-dashboard"></i> <span class="hidden-xs">Job Seeker Dashboard</span> </h4>
            </div>
            <div class="col-md-3">

                <div class="card">
                    <div style="  padding: 10px; ">
                        <p>&nbsp;</p>
                        <div class="row">
                            <div class="col-md-12">
                                <button type="button" class="btn btn-default col-md-12">Template's List</button>
                            </div>
                        </div>
                        <p>&nbsp;</p>
                        <div class="row">
                            <div class="col-md-12">
                                <button type="button" class="btn btn-success col-md-12">Profile Details</button>
                            </div>
                        </div>
                        <p>&nbsp;</p>
                        <div class="row">
                            <div class="col-md-12">
                                <button type="button" class="btn btn-info col-md-12">Payment Process</button>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
			
	<?php 
	if(isset($_POST['pick-temp']))
	{
	$temp_image =  $_POST['pick-temp'];
	if($temp_image == T1)
	{
		$id = $_GET['id'];
		
	header("Location: jobseeker.php?type=profile_valid&t_id=$id&inserted");	
	}
	}
	?>
		<?php
echo $id = $_GET['id'];
?>		
            <div class="col-md-5">
                
                    <div class="col-sm-9">
                        <div class="well white">                            
                                <form method="post" name="enq_frm" class="form-floating">
                                                                           
                                            <div id="template" class="carousel slide">
                                                <!-- Wrapper for slides -->
                                                <div class="carousel-inner" role="listbox">

                                                    <div class="item active">
                                                  <input type="image"   name="t1" value="t1" alt="T1"   
												  src="templates\img\templates\T1.png" width="350" height="400"> </input>

                                                    </div>

                                                    <div class="item">
                                                        <input type="image"  src="templates\img\templates\T1.png"  width="350" height="400" name="t2" value="t2" alt="T2" >

                                                    </div>
													
													<div class="item">
                                                        <input type="image"  src="templates\img\templates\T1.png" name="t3" value="t3" alt="T3"  width="350" height="400" >

                                                    </div>
												
											<button type="submit" name="pick-temp" value="T1"class="pull-right right btn btn-success">Continue</button>
                                                </div>


                                            </div>
                                        
                                        <!-- Left and right controls -->
                                        <a class="pull-left left" href="#template" role="button">
                                            <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
                                            <span class="sr-only">Previous</span>
                                        </a>
                                        <a class="pull-right right" href="#template" role="button">
                                            <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
                                            <span class="sr-only">Next</span>
                                        </a>
                                        <script>
                                            $(document).ready(function() {
                                                $('.carousel').carousel('pause');


                                                // Enable Carousel Controls
                                                $(".left").click(function() {
                                                    $("#template").carousel("prev");
                                                });
                                                $(".right").click(function() {
                                                    $("#template").carousel("next");
                                                });
                                            });

                                        </script>


                                        
                                        <div class="clearfix"></div>
                                   
                                </form>
                        </div>
                    </div>
               
            </div>
            <div class="col-md-3">
                <div class="card">
                    <div class="card-header relative">
                        <div class="card-title"> Content Writers</div>
                    </div>
                    <div class="list-group">
                        <?php

     
   // Retrieve the URL variables (using PHP).
   
		
   
$stmtje=$db->prepare("SELECT * FROM content_writer LIMIT 4");
	
$stmtje->execute();
//	$i=1;
while($row=$stmtje->fetch(PDO::FETCH_ASSOC))
			{
?>
                            <form method="post">


                            </form>
                            <?php   
     }

	  ?>

                    </div>
                </div>
            </div>
    </section>
