<?php
include_once '../db.php';

include_once 'jobseeker_model.php';

$jobseeker = new jobseeker($db);

if(isset($_POST['btn-update']))
{
	$id = $_SESSION['Job_Seeker_Id'];
	$First_name = $_POST['First_name'];
	$Last_name = $_POST['Last_name'];
	$Email_id = $_POST['Email_id'];
	$User_name = $_POST['User_name'];	
	$Phone_No = $_POST['Phone_No'];
	$Experience_level = $_POST['Experience_level'];
	$Domain = $_POST['Domain'];
	
	//echo $id;
	//echo $First_name;
	
	//exit();
	if($jobseeker->update($id,$First_name,$Last_name,$Email_id,$User_name,$Phone_No,$Experience_level,$Domain))
	{

		$msg = "<div class='alert alert-info'>
				your <strong>Query</strong>  successfully sent to Content Writer !
				</div>";	
		
	}
	else
	{
		$msg = "<div class='alert alert-warning'>
				<strong>SORRY!</strong> ERROR while inserting record !
				</div>";
	}
}
if(isset($_GET['edit_id']))
{
	$id = $_GET['edit_id'];
	extract($jobseeker->getID($id));	
}

?>





<?php 
	$stmtjs=$db->prepare("SELECT * FROM job_seeker WHERE Job_Seeker_Id='".$_SESSION['Job_Seeker_Id']."'");
	
	$stmtjs->execute();
	
	$js=$stmtjs->fetch(PDO::FETCH_ASSOC);
	
	
		
	?>
<div class="clearfix"></div><br />

<div class="container">
	 
     <form method='post'>
 
    <table class='table table-bordered'>
	<div class="clearfix"></div>

<div class="">
<?php
if(isset($msg))
{
	echo $msg;
}   
	
?>
		
</div>
 <div class="form-group">
        <tr>
            <td>First Name</td>
            <td><input type='text' name='First_name' class='form-control' value="<?php echo $js['First_name']; ?>" required></td>
       
            <td>Last Name</td>
            <td><input type='text' name='Last_name' class='form-control' value="<?php echo $js['Last_name']; ?>" required></td>
        </tr>
 </div>
        <tr>
            <td>E-mail ID</td>
            <td><input type='email' name='Email_id' class='form-control' value="<?php echo $js['Email_id']; ?>" required></td>
        
            <td>User name</td>
            <td><input type='text' name='User_name' class='form-control' value="<?php echo $js['User_name']; ?>" required></td>
        </tr>

		
       
 		<tr>
            <td>Contact No</td>
            <td><input type='text' name='Phone_No' class='form-control' value="<?php echo $js['Phone_No']; ?>" required></td>
       
            <td>Experience level</td>
			<td> <div class="form-group">
                      
                        <div class="radio">
                          <label>
                            <input type="radio" name='Experience_level' checked="" value="Fresher" <?php if($js['Experience_level']=="Fresher") { echo "checked"; } ?> id="optionsRadios1" > Fresher &emsp;</label>
                       
                          <label>
                            <input type="radio" name='Experience_level' value="Experience" id="optionsRadios2" <?php if($js['Experience_level']=="Experience") { echo "checked"; } ?>> Experienced </label>
                        </div>
                      </div></td>
			
        </tr>
 		<tr>
            <td>Domain</td>
            <td><input type='text' name='Domain' class='form-control' value="<?php echo $js['Domain']; ?>" required></td>
        </tr>
 
        <tr>
            <td colspan="2">
                <button type="submit" class="btn btn-primary" name="btn-update">
    			<span class="glyphicon glyphicon-edit"></span>  Update
				</button>
                <a href="#" class="btn btn-large btn-success"><i class="glyphicon glyphicon-backward"></i> &nbsp; CANCEL</a>
            </td>
        </tr>
 
    </table>
</form>
     
     
</div>

