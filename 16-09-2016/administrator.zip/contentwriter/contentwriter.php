<?php
include 'header.php'; 

$type=$_GET['type'];
if($type == 'home'){    
include 'contentwriter_dashboard.php';
}
else if($type == 'js'){
    include 'jobseeker_list.php';
}
else if($type == 'mr'){
    include 'templates.php';
}
else if($type == 'template'){
    include 'templates.php';
}
else if($type == 'ed'){
    include 'enquiry_details.php';
}
else if($type == 'not'){
include 'notification.php';
}
else if($type == 'edit_profile'){
include 'edit_profile.php';
}
else if($type == 'change_password'){
include 'change_password.php';
}
else if($type == 'my_orders'){
include 'my_orders.php';
}
else if($type == 'logout'){
include 'logout.php';
}
include 'footer.php';
?>
