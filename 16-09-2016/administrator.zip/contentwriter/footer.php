<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="">
<meta name="author" content="">
<title>Resume Services</title>

</head>
<body init-ripples="">
<div class="footer">
  <div class="container-fluid">
    <div class="pull-left"> <a href="http://virtuelltech.com/">virtuelltech</a> © 2016. </div>
    <div class="pull-right">Powered by <a href="http://virtuelltech.com/">virtuelltech</a> </div>
  </div>
</div>
<script charset="utf-8" src="assets/js/vendors.min.js"></script> 
<script charset="utf-8" src="assets/js/app.min.js"></script>
</body>

</html>