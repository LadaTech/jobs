<?php
include_once '../db.php';

//include_once 'jobseeker_model.php';

//$jobseeker = new jobseeker($db);

?>
<?php include_once 'header.php'; ?>

<section class="colors">
<div class="container-fluid">
<div class="p-10 clearfix">
  <h4 class="grey-text"> <i class="md md-dashboard"></i> <span class="hidden-xs">Change Password</span> </h4>
</div>
<div class="col-md-3">
  <div class="card">
    <div style="  padding: 10px; ">
      <div class="row">
        <div class="col-md-12">
          <p>Experience</p>
          <a href="#"> <img style=" width:100%; height: 100%; border: 1px #ccc solid; " src="assets/img/T2.png"> </a> </div>
      </div>
    </div>
  </div>
</div>
    
    <div class="col-md-6">
        
        <?php 
	$stmtjs=$db->prepare("SELECT * FROM content_writer WHERE Content_writer_id='".$_SESSION['content_writer_Id']."'");
	
	$stmtjs->execute();
	
	$js=$stmtjs->fetch(PDO::FETCH_ASSOC);
	
	
		
	?>
<div class="clearfix"></div><br />

<form method='post'>
 
    <table class='table table-bordered'>
  
        
             <tr>
            <td>old Password</td>
            <td><input type='password' name='Password' class='form-control' value="" required></td>
        
            
                
        </tr> 
        <tr>
            <td>New Password </td>
            <td><input type='password' name='Confirm_password' class='form-control' value="" required></td>
        </tr>
<tr>
     <td>Confirm Password </td>
            <td><input type='password' name='Confirm_password' class='form-control' value="" required></td>
		
        </tr>
        <tr>
             <td>
                 
            </td>
            <td>
                <button class="btn btn-primary" type="Save">Save
                    <div class="ripple-wrapper"></div>
                    </button>
                <button class="btn btn-default" type="reset">Cancel</button>
            </td>
		
        </tr>
    </table>
</form>
     
        
    </div>
    
    
    <div class="col-md-3">
  <div class="card">
    <div class="card-header relative">
      <div class="card-title"> Jobseekers</div>
    </div>
    <div class="list-group">
	<?php

$stmtje=$db->prepare("SELECT * FROM job_seeker LIMIT 4");
	
$stmtje->execute();
//	$i=1;
while($row=$stmtje->fetch(PDO::FETCH_ASSOC))
			{
?>
	<form method="post">
	
      <div class="list-group-item clearfix" href="#">
        <div class="pull-left m-r-10"> <img src="<?php echo $row['Profile_picture_path']; ?>" class="img-responsive" style="  border-radius: 50%; "> </div>
        <div class="list-group-item-heading"><?php echo $row['User_name']; ?></div>
      
        <span class="list-group-item-text">
        </span>
        <div class="row">
          <div class="col-md-6">
            <p>Domain:</p>
          </div>
         <div class="col-md-6" > <?php echo $row['Domain']; ?> </div>           
          
        </div>
          
          <div class="row"><div class="col-md-6">
            <p>Template ID:</p>
          </div>
         <div class="col-md-6" > IT-01 </div></div>
          <div class="row">
          <div class="pull-left"> <a title="" data-toggle="tooltip" class="btn btn-round-sm btn-link" href="contentwriter.php?type=home&id=<?php echo $row['Job_Seeker_Id']; ?>" data-original-title="View Details"><i class="fa fa-desktop" aria-hidden="true"></i>
            <div class="ripple-wrapper"></div>
            </a> <a title="" data-toggle="tooltip" class="btn btn-round-sm btn-link" target="_blank" href="pages-material-bird.html" data-original-title="Move to Template"><i class="fa fa-arrows" aria-hidden="true"></i> </a>  </div> 
          </div>
      </div>
	  </form>
			<?php 
  // $i=$i+1;
     }

	  ?>
    <!--  <div class="list-group">
        <div class="list-group-item clearfix" href="#">
          <div class="pull-left m-r-10"> <img src="assets/img/icon_user.png" class="img-responsive" style="  border-radius: 50%; "> </div>
          <div class="list-group-item-heading">Domala Rajamouli</div>
          <span class="list-group-item-text">
          <p>Risus sed vulputate odio ut enim blandit volutpat maecenas volutpat blandit aliquam etiam erat.</p>
          </span>
          <div class="row">
            <div class="col-md-3">
              <p>Rating</p>
            </div>
            <div class="col-md-9" style=" font-size: 22px !important; "> <a href="#"><i class="md md-star-rate"></i></a> <a href="#"><i class="md md-star-rate"></i></a> <a href="#"><i class="md md-star-rate"></i></a> <a href="#"><i class="md md-star-rate"></i></a> <a href="#"><i class="md md-star-rate"></i></a> </div>
          </div>
        </div>
        <div class="list-group">
          <div class="list-group-item clearfix" href="#">
            <div class="pull-left m-r-10"> <img src="assets/img/icon_user.png" class="img-responsive" style="  border-radius: 50%; "> </div>
            <div class="list-group-item-heading">Domala Rajamouli</div>
            <span class="list-group-item-text">
            <p>Risus sed vulputate odio ut enim blandit volutpat maecenas volutpat blandit aliquam etiam erat.</p>
            </span>
            <div class="row">
              <div class="col-md-3">
                <p>Rating</p>
              </div>
              <div class="col-md-9" style=" font-size: 22px !important; "> <a href="#"><i class="md md-star-rate"></i></a> <a href="#"><i class="md md-star-rate"></i></a> <a href="#"><i class="md md-star-rate"></i></a> <a href="#"><i class="md md-star-rate"></i></a> <a href="#"><i class="md md-star-rate"></i></a> </div>
            </div>
            <div class="pull-right"> <a title="" data-toggle="tooltip" class="btn btn-round-sm btn-link" target="_blank" href="pages-material-bird.html" data-original-title="Order now"><i class="fa fa-shopping-cart" aria-hidden="true"></i>
              <div class="ripple-wrapper"></div>
              </a> <a title="" data-toggle="tooltip" class="btn btn-round-sm btn-link" target="_blank" href="pages-material-bird.html" data-original-title="Send an enquiry"><i class="fa fa-paper-plane" aria-hidden="true"></i> </a>  </div>
          </div>
          <div class="list-group">
            <div class="list-group-item clearfix" href="#">
              <div class="pull-left m-r-10"> <img src="assets/img/icon_user.png" class="img-responsive" style="  border-radius: 50%; "> </div>
              <div class="list-group-item-heading">Domala Rajamouli</div>
              <span class="list-group-item-text">
              <p>Risus sed vulputate odio ut enim blandit volutpat maecenas volutpat blandit aliquam etiam erat.</p>
              </span>
              <div class="row">
                <div class="col-md-3">
                  <p>Rating</p>
                </div>
                <div class="col-md-9" style=" font-size: 22px !important; "> <a href="#"><i class="md md-star-rate"></i></a> <a href="#"><i class="md md-star-rate"></i></a> <a href="#"><i class="md md-star-rate"></i></a> <a href="#"><i class="md md-star-rate"></i></a> <a href="#"><i class="md md-star-rate"></i></a> </div>
              </div>
              <div class="pull-right"> <a title="" data-toggle="tooltip" class="btn btn-round-sm btn-link" target="_blank" href="pages-material-bird.html" data-original-title="Order now"><i class="fa fa-shopping-cart" aria-hidden="true"></i>
                <div class="ripple-wrapper"></div>
                </a> <a title="" data-toggle="tooltip" class="btn btn-round-sm btn-link" target="_blank" href="pages-material-bird.html" data-original-title="Send an enquiry"><i class="fa fa-paper-plane" aria-hidden="true"></i> </a> 
               </div>
            </div>
          </div>
        </div>
      </div>-->
    </div>
  </div>
</div>
    
    </div>
</section>

<?php include_once 'footer.php'; ?>