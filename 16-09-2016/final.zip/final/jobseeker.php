<?php
include 'header.php'; 

$type=$_GET['type'];
if($type == 'home'){
include 'jobseeker_dashboard.php';
}
else if($type == 'res_tem'){
include 'resume_templates.php';
}
else if($type == 'cwl'){
include 'content_writer_list.php';
}
else if($type == 'my_resumes'){
include 'my_resumes.php';
}
else if($type == 'edit_profile'){
include 'edit_jobseeker.php';
}
else if($type == 'change_password'){
include 'change_password.php';
}
else if($type == 'my_orders'){
include 'my_orders.php';
}
else if($type == 'logout'){
include 'logout.php';
}
include 'footer.php';
?>