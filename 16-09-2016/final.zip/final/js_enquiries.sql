-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 17, 2016 at 06:42 AM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 7.0.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `resume_services_aug1`
--

-- --------------------------------------------------------

--
-- Table structure for table `js_enquiries`
--

CREATE TABLE `js_enquiries` (
  `js_enquiry_id` int(100) NOT NULL,
  `js_jobseeker_name` varchar(100) DEFAULT NULL,
  `js_email_id` varchar(45) DEFAULT NULL,
  `js_phone_no` varchar(45) DEFAULT NULL,
  `js_job_seeker_id` int(100) DEFAULT NULL,
  `js_message` varchar(500) DEFAULT NULL,
  `js_subject` varchar(200) DEFAULT NULL,
  `js_content_writer_id` int(100) DEFAULT NULL,
  `inserted_by` varchar(100) DEFAULT NULL,
  `inserted_date` timestamp NULL DEFAULT NULL,
  `is_read_js` int(3) NOT NULL,
  `is_read_cw` int(100) NOT NULL,
  `is_read_ad` int(100) NOT NULL,
  `is_read_sa` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `js_enquiries`
--

INSERT INTO `js_enquiries` (`js_enquiry_id`, `js_jobseeker_name`, `js_email_id`, `js_phone_no`, `js_job_seeker_id`, `js_message`, `js_subject`, `js_content_writer_id`, `inserted_by`, `inserted_date`, `is_read_js`, `is_read_cw`, `is_read_ad`, `is_read_sa`) VALUES
(1, 'veekshan', 'bten688@gmail.com', NULL, 28, 'how do i know?', 'resume', 4, NULL, NULL, 0, 0, 0, 0),
(2, 'veekshan', 'bten688@gmail.com', NULL, 28, 'hello world', 'hi', 4, NULL, NULL, 0, 0, 0, 0),
(3, 'gvk@123', 'vijayv@gmail.com', NULL, 27, 'Do you know me?????', 'Hi', 4, NULL, NULL, 0, 0, 0, 0),
(4, 'veekshan', 'bten688@gmail.com', NULL, 28, 'gd mrng, how r u??\r\n', 'hi', 5, NULL, NULL, 0, 1, 0, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `js_enquiries`
--
ALTER TABLE `js_enquiries`
  ADD PRIMARY KEY (`js_enquiry_id`),
  ADD KEY `js_enq_job_seeker_id_idx` (`js_job_seeker_id`),
  ADD KEY `js_cw_enq_id_idx` (`js_content_writer_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `js_enquiries`
--
ALTER TABLE `js_enquiries`
  MODIFY `js_enquiry_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `js_enquiries`
--
ALTER TABLE `js_enquiries`
  ADD CONSTRAINT `js_cw_enq_id` FOREIGN KEY (`js_content_writer_id`) REFERENCES `content_writer` (`Content_writer_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `js_job_seeker_enq_id` FOREIGN KEY (`js_job_seeker_id`) REFERENCES `job_seeker` (`Job_Seeker_Id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
