<?php
include_once '../db.php';

include_once 'content_writer_model.php';

$content_writer = new content_writer($db);
?>
<?php include_once 'header.php'; ?>

<div class="clearfix"></div>

<?php
if(isset($_GET['inserted']))
{
	?>
    <div class="container">
	<div class="alert alert-info">
    <strong>Record was inserted successfully..</strong>  
	</div>
	</div>
    <?php
}
else if(isset($_GET['in_failure']))
{
	?>
    <div class="container">
	<div class="alert alert-warning">
    <strong>SORRY!</strong> ERROR while inserting record !
	</div>
	</div>
    <?php
}
?>
<?php
if(isset($_GET['updated']))
{
	?>
    <div class="container">
	<div class="alert alert-info">
    <strong>Record was updated successfully..</strong>  
	</div>
	</div>
    <?php
}
else if(isset($_GET['up_failure']))
{
	?>
    <div class="container">
	<div class="alert alert-warning">
    <strong>SORRY!</strong> ERROR while updating record !
	</div>
	</div>
    <?php
}
?>

<?php
	if(isset($_GET['deleted']))
	{
		?>
        <div class="alert alert-success">
    	<strong>Success!</strong> record was deleted... 
		</div>
        <?php
	}
	
	?>
<div class="clearfix"></div><br />

<div class="main-content" autoscroll="true" bs-affix-target="" init-ripples="" style="">

 	<section class="forms-basic">
        <div class="page-header">
              <h1>      <i class="md md-input"></i>      Create Contentwriter    </h1>
            </div>
        
<div class="well white">
<a href="add_content_writer.php" class="btn btn-large btn-info"><i class="glyphicon glyphicon-plus"></i> &nbsp; Add Content Writers</a>


<div class="clearfix"></div><br />


	 <table class='table table-bordered table-responsive '>
     <tr>
     <th>S.No</th>
     <th>Username</th>
     <th>Email ID</th>
     <th>Experience</th>
     <th>Status</th>
     <th colspan="2" align="center">Actions</th>
     </tr>
     <?php
		$query = "SELECT * FROM content_writer order by Content_writer_id asc";       
		$records_per_page=10;
		$newquery = $content_writer->paging($query,$records_per_page);
		$content_writer->dataview($newquery);
	 ?>
    <tr>
        <td colspan="7" align="center">
 			<div class="pagination-wrap">
            <?php $content_writer->paginglink($query,$records_per_page); ?>
        	</div>
        </td>
    </tr>
 
</table>

       
</div>

<?php //include_once 'footer.php'; ?>