<?php
include_once '../db.php';

include_once 'content_writer_model.php';

$content_writer = new content_writer($db);

include_once 'header.php';
?>
    <div class="main-content" autoscroll="true" bs-affix-target="" init-ripples="" style="">

        <section class="forms-basic">
            <div class="page-header">
                <h1>      <i class="md md-input"></i>  jobseeker Enquiry   </h1>
            </div>
            <div class="well white">
                <table class="table">
                    <thead>
                        <tr>
                            <th>sno</th>
                            <th>Content Writer</th>
                            <th>Jobseeker</th>
                            <th>Query</th>
                            <th>View Conversation</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                    $stmt = $db->prepare('SELECT * FROM js_enquiries order by js_enquiry_id asc');
                $stmt->execute();
                        
                $update = $db->prepare('update js_enquiries set is_read_ad=0 where is_read_ad=1 ');
                $update->execute();
                $i =1;
                if ($stmt->rowCount() > 0):

                while($row=$stmt->fetch(PDO::FETCH_ASSOC)):
                
                     ?>
                            <tr>
                                <td>
                                    <?php echo $i ?>
                                </td>
                                <td>
                                    <?php $stmtcw = $db->prepare("SELECT * FROM content_writer WHERE Content_writer_id='".$row['js_content_writer_id']."'"); $stmtcw->execute();$cw=$stmtcw->fetch(PDO::FETCH_ASSOC);
                                    echo $cw['First_name']; ?>
                                </td>
                                <td>
                                    <?php echo $row['js_jobseeker_name']; ?>
                                </td>
                                <td>
                                    <?php echo $row['js_message']; ?>
                                </td>
                                <?php $count = $db->prepare('SELECT * FROM js_enquiries where js_enquiry_id="'.$row['js_enquiry_id'].'" and is_read_ad=1'); $count->execute(); ?>
                                    <td><a href="administrator.php?type=ed&n=<?php echo $row['js_enquiry_id'] ?>">view(<?php echo $count->rowCount(); ?>)</a></td>
                            </tr>

                            <?php
                        $i++;
                    endwhile;
                    endif;
                    ?>
                    </tbody>
                </table>


            </div>

        </section>
    </div>
