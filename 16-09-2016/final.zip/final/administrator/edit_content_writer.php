<?php
include_once '../db.php';


include_once 'content_writer_model.php';

$content_writer = new content_writer($db);

if(isset($_POST['btn-update']))
{
	$id = $_GET['edit_id'];
	$First_name = $_POST['First_name'];
	$Last_name = $_POST['Last_name'];
	$Email_id = $_POST['Email_id'];
	$User_name = $_POST['User_name'];
	$Password = $_POST['Password'];
	$Confirm_password = $_POST['Confirm_password'];
	$Gender = $_POST['Gender'];
	$Alternate_email = $_POST['Alternate_email'];
	$Phone_No = $_POST['Phone_No'];
	$Address = $_POST['Address'];
	$Experience = $_POST['Experience'];
	$Domain = $_POST['Domain'];
	$Profile_summary = $_POST['Profile_summary'];
	
	if($content_writer->update($id,$First_name,$Last_name,$Email_id,$User_name,$Password,$Confirm_password,$Gender,$Alternate_email,$Phone_No,$Address,$Experience,$Domain,$Profile_summary))
	{
		
		header("Location: content_writer_master.php?updated");
		
	}
	else
	{
		$msg = "<div class='alert alert-warning'>
				<strong>SORRY!</strong> ERROR while updating record !
				</div>";
	}
}

if(isset($_GET['edit_id']))
{
	$id = $_GET['edit_id'];
	extract($content_writer->getID($id));	
}

?>
<?php include_once 'header.php'; ?>

<div class="clearfix"></div>

<div class="container">
<?php
if(isset($msg))
{
	echo $msg;
}
?>
</div>

<div class="clearfix"></div><br />

<div class="container">
	 
     <form method='post'>
 
    <table class='table table-bordered'>
 
        <tr>
            <td>First Name</td>
            <td><input type='text' name='First_name' class='form-control' value="<?php echo $First_name; ?>" required></td>
       
            <td>Last Name</td>
            <td><input type='text' name='Last_name' class='form-control' value="<?php echo $Last_name; ?>" required></td>
        </tr>
 
        <tr>
            <td>E-mail ID</td>
            <td><input type='email' name='Email_id' class='form-control' value="<?php echo $Email_id; ?>" required></td>
       
            <td>User name</td>
            <td><input type='text' name='User_name' class='form-control' value="<?php echo $User_name; ?>" required></td>
        </tr>
 
        <tr>
            <td>Password</td>
            <td><input type='password' name='Password' class='form-control' value="<?php echo $Password; ?>" required></td>
        
            <td>Confirm Password </td>
            <td><input type='password' name='Confirm_password' class='form-control' value="<?php echo $Confirm_password; ?>" required></td>
        </tr>
 		<tr>
            <td>Contact No</td>
            <td><input type='text' name='Phone_No' class='form-control' value="<?php echo $Phone_No; ?>" required></td>
       
            <td>Alternate Email</td>
            <td><input type='email' name='Alternate_email' class='form-control' value="<?php echo $Alternate_email; ?>" required></td>
        </tr>
 		<tr>
            <td>Gender</td>
			<td><input type="radio" class="" name="Gender" value="M" <?php if($Gender=="M") { echo "checked"; } ?> placeholder="">Male
			<input type="radio" class="" name="Gender" value="F" <?php if($Gender=="F") { echo "checked"; }  ?>  placeholder="">Female</td>
   
       
            <td>Address</td>
            <td><textarea name='Address' class='form-control'  ><?php echo $Address; ?></textarea></td>
        </tr>
 		<tr>
            
            <td>Experience</td>
            <td><select name='Experience' class='form-control' value="<?php echo $Experience; ?>" required>
			<option value="<?php echo $Experience; ?>"><?php echo $Experience; ?></option>
			<option value="1">1</option>
			<option value="2">2</option>
			<option value="3">3 </option>
			<option value="5">5 </option>
			<option value="7">7 </option>
			<option value="9">9 </option>
			<option value="12">12 </option>
			<option value="15<">More than 15</option></select>
		 </td>
     
            <td>Domain</td>
            <td><input type='text' name='Domain' class='form-control' value="<?php echo $Domain; ?>" required></td>
        </tr>
 <tr><td>Profile Summary</td>
		<td><textarea class='form-control' name="Profile_summary"><?php echo $Profile_summary; ?></textarea></td></tr>
        <tr>
            <td colspan="2">
                <button type="submit" class="btn btn-primary" name="btn-update">
    			<span class="glyphicon glyphicon-edit"></span>  Update
				</button>
                <a href="content_writer_master.php" class="btn btn-large btn-success"><i class="glyphicon glyphicon-backward"></i> &nbsp; CANCEL</a>
            </td>
        </tr>
 
    </table>
</form>
     
     
</div>

<?php include_once 'footer.php'; ?>