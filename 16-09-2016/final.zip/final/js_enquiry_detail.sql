-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 17, 2016 at 06:42 AM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 7.0.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `resume_services_aug1`
--

-- --------------------------------------------------------

--
-- Table structure for table `js_enquiry_detail`
--

CREATE TABLE `js_enquiry_detail` (
  `js_enquiry_details_id` int(100) NOT NULL,
  `js_enquiry_id` int(100) NOT NULL,
  `js_sender` int(100) NOT NULL,
  `js_receiver` int(100) NOT NULL,
  `js_message` varchar(100) NOT NULL,
  `is_read` int(100) NOT NULL,
  `is_read_ad` int(100) NOT NULL,
  `is_read_sa` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `js_enquiry_detail`
--

INSERT INTO `js_enquiry_detail` (`js_enquiry_details_id`, `js_enquiry_id`, `js_sender`, `js_receiver`, `js_message`, `is_read`, `is_read_ad`, `is_read_sa`) VALUES
(1, 1, 4, 28, 'aaedadfsadfc', 0, 0, 0),
(2, 2, 4, 28, 'adasdcasdc', 0, 0, 0),
(3, 1, 4, 28, 'aksjdxbaedx', 0, 0, 0),
(4, 1, 28, 4, 'asdasd', 0, 0, 0),
(5, 1, 27, 4, 'sdcsdfc', 0, 0, 0),
(6, 3, 4, 27, 'yes i know who you are.........!!', 0, 0, 0),
(7, 3, 27, 4, 'sax', 0, 0, 0),
(8, 1, 4, 28, 'fsdfgdsfgs', 0, 0, 0),
(9, 3, 27, 4, 'hmmmmmmmmmmmmmm', 0, 0, 0),
(10, 3, 27, 4, 'hmmmmmmmmmmmmmm', 0, 0, 0),
(11, 2, 27, 4, 'lakdsmnasldc', 0, 0, 0),
(12, 2, 27, 4, 'alsdmas\r\n', 0, 0, 0),
(13, 2, 27, 4, 'lasdx', 0, 0, 0),
(14, 2, 27, 4, 'sdfwsdfwsdfad', 0, 0, 0),
(15, 2, 27, 4, 'dasfcasdfas', 0, 0, 0),
(16, 2, 27, 4, 'abc', 0, 0, 0),
(17, 2, 27, 4, '', 0, 0, 0),
(18, 2, 27, 4, 'asdcassd', 0, 0, 0),
(19, 1, 4, 28, 'sda', 0, 1, 1),
(20, 1, 28, 4, 'lkjgtlkejlrkj', 1, 1, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `js_enquiry_detail`
--
ALTER TABLE `js_enquiry_detail`
  ADD PRIMARY KEY (`js_enquiry_details_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `js_enquiry_detail`
--
ALTER TABLE `js_enquiry_detail`
  MODIFY `js_enquiry_details_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
