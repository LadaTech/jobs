<?php
include_once '../db.php';

//session_start();
include_once 'jobseeker_model.php';

$jobseeker = new jobseeker($db);
?>


<?php

$stmtje=$db->prepare("SELECT * FROM js_educational_information");
	
$stmtje->execute();
	
$row_js=$stmtje->fetch(PDO::FETCH_ASSOC);

$row = $row_js['js_educational_information_id'];

?>

<?php

if(empty($row)){
if(isset($_POST['btn-add']))
{
	$id = $_GET['edit_id'];
		
	$js_qualification_name = $_POST['profficiency_level'];
	$js_course = $_POST['js_course'];
	$js_institution_name = $_POST['js_institution_name'];
	$js_education_location = $_POST['js_education_location'];
	$js_start_date = $_POST['js_start_date'];
	$js_end_date = $_POST['js_end_date'];
	$js_percentage = $_POST['js_percentage'];
	$js_university = $_POST['js_university'];
	if($jobseeker->Eduction_profile($id, $js_qualification_name, $js_course, $js_institution_name, $js_education_location, $js_start_date,$js_end_date, $js_percentage, $js_university))
	
	{		
		  header("Location: jobseeker_master.php?inserted");		
	
	}
	else
	{
		$msg = "<div class='alert alert-warning'>
				<strong>SORRY!</strong> ERROR while inserted record !
				</div>";
	}
}

}
else {
 if(isset($_POST['btn-add']))
{
	$id = $_GET['edit_id'];
		
	$js_qualification_name = $_POST['profficiency_level'];
	$js_course = $_POST['js_course'];
	$js_institution_name = $_POST['js_institution_name'];
	$js_education_location = $_POST['js_education_location'];
	$js_start_date = $_POST['js_start_date'];
	$js_end_date = $_POST['js_end_date'];
	$js_percentage = $_POST['js_percentage'];
	$js_university = $_POST['js_university'];
	if($jobseeker->Eduction_profile_update($id, $js_qualification_name, $js_course, $js_institution_name, $js_education_location, $js_start_date,$js_end_date, $js_percentage, $js_university))
	{		
		  header("Location: jobseeker_master.php?updated");		
	
	}
	else
	{
		$msg = "<div class='alert alert-warning'>
				<strong>SORRY!</strong> ERROR while updating record !
				</div>";
	}
}
}
if(isset($_GET['edit_id']))
{
	$id = $_GET['edit_id'];
	extract($jobseeker->getID($id));	
}

?>
<?php include_once 'header.php'; ?>

<div class="clearfix"></div>

<div class="container">
<?php
if(isset($msg))
{
	echo $msg;
}   
	
?>
		
</div>

<?php

$stmtje=$db->prepare("SELECT * FROM js_educational_information WHERE job_seeker_id ='".$_SESSION['Job_Seeker_Id']."'");
	
$stmtje->execute();
	
$js=$stmtje->fetch(PDO::FETCH_ASSOC);
?>

<div class="clearfix"></div><br />

<div class="container">
	 
     <form method='post'>
 
    <table class='table table-bordered'>
 
        <tr>
            <td>Education</td>
            <td><select class='form-control' name="profficiency_level" value="<?php echo $js['First_name']; ?>">
           <option value="<?php echo $js['js_qualification_name']; ?>"><?php echo $js['js_qualification_name']; ?></option>
            <option value="Post Graduation">Ph.D</option>
			<option value="Post Graduation">Post Graduation</option>
            <option value="Graduation">Graduation</option>
            <option value="Diploma">Diploma</option>
            <option value="Intermediate">Intermediate</option>
            <option value="SSC">SSC</option>
        </select>
       
            <td>course</td>
            <td><input type='text' name='js_course' class='form-control'  value="<?php echo $js['js_course']; ?>" ></td>
        </tr>
 
        <tr><td>Institution Name</td>
            <td><input type='text' name='js_institution_name' class='form-control'  value="<?php echo $js['js_institution_name']; ?>" ></td>
         <td>Institution Location</td>
            <td><input type='text' name='js_education_location' class='form-control'  value="<?php echo $js['js_education_location']; ?>" ></td> 
			
			
           
            </tr> 
			<tr><td>Start Year</td>
            <td><input type='date' name='js_start_date' class='form-control'  value="<?php echo $js['js_start_date']; ?>" ></td><td>University</td>
            <td><input type='text' name='js_university' class='form-control'  value="<?php echo $js['js_university']; ?>" ></td>
           
            </tr>
			<td>End Year</td>
            <td><input type='date' name='js_end_date' class='form-control' value="<?php echo $js['js_end_date']; ?>" ></td>
        
       <td>% or CGPA</td>
            <td><input type='text' name='js_percentage' class='form-control' value="<?php echo $js['js_percentage']; ?>" ></td>
 		
        <tr>
            <td colspan="2">
                <button type="submit" class="btn btn-primary" name="btn-add">
    			<span class="glyphicon glyphicon-edit"></span>  Submit
				</button>
                <a href="jobseeker_master.php" class="btn btn-large btn-success"><i class="glyphicon glyphicon-backward"></i> &nbsp; CANCEL</a>
            </td>
        </tr>
 
    </table>
</form>
     
     
</div>

<?php include_once 'footer.php'; ?>

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<script type="text/javascript">
var rowCount = 1;
function addMoreRows(frm) {
rowCount ++;
var recRow = '<p id="rowCount'+rowCount+'"><table><tr><td><input name="language_name" type="text" size="17%"  maxlength="120" /></td><td><select name="profficiency_level"  maxlength="120" style="margin: 4px 5px 0 5px;"/></select></td><td><input name="" type="text" maxlength="120" style="margin: 4px 10px 0 0px;"/></td></tr> </table><a href="javascript:void(0);" onclick="removeRow('+rowCount+');">Delete</a></p>';
jQuery('#addedRows').append(recRow);
}

function removeRow(removeNum) {
jQuery('#rowCount'+removeNum).remove();
}
</script>