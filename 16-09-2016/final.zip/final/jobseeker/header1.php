<?php 

session_start();
	
	?>

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Resume Services</title>
<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen"> 
</head>

<body>

<div class="navbar navbar-default navbar-static-top" role="navigation">
    <div class="container">
 
        <div  class="navbar-header" >	
           </div>
 
    <p align="right">
	<?php   echo $_SESSION['User_name']."&emsp;".$_SESSION['Job_Seeker_Id']; ?>
	
	<?php //$id=$_SESSION['Job_Seeker_Id']; ?>
        
		
		
		<a href="logout.php" class="btn btn-info btn-lg">
          <span  class="glyphicon glyphicon-log-out"></span> Log out
        </a>
		
      </p></div>
</div>