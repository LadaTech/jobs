<?php
include_once '../db.php';
include_once 'header.php';
?>
    <style>
        /****** Rating Starts *****/
        
        .rating {
            border: none;
            float: left;
        }
        
        .rating > input {
            display: none;
        }
        
        .rating > label:before {
            margin: 3px;
            font-size: 1.2em;
            font-family: FontAwesome;
            display: inline-block;
            content: "\f005";
        }
        
        .rating > .half:before {
            content: "\f089";
            position: absolute;
        }
        
        .rating > label {
            color: #ddd;
            float: right;
        }
        
        .rating > input:checked ~ label,
        .rating:not(:checked) > label:hover,
        .rating:not(:checked) > label:hover ~ label {
            color: #FFD700;
        }
        
        .rating > input:checked + label:hover,
        .rating > input:checked ~ label:hover,
        .rating > label:hover ~ input:checked ~ label,
        .rating > input:checked ~ label:hover ~ label {
            color: #FFED85;
        }
        /* Downloaded from http://devzone.co.in/ */

    </style>
    <section class="colors">
        <div class="container-fluid">
            <div class="p-10 clearfix">
                <h4 class="grey-text"> <i class="md md-dashboard"></i> <span class="hidden-xs">Notifications</span> </h4>
            </div>
            <div class="well white">
                <?php $rating=NULL; $review =NULL; if(isset($_POST['sb_rating'])) { $rating = $_POST['rating']; $review = $_POST['review']; echo $rating; }?>
                    <form name="ratings" method="post">
                        <fieldset class="rating">
                            <input class="stars" type="radio" id="star5" name="rating" value="5" />
                            <label class="full" for="star5" title="Awesome - 5 stars"></label>
                            <input class="stars" type="radio" id="star4half" name="rating" value="4.5" />
                            <label class="half" for="star4half" title="Pretty good - 4.5 stars"></label>
                            <input class="stars" type="radio" id="star4" name="rating" value="4" />
                            <label class="full" for="star4" title="Pretty good - 4 stars"></label>
                            <input class="stars" type="radio" id="star3half" name="rating" value="3.5" />
                            <label class="half" for="star3half" title="Meh - 3.5 stars"></label>
                            <input class="stars" type="radio" id="star3" name="rating" value="3" />
                            <label class="full" for="star3" title="Meh - 3 stars"></label>
                            <input class="stars" type="radio" id="star2half" name="rating" value="2.5" />
                            <label class="half" for="star2half" title="Kinda bad - 2.5 stars"></label>
                            <input class="stars" type="radio" id="star2" name="rating" value="2" />
                            <label class="full" for="star2" title="Kinda bad - 2 stars"></label>
                            <input class="stars" type="radio" id="star1half" name="rating" value="1.5" />
                            <label class="half" for="star1half" title="Meh - 1.5 stars"></label>
                            <input class="stars" type="radio" id="star1" name="rating" value="1" />
                            <label class="full" for="star1" title="Sucks big time - 1 star"></label>
                            <input class="stars" type="radio" id="starhalf" name="rating" value="0.5" />
                            <label class="half" for="starhalf" title="Sucks big time - 0.5 stars"></label>
                            <input class="stars" type="radio" name="rating" value="0" checked />
                        </fieldset>
                        <input type="text" class="form-control" name="review" />
                        <input type="submit" value="submit" name="sb_rating" />
                    </form>
            </div>
        </div>
    </section>
