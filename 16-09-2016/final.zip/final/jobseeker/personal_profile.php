<?php
include_once '../db.php';

include_once 'jobseeker_model.php';

$jobseeker = new jobseeker($db);

if(isset($_POST['btn-update']))
{
	$id = $_GET['edit_id'];
		
	$Alternate_email = $_POST['Alternate_email'];
	$Alternate_Phone_no = $_POST['Alternate_Phone_no'];
	$Address = $_POST['Address'];
	$Father_Name = $_POST['Father_Name'];
	$language_name = $_POST['language_name'];
	$profficiency_level = $_POST['profficiency_level'];
	$read = $_POST['read'];
	$write = $_POST['write'];
	$speak = $_POST['speak'];
	

	
	if($jobseeker->profile_update($id,$Alternate_email,$Alternate_Phone_no,$Address,$Father_Name))
	
	{		
		  header("Location: jobseeker_master.php?updated");		
	
	}
	else
	{
		$msg = "<div class='alert alert-warning'>
				<strong>SORRY!</strong> ERROR while updating record !
				</div>";
	}
}
if(isset($_POST['btn-update']))
{
	$id = $_GET['edit_id'];

	$language_name = $_POST['language_name'];
	$profficiency_level = $_POST['profficiency_level'];
	$read = $_POST['read'];
	$write = $_POST['write'];
	$speak = $_POST['speak'];
	
	
	
		if($jobseeker->profile_language($language_name,$profficiency_level,$read,$write,$speak,$id))
		{		
		   header("Location: jobseeker_master.php?inserted");		
		}
	
	else
	{
		$msg = "<div class='alert alert-warning'>
				<strong>SORRY!</strong> ERROR while updating record !
				</div>";
	}
}
if(isset($_GET['edit_id']))
{
	$id = $_GET['edit_id'];
	extract($jobseeker->getID($id));	
}

?>
<?php include_once 'header.php'; ?>

<div class="clearfix"></div>

<div class="container">
<?php
if(isset($msg))
{
	echo $msg;
}   
	
?>
		
</div>


<?php 
	// $stmtjs=$db->prepare("SELECT * FROM job_seeker WHERE Job_Seeker_Id='".$_SESSION['Job_Seeker_Id']."'");
	
	// $stmtjs->execute();
	
	// $js=$stmtjs->fetch(PDO::FETCH_ASSOC);
		
	?>
<div class="clearfix"></div><br />
<!--
<div class="container">
	 
     <form method='post'>
 
    <table class='table table-bordered'>
 
        <tr>
            <td>First Name</td>
            <td><input type='text' name='First_name' class='form-control' readonly value="<?php // echo $js['First_name']; ?>" required></td>
       
            <td>Last Name</td>
            <td><input type='text' name='Last_name' class='form-control' readonly value="<?php //echo $js['Last_name']; ?>" required></td>
        </tr>
 
        <tr><td>Contact No</td>
            <td><input type='text' name='Phone_No' class='form-control' readonly value="<?php //echo $js['Phone_No']; ?>" required></td>
        
            <td>E-mail ID</td>
            <td><input type='email' name='Email_id' class='form-control' readonly value="<?php //echo $js['Email_id']; ?>" required></td>
            </tr>
			<tr><td>Contact No(Alternate)</td>
            <td><input type='text' name='Alternate_Phone_no' class='form-control' value="<?php //echo $js['Alternate_Phone_no']; ?>" required></td>
        
            <td>E-mail ID(Alternate)</td>
            <td><input type='email' name='Alternate_email' class='form-control' value="<?php //echo $js['Alternate_email']; ?>" required></td>
            </tr>
 
      
 		
 		<tr>
            <td>Father Name</td>
            <td><input type='text' name='Father_Name' class='form-control' value="<?php //echo $js['Father_Name']; ?>" ></td>
			 <td>Address</td>
            <td><textarea class='form-control' name="Address"><?php //echo $js['Address']; ?>	</textarea>
        </tr>
		<tr id="addedRows"> <td>Languages</td>
            <td><input type='text' name='language_name' class='form-control' value="" ></td>
			
			<td><select class=""  name="profficiency_level">
            <option value="0">select option</option>
            <option value="1">Beginner</option>
            <option value="2">Intermediate</option>
            <option value="3">Expert</option>
            <option value="4">Profossional</option>
        </select>
		
		<input type="checkbox" name="read" value="R" />Read &emsp;
		<input type="checkbox" name="write" value="W" />Write &emsp;
		<input type="checkbox" name="speak" value="S" />Speack  
		</td><td><span style="font:normal 12px agency, arial; color:blue; text-decoration:underline; cursor:pointer;" onclick="addMoreRows(this.form);">
Add More
</span></td>

<div id="addedRows"></div>

		</tr>
 
        <tr>
            <td colspan="2">
                <button type="submit" class="btn btn-primary" name="btn-update">
    			<span class="glyphicon glyphicon-edit"></span>  ADD
				</button>
                <a href="jobseeker_master.php" class="btn btn-large btn-success"><i class="glyphicon glyphicon-backward"></i> &nbsp; CANCEL</a>
            </td>
        </tr>
 
    </table>
</form>
     
   -->  
</div>

<?php include_once 'footer.php'; ?>

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<script type="text/javascript">
var rowCount = 1;
function addMoreRows(frm) {
rowCount ++;
var recRow = '<p id="rowCount'+rowCount+'"><table><tr><td><input name="language_name" type="text" size="17%"  maxlength="120" /></td><td><select name="profficiency_level"  maxlength="120" style="margin: 4px 5px 0 5px;"/></select></td><td><input name="" type="text" maxlength="120" style="margin: 4px 10px 0 0px;"/></td></tr> </table><a href="javascript:void(0);" onclick="removeRow('+rowCount+');">Delete</a></p>';
jQuery('#addedRows').append(recRow);
}

function removeRow(removeNum) {
jQuery('#rowCount'+removeNum).remove();
}
</script>