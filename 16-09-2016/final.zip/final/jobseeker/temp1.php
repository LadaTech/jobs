<script src="templates/slider/js/bootstrap-slider.min.js"></script> 
<script src="templates/summernote/summernote.min.js"></script> 
<script src="templates/Viewer.php"></script> 
<script src="templates/Editor.php"></script> 
<script>



 var temp = Viewer.a15.T6;
 
 alert(temp);
 
</script> 