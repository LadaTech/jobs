<?php
include_once '../db.php';

?>
    <?php include_once 'header.php'; ?>
        <section class="colors">
            <div class="container-fluid">
                <div class="p-10 clearfix">
                    <h4 class="grey-text"> <i class="md md-dashboard"></i> <span class="hidden-xs">Jobseeker List</span> </h4>
                </div>

                <div class="col-md-12">

                    <?php

        $total = $db->query('
        SELECT
            COUNT(*)
        FROM
            job_seeker
    ')->fetchColumn();

    $limit = 6;

    $pages = ceil($total / $limit);

    $page = min($pages, filter_input(INPUT_GET, 'page', FILTER_VALIDATE_INT, array(
        'options' => array(
            'default'   => 1,
            'min_range' => 1,
        ),
    )));

    $offset = ($page - 1)  * $limit;

    $start = $offset + 1;
    $end = min(($offset + $limit), $total);

    $prevlink = ($page > 1) ? '<a href="jobseeker.php?type=cwl&page=1" title="First page">&laquo;</a> <a href="jobseeker.php?type=cwl&page=' . ($page - 1) . '" title="Previous page">&lsaquo;</a>' : '<span class="disabled">&laquo;</span> <span class="disabled">&lsaquo;</span>';

    $nextlink = ($page < $pages) ? '<a href="jobseeker.php?type=cwl&page=' . ($page + 1) . '" title="Next page">&rsaquo;</a> <a href="jobseeker.php?type=cwl&page=' . $pages . '" title="Last page">&raquo;</a>' : '<span class="disabled">&rsaquo;</span> <span class="disabled">&raquo;</span>';

    echo '<div id="paging"><p>', $prevlink, ' Page ', $page, ' of ', $pages, ' pages ', $start, '-', $end, ' of ', $total, ' results ', $nextlink, ' </p></div>';

    $stmt = $db->prepare('
        SELECT
            *
        FROM
            job_seeker        
        LIMIT
            :limit
        OFFSET
            :offset
    ');

    $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
    $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();

    if ($stmt->rowCount() > 0) {
     
        while($row=$stmt->fetch(PDO::FETCH_ASSOC))
        {
            ?>
                        <form method="post">


                            <div class="col-md-4">
                                <div class="card bordered">
                                    <div class="card-header">
                                        <div class="pull-left m-r-10"> <img src="<?php echo $row['Profile_picture_path']; ?>" class="img-responsive" style="  border-radius: 50%; "> </div>
                                        <span class="card-title"><?php echo $row['User_name']; ?></span> </div>
                                    <div class="card-content">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <p>Domain:</p>
                                            </div>
                                            <div class="col-md-6">
                                                <?php echo $row['Domain']; ?>
                                            </div>

                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <p>Template ID:</p>
                                            </div>
                                            <div class="col-md-6"> IT-01 </div>
                                        </div>
                                    </div>
                                    <div class="card-action clearfix">
                                        <div class="pull-left"> <a title="" data-toggle="tooltip" class="btn btn-round-sm btn-link" href="contentwriter.php?type=home&id=<?php echo $row['Job_Seeker_Id']; ?>" data-original-title="View Details"><i class="fa fa-desktop" aria-hidden="true"></i>
                      <div id="id"></div>
            <div class="ripple-wrapper"></div>
            </a> <a title="" data-toggle="tooltip" class="btn btn-round-sm btn-link" target="_blank" href="pages-material-bird.html" data-original-title="Move to Template"><i class="fa fa-arrows" aria-hidden="true"></i> </a> </div>
                                    </div>
                                </div>
                            </div>


                        </form>

                        <?php
            
        }


     }
    
	  ?>

                </div>
            </div>

        </section>
        <?php include_once 'footer.php'; ?>
