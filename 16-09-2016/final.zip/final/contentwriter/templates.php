<?php
include_once '../db.php';

//include_once 'jobseeker_model.php';

//$jobseeker = new jobseeker($db);

?>
<?php include_once 'header.php'; ?>

<section class="colors">
<div class="container-fluid">
<div class="p-10 clearfix">
  <h4 class="grey-text"> <i class="md md-dashboard"></i> <span class="hidden-xs">Templates</span> </h4>
</div>
<div class="col-md-9">
  <div class="card">
    <div style="  padding: 10px; ">
      <div class="row">
        <div class="col-md-3">
          <a href="#"> <img style=" width:100%; height: 100%; border: 1px #ccc solid; " src="assets/img/T1.png"> </a> </div>
        <div class="col-md-3">
          <a href="#"> <img style=" width:100%; height: 100%; border: 1px #ccc solid; " src="assets/img/T2.png"> </a> </div>
          <div class="col-md-3"> <a href="#"> <img style=" width:100%; height: 100%; border: 1px #ccc solid; " src="assets/img/T1.png"> </a> </div>
        <div class="col-md-3"> <a href="#"> <img style=" width:100%; height: 100%; border: 1px #ccc solid; " src="assets/img/T2.png"> </a> </div>
      
      </div>
        
    </div>
    <div style="  padding: 10px; ">
      <div class="row">
        <div class="col-md-3">
          <a href="#"> <img style=" width:100%; height: 100%; border: 1px #ccc solid; " src="assets/img/T1.png"> </a> </div>
        <div class="col-md-3">
          <a href="#"> <img style=" width:100%; height: 100%; border: 1px #ccc solid; " src="assets/img/T2.png"> </a> </div>
          <div class="col-md-3"> <a href="#"> <img style=" width:100%; height: 100%; border: 1px #ccc solid; " src="assets/img/T1.png"> </a> </div>
        <div class="col-md-3"> <a href="#"> <img style=" width:100%; height: 100%; border: 1px #ccc solid; " src="assets/img/T2.png"> </a> </div>
      
      </div>
        
    </div>
   
  </div>
</div>
<div class="col-md-3">
  <div class="card">
    <div class="card-header relative">
      <div class="card-title"> Jobseekers</div>
    </div>
    <div class="list-group">
	<?php

$stmtje=$db->prepare("SELECT * FROM job_seeker LIMIT 4");
	
$stmtje->execute();
//	$i=1;
while($row=$stmtje->fetch(PDO::FETCH_ASSOC))
			{
?>
	<form method="post">
	
      <div class="list-group-item clearfix" href="#">
        <div class="pull-left m-r-10"> <img src="<?php echo $row['Profile_picture_path']; ?>" class="img-responsive" style="  border-radius: 50%; "> </div>
        <div class="list-group-item-heading"><?php echo $row['User_name']; ?></div>
      
        <span class="list-group-item-text">
        <p><?php echo $row['Profile_summary']; ?></p>
        </span>
        <div class="row">
          <div class="col-md-6">
            <p>Domain:</p>
          </div>
         <div class="col-md-6" > <?php echo $row['Domain']; ?> </div>           
          
        </div>
          
          <div class="row"><div class="col-md-6">
            <p>Template ID:</p>
          </div>
         <div class="col-md-6" > IT-01 </div></div>
          <div class="row">
          <div class="pull-left"> <a title="" data-toggle="tooltip" class="btn btn-round-sm btn-link" href="contentwriter.php?type=home&id=<?php echo $row['Job_Seeker_Id']; ?>" data-original-title="View Details"><i class="fa fa-desktop" aria-hidden="true"></i>
            <div class="ripple-wrapper"></div>
            </a> <a title="" data-toggle="tooltip" class="btn btn-round-sm btn-link" target="_blank" href="pages-material-bird.html" data-original-title="Move to Template"><i class="fa fa-arrows" aria-hidden="true"></i> </a>  </div> 
          </div>
      </div>
	  </form>
			<?php 
  // $i=$i+1;
     }

	  ?>
  
    </div>
  </div>
</div>
    </div>
</section>

<?php include_once 'footer.php'; ?>