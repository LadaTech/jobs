<!DOCTYPE html><?php error_reporting(E_ERROR); ?>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="">
<meta name="author" content="">
<title>Resume Services</title>

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!--[if lt IE 9]>  <script src="//oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>  <script src="//oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>  <![endif]-->
<link href="assets/css/vendors.min.css" rel="stylesheet">
<link href="assets/css/styles.min.css" rel="stylesheet">
<script charset="utf-8" src="//maps.google.com/maps/api/js?sensor=true"></script>
<style type="text/css">
.full { width: 100% !important; }
.circle-mask { background-image: url(assets/img/icon_user.png); background-repeat: no-repeat; background-size: 96px auto; border-radius: 50%; display: block; height: 96px; margin-bottom: 10px; margin-left: auto; margin-right: auto; overflow: hidden; transition: opacity 0.075s ease 0s; width: 96px; z-index: 100; }
#canvas { opacity: 0.01; transition: opacity 0.075s ease 0s; }
.circle { background-position: center center; background-repeat: no-repeat; border-radius: 50%; height: 96px; opacity: 0.99; overflow: hidden; position: absolute; width: 96px; z-index: 101; }
.header { background: #7ed1f6; width: 100%; border-bottom: 1px solid #001291; }
h1 { font-size: 21px !important; padding-top: 10px !important; margin-top: 0PX !important; }
.footer { position: fixed; bottom: 0px; left: 0px;  background: #f4f4f4 none repeat scroll 0 0; border-top: 1px solid #cccccc; line-height: 25px; padding: 0 20px;  width: 100%; }
.card .card-header { padding: 10px !important; }
</style>
</head>
<body init-ripples="">
<div class="container-fluid header">
  <div class="navbar-header pull-left">
    <h1>Resume Services</h1>
  </div>
</div>
<div class="center" style="margin:2% auto;">
  <div class="card bordered z-depth-2" style="margin:0% auto; max-width:400px;">
    <div class="card-header">
      <div class="brand-logo">
        <h2> Login</h2>
      </div>
    </div>
    <div class="card-content">
      <div class="m-b-30">
        <div style="" class="circle-mask">
          <canvas height="96" width="96" class="circle" id="canvas"></canvas>
        </div>
      </div>
      <form class="form-floating"  name="login" action="login_process.php" method="post" role="">
	  
			<div class="clearfix"></div>

			<?php
			if(isset($_GET['inserted']))
			{
			?>
			<div class="">
			<div class="alert alert-info">
			<strong>Record was inserted successfully..</strong>  
			</div>
			</div>
			<?php
			}
			else if(isset($_GET['in_failure']))
			{
			?>
			<div class="">
			<div class="alert alert-warning">
			<strong>SORRY!</strong> ERROR while inserting record !
			</div>
			</div>
			<?php
			}
			?>
			<div class="clearfix"></div>
	  
	  
	  
	  
	  
	  
	  
	  
        <div class="form-group">
          <label for="uname" class="control-label">Email</label>
          <input name="uname" type="text" class="form-control">
        </div>
        <div class="form-group">
          <label for="pwd" class="control-label">Password</label>
          <input name="pwd" type="password" class="form-control" id="inputPassword">
        </div>
		<div class="form-group">
		
		
		<?php // To display Login Error messages
		
		
		
		if(isset($_GET['err'])){
		$ut=$_GET['ut'];
		if ($_GET['err']==1){
		if($ut == 'sa'){
		echo "<span style=\"color:#FF0000\">Invalid Super Admin Credentials</span>";
		}
		else if($ut == 'ad'){
		echo "<span style=\"color:#FF0000\">Invalid Admin Credentials</span>";
		}
		else if($ut == 'cw'){
		echo "<span style=\"color:#FF0000\">Invalid Content Writer Credentials</span>";
		}
		else if($ut == 'js'){
		echo "<span style=\"color:#FF0000\">Invalid Job Seeker Credentials</span>";
		}
		}
		else if ($_GET['err']==2){
		echo "<span style=\"color:#FF0000\">Your trying to access un authorized login credentials</span>";
		}
		}
		?>
		
		
		</div>
		
        <input type="submit" value="Login" class="btn btn-success btn-flat-borde full"></button>
        <!--<div class="form-group">
              <div class="checkbox">
                <label>
                  <input type="checkbox"> Remember me </label>
              </div>
            </div>-->
      </form>
    </div>
    <div class="card-action clearfix">
	 <div class="pull-left">
      <a href="jobseeker/register_jobseeker.php">
        <button type="button"  class="btn btn-link black-text">JobSeeker Register</button>
       </a>  </div>
      <div class="pull-right">
      <a href="forgot-password.html">
        <button type="button"  class="btn btn-link black-text">Forgot password</button>
       </a> 
      </div>
   
  </div>
</div>
<div class="container-fluid footer">
  <div class="pull-left"> <a href="http://virtuelltech.com/">virtuelltech</a> © 2016. </div>
  <div class="pull-right"> Powered by <a href="http://virtuelltech.com/">virtuelltech</a> </div>
</div>
<script charset="utf-8" src="assets\js\vendors.min.js"></script> 
<script charset="utf-8" src="assets\js\app.min.js"></script>
</body>
</html>