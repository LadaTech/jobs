<!DOCTYPE html>

<?php 
ob_start(); 
//error_reporting(0); 
include_once '../db.php'; 
include_once 'jobseeker_model.php'; 
$jobseeker = new jobseeker($db);
	
 ?>


    </div>
    <!-- End Top Background Image Wrapper -->
    <?php 
 if(isset($_POST['pd_sub']))
{
	$id = $_SESSION['Job_Seeker_Id'];
		
	$Alternate_email = $_POST['Alternate_email'];
	$Alternate_Phone_no = $_POST['Alternate_Phone_no'];
	$Address = $_POST['Address'];
	$Father_Name = $_POST['Father_Name'];
	
	
	$language_name = $_POST['language_name'];
	$profficiency_level = $_POST['profficiency_level'];
	$read = $_POST['read1'];
	$write = $_POST['write2'];
	$speak = $_POST['speak3'];
     
     if($jobseeker->profile_update($id,$Alternate_email,$Alternate_Phone_no,$Address,$Father_Name,$language_name,$profficiency_level,$read,$write,$speak))	
	{		
	
		 $msg = "<div class='alert alert-warning'>
				<strong>your Personal Details Inserted Sucessfully...</strong>
				</div>";
				
	
	}
	else
	{
			$msg = "<div class='alert alert-warning'>
				<strong>your Personal Details Inserted Sucessfully...</strong>
				</div>";	
	
	}
	
 }



	?>
        <div class="wrapper row3">
            <main class="hoc container clear">

                <div class="group demo">
                    <div class="one_quarter first">
                        <h3>Resume Templates</h3>
                        <div style="  padding: 10px; ">


                            <div class="row">
                                <div class="col-md-6">
                                    <p>Fresher</p>
                                    <a href="#"> <img style=" width:100%; height: 150px; border: 1px #ccc solid; " src="templates\img\templates/T1.png"> </a>
                                </div>
                                <div class="col-md-6">
                                    <p>Experience</p>
                                    <a href="#"> <img style=" width:100%; height: 150px; border: 1px #ccc solid; " src="templates\img\templates/T2.png"> </a>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <p>Fresher</p>
                                    <a href="#"> <img style=" width:100%; height: 150px; border: 1px #ccc solid; " src="templates\img\templates/T5.png"> </a>
                                </div>
                                <div class="col-md-6">
                                    <p>Experience</p>
                                    <a href="#"> <img style=" width:100%; height: 150px; border: 1px #ccc solid; " src="templates\img\templates/T9.png"> </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="two_quarter">
                        <h3>Details</h3>
                        <!-- Accordion begin -->
                        <ul class="accordion_example">


                            <li>
                                <div>Personal Details</div>
                                <!-- Head -->
                                <div>
                                    <?php $stmtjs=$db->prepare("SELECT * FROM job_seeker WHERE Job_Seeker_Id='".$_SESSION['Job_Seeker_Id']."'");
	//'".$_SESSION['Job_Seeker_Id']."'
	$stmtjs->execute();
	
	$js=$stmtjs->fetch(PDO::FETCH_ASSOC); ?>
                                        <form id="form1" name="pd_sub" method="post" action="" class="form-floating" novalidate>
                                            <div class="col-md-6">

                                                <fieldset>
                                                    <div class="form-group">
                                                        <label class="control-label">First Name </label>
                                                        <input type="text" name='First_name' class='form-control' readonly value="<?php echo $js['First_name']; ?>">
                                                        <div class="help-block with-errors"></div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label class="control-label">Mobile Number </label>
                                                        <input type="text" required name='Phone_No' class='form-control' readonly value="<?php echo $js['Phone_No']; ?>">
                                                        <div class="help-block with-errors"></div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label class="control-label">Mobile Number (Alternate) </label>
                                                        <input type="text" name='Alternate_Phone_no' class='form-control' value="<?php echo $js['Alternate_Phone_no']; ?>" required>
                                                        <div class="help-block with-errors"></div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label id="req_1" class="required control-label">Father Name </label>
                                                        <input type='text' name='Father_Name' class='form-control' value="<?php echo $js['Father_Name']; ?>" required>
                                                        <div class="help-block with-errors"></div>
                                                    </div>
                                                </fieldset>

                                            </div>
                                            <div class="col-md-6">

                                                <fieldset>
                                                    <div class="form-group">
                                                        <label class="control-label">Last Name </label>
                                                        <input type="text" data-error="This field is First Name " name='Last_name' class='form-control' readonly value="<?php echo $js['Last_name']; ?>">
                                                        <div class="help-block with-errors"></div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label class="control-label">Email ID </label>
                                                        <input type="email" data-error="That email address is invalid" required name='Email_id' class='form-control' readonly value="<?php echo $js['Email_id']; ?>">
                                                        <div class="help-block with-errors"></div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label class="control-label">Email ID (Alternate) </label>
                                                        <input type='email' name='Alternate_email' class='form-control' value="<?php echo $js['Alternate_email']; ?>" data-error="This field is required">
                                                        <div class="help-block with-errors"></div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label class="control-label">Address</label>
                                                        <textarea class='form-control vertical' id="textArea" rows="1" name="Address">
                                                            <?php echo $js['Address']; ?>
                                                        </textarea>
                                                        <div class="help-block with-errors"></div>
                                                    </div>
                                                </fieldset>

                                            </div>

                                            <div class="col-md-12">
                                                <h5> Language Name </h5>
                                                <div class="col-md-8">
                                                    <div class="form-group">
                                                        <input type="text" name="language_name" data-error="This field is required" value="<?php echo $js['language_name']; ?>" required class="form-control">
                                                    </div>
                                                    <div class="form-group ">
                                                        <label class="control-label">profficiency level</label>
                                                        <select id="select_1" data-error="This field is required" required name="profficiency_level" class="form-control">
                                                            <option value="<?php echo $js['profficiency_level']; ?>">
                                                                <?php echo $js['profficiency_level']; ?>
                                                            </option>
                                                            <option value="Beginner">Beginner</option>
                                                            <option value="Intermediate">Intermediate</option>
                                                            <option value="Expert">Expert</option>
                                                            <option value="Profossional">Profossional</option>
                                                        </select>
                                                        <div class="help-block with-errors"></div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <div class="checkbox">
                                                            <label>
                                                                <input type="checkbox" name="read1" value="R" <?php if($js[ 'lan_read']=="R" ) { echo "checked"; } ?> > Read </label>
                                                        </div>
                                                        <div class="checkbox">
                                                            <label>
                                                                <input type="checkbox" name="write2" value="W" <?php if($js[ 'lan_write']=="W" ) { echo "checked"; } ?> > Write </label>
                                                        </div>
                                                        <div class="checkbox">
                                                            <label>
                                                                <input type="checkbox" name="speak3" value="S" <?php if($js[ 'lan_speak']=="S" ) { echo "checked"; } ?> > Speak </label>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="" id='lan_row'>
                                                    <div data-toggle="tooltip" data-title="Add Language" class="btn btn-primary btn-round btn-lg" data-original-title="" title="" id="add_lan"><i class="md md-add"></i>
                                                        <div class="ripple-wrapper"></div>
                                                    </div>
                                                    <div id='delete_lan' data-toggle="tooltip" data-title="Delete" class="btn btn-primary btn-round btn-lg m-r-10 " data-original-title="" title=""><i class="md md-delete"></i></div>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <button class="btn btn-primary" href="" name="pd_sub" type="submit">Save
                                                        <div class="ripple-wrapper"></div>
                                                    </button>
                                                    <button class="btn btn-default" type="reset">Cancel</button>
                                                </div>
                                            </div>

                                        </form>

                                </div>
                            </li>

                            <li>
                                <div>Educatonal Details</div>
                                <!-- Head -->

                                <?php // Educational information php functionality....
 
$stmtje=$db->prepare("SELECT * FROM js_educational_information");
	
$stmtje->execute();
	
$row_js=$stmtje->fetch(PDO::FETCH_ASSOC);

$row = $row_js['js_educational_information_id'];
 
if(empty($row)){
if(isset($_POST['edu_sub']))
{
	$id = $_SESSION['Job_Seeker_Id'];
		
	$js_qualification_name = $_POST['profficiency_level'];
	$js_course = $_POST['js_course'];
	$js_institution_name = $_POST['js_institution_name'];
	//$js_education_location = $_POST['js_education_location'];
	$js_start_date = $_POST['js_start_date'];
	$js_end_date = $_POST['js_end_date'];
	$js_percentage = $_POST['js_percentage'];
	//$js_university = $_POST['js_university'];
	if($jobseeker->Eduction_profile($id, $js_qualification_name, $js_course, $js_institution_name, $js_start_date,$js_end_date, $js_percentage))
	
	{		header("Location: jobseeker.php?type=home");		
	
	}
	else
	{
		$msg = "<div class='alert alert-warning'>
				<strong>SORRY!</strong> ERROR while inserted record !
				</div>";
	}
}

}
else {
 if(isset($_POST['edu_sub']))
{
	$id = $_SESSION['Job_Seeker_Id'];
		
	$js_qualification_name = $_POST['profficiency_level'];
	$js_course = $_POST['js_course'];
	$js_institution_name = $_POST['js_institution_name'];
	//$js_education_location = $_POST['js_education_location'];
	$js_start_date = $_POST['js_start_date'];
	$js_end_date = $_POST['js_end_date'];
	$js_percentage = $_POST['js_percentage'];
	//$js_university = $_POST['js_university'];
	if($jobseeker->Eduction_profile_update($id, $js_qualification_name, $js_course, $js_institution_name, $js_start_date,$js_end_date, $js_percentage))
	{	
		header("Location: jobseeker.php?type=home");		
	}
	else
	{
		$msg = "<div class='alert alert-warning'>
				<strong>SORRY!</strong> ERROR while updating record !
				</div>";
	}
}
}


$stmtje=$db->prepare("SELECT * FROM js_educational_information WHERE job_seeker_id ='".$_SESSION['Job_Seeker_Id']."'");
	
$stmtje->execute();
	
$js=$stmtje->fetch(PDO::FETCH_ASSOC);
?>
                                    <div>
                                        <div class="row">
                                            <form name="edu_sub" id="form-validation" action="" method='post' class="form-floating" novalidate>
                                                <div class="col-md-12">
                                                    <div class="form-group ">
                                                        <label class="control-label">Choose Education</label>
                                                        <select class='form-control' name="profficiency_level" value="<?php echo $js['profficiency_level']; ?>">
                                                            <option value="<?php echo $js['js_qualification_name']; ?>">
                                                                <?php echo $js['js_qualification_name']; ?>
                                                            </option>
                                                            <option value="Post Graduation">Ph.D</option>
                                                            <option value="Post Graduation">Post Graduation</option>
                                                            <option value="Graduation">Graduation</option>
                                                            <option value="Diploma">Diploma</option>
                                                            <option value="Intermediate">Intermediate</option>
                                                            <option value="SSC">SSC</option>
                                                        </select>
                                                        <div class="help-block with-errors"></div>
                                                    </div>
                                                </div>

                                                <div class="col-md-6">

                                                    <fieldset>
                                                        <div class="form-group">
                                                            <label class="control-label">Course</label>
                                                            <input type="text" data-error="This field is First Name " name='js_course' class='form-control' value="<?php echo $js['js_course']; ?>">
                                                            <div class="help-block with-errors"></div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label class="control-label">Start Year </label>
                                                            <input type='date' name='js_start_date' class='form-control' value="<?php echo $js['js_start_date']; ?>" data-error="That email address is invalid" required>
                                                            <div class="help-block with-errors"></div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label class="control-label">% or CGPA </label>
                                                            <input type='text' name='js_percentage' class='form-control' value="<?php echo $js['js_percentage']; ?>">
                                                            <div class="help-block with-errors"></div>
                                                        </div>
                                                    </fieldset>

                                                </div>
                                                <div class="col-md-6">

                                                    <fieldset>
                                                        <div class="form-group">
                                                            <label class="control-label">Institute Name </label>
                                                            <input type="text" data-error="This field is First Name " required name='js_institution_name' class='form-control' value="<?php echo $js['js_institution_name']; ?>">
                                                            <div class="help-block with-errors"></div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label class="control-label">End Year</label>
                                                            <input type='date' name='js_end_date' class='form-control' value="<?php echo $js['js_end_date']; ?>" data-error="That email address is invalid" required>
                                                            <div class="help-block with-errors"></div>
                                                        </div>

                                                    </fieldset>

                                                </div>
                                                <div class="col-md-6" id='edu_row'>

                                                    <fieldset>
                                                        <div class="form-group">
                                                            <div class="">
                                                                <div data-toggle="tooltip" data-title="New Item" class="btn btn-primary btn-round btn-lg" data-original-title="" title="" id="add_education"><i class="md md-add"></i>
                                                                    <div class="ripple-wrapper"></div>
                                                                </div>
                                                                <div data-toggle="tooltip" data-title="Remove 0 item(s)" class="btn btn-primary btn-round btn-lg m-r-10 " data-original-title="" title="" id="del_education"><i class="md md-delete"></i></div>
                                                            </div>
                                                        </div>
                                                    </fieldset>

                                                </div>
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <button class="btn btn-primary" href="" name="edu_sub" type="submit">Save
                                                            <div class="ripple-wrapper"></div>
                                                        </button>
                                                        <button class="btn btn-default" type="reset">Cancel</button>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>

                                    </div>
                            </li>

                            <li>
                                <div>Work Experiance</div>
                                <!-- Head -->
                                <div>
                                    <?php
$stmtje=$db->prepare("SELECT * FROM  js_work_experience WHERE Job_Seeker_Id ='".$_SESSION['Job_Seeker_Id']."'");
	
$stmtje->execute();
	
$js=$stmtje->fetch(PDO::FETCH_ASSOC);

$row = $js['Company_Name'];

if(empty($row)){
if(isset($_POST['exp_sub']))
{
	
	$id = $_SESSION['Job_Seeker_Id'];	
	$Company_Name = $_POST['Company_Name'];
	$Company_Name_count = sizeof($Company_Name);
	$Designation = $_POST['Designation'];
	$Start_date = $_POST['Start_date'];
	$End_date = $_POST['End_date'];
	$Current_CTC = $_POST['Current_CTC'];
	$Expected_CTC = $_POST['Expected_CTC'];
	for($j=0;$j<$Company_Name_count;$j++){
	 if($jobseeker->Experience_profile($id,$Company_Name[$j],$Designation[$j],$Start_date[$j],$End_date[$j],$Current_CTC[$j],$Expected_CTC[$j]))
	{		//echo("add").$Company_Name_count;
		header("Location: jobseeker.php?type=home");		
	}
	else
	{
		$msg = "<div class='alert alert-warning'>
		<strong>SORRY!</strong> ERROR while inserted record !
		</div>";
	}
	 
	}
	
	
	
	
}

}
else {
 if(isset($_POST['exp_sub']))
{
	$id = $_SESSION['Job_Seeker_Id'];
		
	$jswe_id = $_POST['js_work_experience_id'];
	$Company_Name = $_POST['Company_Name'];
	$Company_Name_count = sizeof($Company_Name);
	$Designation = $_POST['Designation'];
	$Start_date = $_POST['Start_date'];
	$End_date = $_POST['End_date'];
	$Current_CTC = $_POST['Current_CTC'];
	$Expected_CTC = $_POST['Expected_CTC'];
	for($j=0;$j<$Company_Name_count;$j++){
	if($jobseeker->Experience_profile_update($id, $jswe_id, $Company_Name[$j], $Designation[$j], $Start_date[$j], $End_date[$j], $Current_CTC[$j], $Expected_CTC[$j]))
	{		
	//	echo("update").$Company_Name_count;
header("Location: jobseeker.php?type=home");			
	
	}
	else
	{
		$msg = "<div class='alert alert-warning'>
				<strong>SORRY!</strong> ERROR while updating record !
				</div>";
	}
	}
}
}

?>


                                        <div>
                                            <div class="row">
                                                <?php

$stmtjl=$db->prepare("SELECT * FROM js_work_experience WHERE Job_Seeker_Id ='".$_SESSION['Job_Seeker_Id']."'");
	
	
$stmtjl->execute();
                                                $js=$stmtjl->fetch(PDO::FETCH_ASSOC);
	// $i=1;

//$js=$stmtjl->fetch(PDO::FETCH_ASSOC);
			
?>
                                                    <form id="form-validation" name="exp_sub" action="" method='post' class="form-floating" novalidate>
                                                        <div class="col-md-6">

                                                            <fieldset>
                                                                <div class="form-group">
                                                                    <label class="control-label">Company Name</label>
                                                                    <input type="hidden" name='js_work_experience_id' value="<?php echo $js['js_work_experience_id']; ?>">
                                                                    <input type="text" data-error="This field is First Name " name='Company_Name[]' class='form-control' value="<?php echo $js['Company_Name']; ?>">
                                                                    <div class="help-block with-errors"></div>
                                                                </div>
                                                                <div class="form-group">
                                                                    <label class="control-label">Designation </label>
                                                                    <input type='text' name='Designation[]' class='form-control' value="<?php echo $js['Designation']; ?>" data-error="That email address is invalid" required>
                                                                    <div class="help-block with-errors"></div>
                                                                </div>
                                                                <div class="form-group">
                                                                    <label class="control-label">Start date </label>
                                                                    <input type='date' name='Start_date[]' class='form-control' value="<?php echo $js['Start_date']; ?>">
                                                                    <div class="help-block with-errors"></div>
                                                                </div>
                                                            </fieldset>

                                                        </div>
                                                        <div class="col-md-6">

                                                            <fieldset>

                                                                <div class="form-group">
                                                                    <label class="control-label">Current CTC</label>
                                                                    <input type='text' name='Current_CTC[]' class='form-control' value="<?php echo $js['Current_CTC']; ?>" data-error="That email address is invalid" required>
                                                                    <div class="help-block with-errors"></div>
                                                                </div>
                                                                <div class="form-group">
                                                                    <label class="control-label">Expected CTC</label>
                                                                    <input type='text' name='Expected_CTC[]' class='form-control' value="<?php echo $js['Expected_CTC']; ?>" data-error="That email address is invalid" required>
                                                                    <div class="help-block with-errors"></div>
                                                                </div>
                                                                <div class="form-group">
                                                                    <label class="control-label">End date</label>
                                                                    <input type='date' name='End_date[]' class='form-control' value="<?php echo $js['End_date']; ?>" data-error="That email address is invalid" required>
                                                                    <div class="help-block with-errors"></div>
                                                                </div>
                                                            </fieldset>
                                                        </div>
                                                        <div class="" id='exp_row'>
                                                            <div id="add_experiance" data-toggle="tooltip" data-title="New Item" class="btn btn-primary btn-round btn-lg" data-original-title="" title=""><i class="md md-add"></i>
                                                                <div class="ripple-wrapper"></div>
                                                            </div>
                                                            <div id="del_experiance" data-toggle="tooltip" data-title="Remove 0 item(s)" class="btn btn-primary btn-round btn-lg m-r-10 " data-original-title="" title=""><i class="md md-delete"></i></div>
                                                        </div>
                                                        </fieldset>


                                                        <div class="col-md-12">
                                                            <div class="form-group">
                                                                <button class="btn btn-primary" name="exp_sub" type="submit">Save
                                                                    <div class="ripple-wrapper"></div>
                                                                </button>
                                                                <button class="btn btn-default" type="reset">Cancel</button>
                                                            </div>
                                                        </div>
                                                    </form>


                                            </div>
                            </li>

                            <li>
                                <div>Skills</div>
                                <!-- Head -->
                                <div>
                                    <?php

                                                $stmtje=$db->prepare("SELECT * FROM js_skills");

                                                $stmtje->execute();

                                                $row_js=$stmtje->fetch(PDO::FETCH_ASSOC);

                                                 $row = $row_js['js_skills_id'];


                                                if(empty($row)){
                                                if(isset($_POST['sk_sub']))
                                                {
                                                    $id = $_SESSION['Job_Seeker_Id'];		
                                                    $js_skill_description = $_POST['js_skill_description'];


                                                    if($jobseeker->skills($id,$js_skill_description))
                                                    {		
                                                          header("Location: jobseeker.php?type=home");	
                                                //exit();		  
                                                    }
                                                    else
                                                    {
                                                        $msg = "<div class='alert alert-warning'>
                                                        <strong>SORRY!</strong> ERROR while inserted record !
                                                        </div>";
                                                    }
                                                }

                                                }
                                                else {
                                                 if(isset($_POST['sk_sub']))
                                                {
                                                    $id = $_SESSION['Job_Seeker_Id'];

                                                    $js_skill_description = $_POST['js_skill_description'];

                                                    if($jobseeker->skills_update($id, $js_skill_description))
                                                    {		
                                                          header("Location: jobseeker.php?type=home");		

                                                    }
                                                    else
                                                    {
                                                        $msg = "<div class='alert alert-warning'>
                                                                <strong>SORRY!</strong> ERROR while updating record !
                                                                </div>";
                                                    }
                                                }
                                                }
                                                ?>
                                        <?php

$stmtje=$db->prepare("SELECT * FROM js_skills WHERE job_seeker_id ='".$_SESSION['Job_Seeker_Id']."'");
	
$stmtje->execute();
	
$js=$stmtje->fetch(PDO::FETCH_ASSOC);
?>
                                            <form id="form-validation" name="sk_sub" class="form-floating" method="post" novalidate>
                                                <fieldset>
                                                    <div class="form-group">
                                                        <label class="control-label">Skills</label>
                                                        <textarea id="textArea" rows="1" name='js_skill_description' class="form-control vertical">
                                                            <?php echo $js['js_skill_description']; ?>
                                                        </textarea>
                                                        <div class="help-block with-errors"></div>
                                                    </div>
                                                    <div class="col-md-12">
                                                        <div class="form-group">
                                                            <button class="btn btn-primary" name="sk_sub" type="submit">Save
                                                                <div class="ripple-wrapper"></div>
                                                            </button>
                                                            <button class="btn btn-default" type="reset">Cancel</button>
                                                        </div>
                                                    </div>
                                                </fieldset>
                                            </form>
                                </div>
                            </li>

                            <li>
                                <div>Objective</div>
                                <!-- Head -->
                                <div>
                                    <?php

                                                    $stmtje=$db->prepare("SELECT * FROM js_carrer_objective");

                                                    $stmtje->execute();

                                                    $row_js=$stmtje->fetch(PDO::FETCH_ASSOC);

                                                     $row = $row_js['carrer_objective_id'];


                                                    if(empty($row)){
                                                    if(isset($_POST['obj_sub']))
                                                    {
                                                        $id = $_SESSION['Job_Seeker_Id'];		
                                                        $career_objective_name = $_POST['career_objective_name'];


                                                        if($jobseeker->Objective($id,$career_objective_name))
                                                        {		
                                                              header("Location: jobseeker.php?type=home");		
                                                        }
                                                        else
                                                        {
                                                            $msg = "<div class='alert alert-warning'>
                                                            <strong>SORRY!</strong> ERROR while inserted record !
                                                            </div>";
                                                        }
                                                    }

                                                    }
                                                    else {
                                                     if(isset($_POST['obj_sub']))
                                                    {
                                                        $id = $_SESSION['Job_Seeker_Id'];

                                                        $career_objective_name = $_POST['career_objective_name'];

                                                        if($jobseeker->Objective_update($id, $career_objective_name))
                                                        {		
                                                              header("Location: jobseeker.php?type=home");		

                                                        }
                                                        else
                                                        {
                                                            $msg = "<div class='alert alert-warning'>
                                                                    <strong>SORRY!</strong> ERROR while updating record !
                                                                    </div>";
                                                        }
                                                    }
                                                    }


                                                    ?>
                                        <?php

                                                                    $stmtje=$db->prepare("SELECT * FROM js_carrer_objective WHERE job_seeker_id ='".$_SESSION['Job_Seeker_Id']."'");

                                                                    $stmtje->execute();

                                                                    $js=$stmtje->fetch(PDO::FETCH_ASSOC);
                                                                    ?>
                                            <form id="form-validation" name="obj_sub" action="" method="post" class="form-floating" novalidate>
                                                <fieldset>
                                                    <div class="form-group">
                                                        <label class="control-label">Objective</label>
                                                        <textarea id="textArea" rows="1" class="form-control vertical" name='career_objective_name'>
                                                            <?php echo $js['career_objective_name']; ?>
                                                        </textarea>
                                                        <div class="help-block with-errors"></div>
                                                    </div>
                                                    <div class="col-md-12">
                                                        <div class="form-group">
                                                            <button class="btn btn-primary" name="obj_sub" type="Save">Save
                                                                <div class="ripple-wrapper"></div>
                                                            </button>
                                                            <button class="btn btn-default" type="reset">Cancel</button>
                                                        </div>
                                                    </div>
                                                </fieldset>
                                            </form>
                                </div>
                            </li>



                        </ul>
                        <!-- Accordion end -->
                        </div>
                        <div class="one_quarter">
                            <h3>Content writers</h3>
                            <?php
                            $stmtje=$db->prepare("SELECT * FROM content_writer LIMIT 1"); $stmtje->execute(); while($row=$stmtje->fetch(PDO::FETCH_ASSOC)) { ?>


                                <article class="material-card Cyan">
                                    <h2>
                    <span><?php echo $row['User_name']; ?></span>
                    <strong>
                        <i class="fa fa-fw fa-star"></i>
                        <i class="fa fa-fw fa-star"></i>
                        <i class="fa fa-fw fa-star"></i>
                        <i class="fa fa-fw fa-star"></i>
                        <i class="fa fa-fw fa-star"></i>
                    </strong>
                </h2>
                                    <div class="mc-content">
                                        <div class="img-container">
                                            <img class="img-responsive" src="https://lh3.googleusercontent.com/-W3E2_6WcwAg/VuEY6f7m3xI/AAAAAAAAABE/YaJ6Bjd3p8EUOxjhA4SYn5wgdbKcvQUrgCL0B/w561-h563-no/11872072_140846389587317_7934122158675082122_o.jpg">
                                        </div>
                                        <div class="mc-description">
                                            <?php echo $row['Profile_summary']; ?>
                                        </div>
                                    </div>
                                    <a class="mc-btn-action">
                                        <i class="fa fa-bars"></i>
                                    </a>
                                    <div class="mc-footer">

                                        <a class="fa fa-fw fa-shopping-cart" href="jobseeker.php?type=order_now&id=<?php echo $row['Content_writer_id']; ?>"></a>
                                        <a class="fa fa-fw fa-paper-plane" href="jobseeker.php?type=ef&n=<?php echo $row['Content_writer_id']; ?>"></a>
                                        <?php $rate = $db->prepare('SELECT * FROM js_enquiries where js_job_seeker_id="'.$_SESSION['Job_Seeker_Id'].'" and js_content_writer_id="'.$row['Content_writer_id'].'"'); $rate->execute(); if($rate->rowCount()!=0): ?>
                                            <a class="fa fa-fw fa-star" href="jobseeker.php?type=r&n=<?php echo $row['Content_writer_id']; ?>"></a>
                                            <?php endif; ?>
                                    </div>
                                </article>


                                <?php 
  // $i=$i+1;
     }
                            
	  ?>
                                    <h4 align="right"><a href="#">more...</a></h4>
                        </div>



                        </div>

                        <!-- / main body -->
                        <div class="clear"></div>
            </main>
            </div>

            <script>
                $(document).ready(function() {
                    //////////////////language////////////////////////////////////////
                    $('#add_lan').click(function() {
                        $('#lan_row').before('<div id="details" class="col-md-12"><h5> Language Name</h5><div class="col-md-8"><div class="form-group"><input type="password" data-error="This field is required" required class="form-control"></div><div class="form-group "><label class="control-label">Beginner</label><select data-error="This field is required" required class="form-control"><option value=""> </option><option value="Select a pirate">Intermediate Level </option><option value="Expert">Expert </option><option value="Roronoa Zoro">Professional </option></select><div class="help-block with-errors"></div></div></div><div class="col-md-4"><div class="form-group"><div class="checkbox"><label><input type="checkbox" required>Read </label></div><div class="checkbox"><label><input type="checkbox" required>Write </label></div><div class="checkbox"><label><input type="checkbox" required>Speak </label></div></div></div></div>'); // Add new one below
                    });

                    $('#delete_lan').click(function() {
                        $('#details').remove();
                    });
                    /////////////////////////education//////////////////////////////
                    $('#add_education').click(function() {
                        $('#edu_row').before('<div id="edu_details"><div class="col-md-12"><div class="form-group"><label class="control-label">Choose Education</label><select class="form-control" name="profficiency_level[]" value=""><option value=""></option><option value="Post Graduation">Ph.D</option><option value="Post Graduation">Post Graduation</option><option value="Graduation">Graduation</option> <option value="Diploma">Diploma</option><option  value="Intermediate">Intermediate</option><option value="SSC">SSC</option> </select><div class="help-block with-errors"></div></div></div><div class="col-md-6"><fieldset><div class="form-group"><label class="control-label">Course</label><input data-error="This field is First Name " name="js_course[]" class="form-control" value="" type="text"><div class="help-block with-errors"></div></div><div class="form-group"><label class="control-label">Start Year </label><input name="js_start_date[]" class="form-control" value="" data-error="That email address is invalid" required="" type="date"><div class="help-block with-errors"></div></div><div class="form-group"> <label class="control-label">% or CGPA </label><input name="js_percentage[]" class="form-control" value="" type="text"> <div class="help-block with-errors"></div></div></fieldset></div><div class="col-md-6"> <fieldset><div class="form-group"><label class="control-label">Institute Name </label><input data-error="This field is First Name " required="" name="js_institution_name[]" class="form-control" value="" "="" type="text"><div class="help-block with-errors"></div><div class="form-group"><label class="control-label">End Year</label><input name="js_end_date[]" class="form-control" value="" data-error="That email address is invalid" required="" type="date"><div class="help-block with-errors"></div></div></div></fieldset></div></div>'); // Add new one below
                    });
                    $('#del_education').click(function() {
                        $('#edu_details').remove();
                    });

                    /////////////////////////////////////////////////////////////////
                    ///////////////////////experience/////////////////////////////////vvv
                    $('#add_experiance').click(function() {

                        $('#exp_row').before('<div id="exp_details"><div class="col-md-6"><fieldset><div class="form-group"><label class="control-label">Company Name</label><input data-error="This field is First Name " name="Company_Name[]" class="form-control" value="" type="text"><div class="help-block with-errors"></div></div><div class="form-group"><label class="control-label">Designation </label><input name="Designation" class="form-control" value="" data-error="That email address is invalid" required="" type="text"><div class="help-block with-errors"></div></div><div class="form-group"><label class="control-label">Start date </label><input name="Start_date" class="form-control" value="" type="date"><div class="help-block with-errors"></div></div></fieldset></div><div class="col-md-6"><fieldset><div class="form-group"><label class="control-label">Current CTC</label><input name="Current_CTC" class="form-control" value="" data-error="That email address is invalid" required="" type="text"><div class="help-block with-errors"></div></div> <div class="form-group"><label class="control-label">Expected CTC</label><input name="Expected_CTC" class="form-control" value="" data-error="That email address is invalid" required="" type="text"><div class="help-block with-errors"></div></div><div class="form-group"><label class="control-label">End date</label><input name="End_date" class="form-control" value="" data-error="That email address is invalid" required="" type="date"><div class="help-block with-errors"></div></div></fieldset></div></div></div>'); // Add new one below
                    });

                    $('#del_experiance').click(function() {
                        $('#exp_details').remove();
                    });
                    //////////////////////////////////////////////////////////////////
                });

            </script>
