<?php
include 'header.php'; 

$type=$_GET['type'];
if($type == 'home'){
    include 'jobseeker_dashboard.php';
}
else if($type == 'res_tem'){
    include 'templates.php';
}
else if($type == 'cwl'){
    include 'content_writer_list.php';
}
else if($type == 'my_resume'){
    include 'my_resumes.php';
}
else if($type == 'edit_profile'){
    include 'edit_profile.php';
}
else if($type == 'ef'){
    include 'enquiry_form.php';
}
else if($type == 'r'){
    include 'Reviews.php';
}
else if($type == 'not'){
    include 'notification.php';
}
else if($type == 'ed'){
    include 'enquiry_details.php';
}
else if($type == 'of'){
    include 'order_form.php';
}
else if($type == 'order_now'){
include 'order_form.php';
}
else if($type == 'profile_valid'){
include 'profile_valid.php';
}

else if($type == 'payment'){
include 'profile_valid.php';
}
else if($type == 'change_password'){
    include 'change_password.php';
}
else if($type == 'my_orders'){
    include 'my_orders.php';
}
else if($type == 'logout'){
    include 'logout.php';
}

include 'footer.php';
?>
