<?php
include_once '../db.php';

//session_start();
include_once 'jobseeker_model.php';

$jobseeker = new jobseeker($db);
?>


<?php

$stmtje=$db->prepare("SELECT * FROM js_skills");
	
$stmtje->execute();
	
$row_js=$stmtje->fetch(PDO::FETCH_ASSOC);

$row = $row_js['js_skills_id'];

?>

<?php

if(empty($row)){
if(isset($_POST['btn-add']))
{
	$id = $_GET['edit_id'];		
	$js_skill_description = $_POST['js_skill_description'];
	

	if($jobseeker->skills($id,$js_skill_description))
	{		
		  header("Location: jobseeker/jobseeker_dashboard.php?inserted");		
	}
	else
	{
		$msg = "<div class='alert alert-warning'>
		<strong>SORRY!</strong> ERROR while inserted record !
		</div>";
	}
}

}
else {
 if(isset($_POST['btn-add']))
{
	$id = $_GET['edit_id'];
		
	$js_skill_description = $_POST['js_skill_description'];

	if($jobseeker->skills_update($id, $js_skill_description))
	{		
		  header("Location: jobseeker_dashboard.php?updated");		
	
	}
	else
	{
		$msg = "<div class='alert alert-warning'>
				<strong>SORRY!</strong> ERROR while updating record !
				</div>";
	}
}
}
if(isset($_GET['edit_id']))
{
	$id = $_GET['edit_id'];
	extract($jobseeker->getID($id));	
}

?>
<?php include_once 'header.php'; ?>

<div class="clearfix"></div>

<div class="container">
<?php
if(isset($msg))
{
	echo $msg;
}   
	
?>
		
</div>

<?php

$stmtje=$db->prepare("SELECT * FROM js_skills WHERE job_seeker_id ='".$_SESSION['Job_Seeker_Id']."'");
	
$stmtje->execute();
	
$js=$stmtje->fetch(PDO::FETCH_ASSOC);
?>

<div class="clearfix"></div><br />

<div class="container">
	 
     <form method='post'>
 
    <table class='table table-bordered'>
 
        <tr>
            <td>Skill Description</td>
            <td><textarea name='js_skill_description' class='form-control' > <?php echo $js['js_skill_description']; ?></textarea></td>
        </tr>
 
        
			
        <tr>
            <td colspan="2">
                <button type="submit" class="btn btn-primary" name="btn-add">
    			<span class="glyphicon glyphicon-edit"></span>  Submit
				</button>
                <a href="jobseeker_master.php" class="btn btn-large btn-success"><i class="glyphicon glyphicon-backward"></i> &nbsp; CANCEL</a>
            </td>
        </tr>
 
    </table>
</form>
     
     
</div>

<?php include_once 'footer.php'; ?>

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<script type="text/javascript">
var rowCount = 1;
function addMoreRows(frm) {
rowCount ++;
var recRow = '<p id="rowCount'+rowCount+'"><table><tr><td><input name="language_name" type="text" size="17%"  maxlength="120" /></td><td><select name="profficiency_level"  maxlength="120" style="margin: 4px 5px 0 5px;"/></select></td><td><input name="" type="text" maxlength="120" style="margin: 4px 10px 0 0px;"/></td></tr> </table><a href="javascript:void(0);" onclick="removeRow('+rowCount+');">Delete</a></p>';
jQuery('#addedRows').append(recRow);
}

function removeRow(removeNum) {
jQuery('#rowCount'+removeNum).remove();
}
</script>