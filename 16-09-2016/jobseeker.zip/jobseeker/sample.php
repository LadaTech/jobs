<!DOCTYPE html>

<?php ob_start(); 
error_reporting(0); 
include_once '../db.php';
session_start(); 

include 'header.php'; 

		
 ?>


    <div class="wrapper row2">
        <div id="breadcrumb" class="hoc clear">

            <ul>
                <li><a href="#">Home</a></li>
                <li><a href="#">Lorem</a></li>
                <li><a href="#">Ipsum</a></li>
                <li><a href="#">Dolor</a></li>
            </ul>

        </div>
    </div>

    </div>
    <!-- End Top Background Image Wrapper -->
    <?php 
 if(isset($_POST['pd_sub']))
{
	$id = $_SESSION['Job_Seeker_Id'];
		
	$Alternate_email = $_POST['Alternate_email'];
	$Alternate_Phone_no = $_POST['Alternate_Phone_no'];
	$Address = $_POST['Address'];
	$Father_Name = $_POST['Father_Name'];
	
	
	$language_name = $_POST['language_name'];
	$profficiency_level = $_POST['profficiency_level'];
	$read = $_POST['read1'];
	$write = $_POST['write2'];
	$speak = $_POST['speak3'];
     
     if($jobseeker->profile_update($id,$Alternate_email,$Alternate_Phone_no,$Address,$Father_Name,$language_name,$profficiency_level,$read,$write,$speak))	
	{		
	
		 $msg = "<div class='alert alert-warning'>
				<strong>your Personal Details Inserted Sucessfully...</strong>
				</div>";
				
	
	}
	else
	{
			$msg = "<div class='alert alert-warning'>
				<strong>your Personal Details Inserted Sucessfully...</strong>
				</div>";	
	
	}
	
 }
	?>
        <div class="wrapper row3">
            <main class="hoc container clear">

                <div class="group demo">
                    <div class="one_quarter first">1/4</div>
                    <div class="two_quarter">
                        <div class="row">
                            <div class="col-md-3">
                                <a href=# data-toggle="modal" data-target="#myModal"><img style=" width:100%; height: 150px; border: 1px #ccc solid; " src="assets/img/T2.png"></a>
                            </div>
                            <div class="col-md-3 ">
                                <a href=# data-toggle="modal" data-target="#myModal"><img style=" width:100%; height: 150px; border: 1px #ccc solid; " src="assets/img/T2.png"></a>
                            </div>
                            <div class="col-md-3 ">
                                <a href=# data-toggle="modal" data-target="#myModal"><img style=" width:100%; height: 150px; border: 1px #ccc solid; " src="assets/img/T2.png"></a>
                            </div>
                            <div class="col-md-3 ">
                                <a href=# data-toggle="modal" data-target="#myModal"><img style=" width:100%; height: 150px; border: 1px #ccc solid; " src="assets/img/T2.png"></a>
                            </div>

                        </div>
                        <br />
                        <div class="row">
                            <div class="col-md-3">
                                <a href=# data-toggle="modal" data-target="#myModal"><img style=" width:100%; height: 150px; border: 1px #ccc solid; " src="assets/img/T2.png"></a>
                            </div>
                            <div class="col-md-3 ">
                                <a href=# data-toggle="modal" data-target="#myModal"><img style=" width:100%; height: 150px; border: 1px #ccc solid; " src="assets/img/T2.png"></a>
                            </div>
                            <div class="col-md-3 ">
                                <a href=# data-toggle="modal" data-target="#myModal"><img style=" width:100%; height: 150px; border: 1px #ccc solid; " src="assets/img/T2.png"></a>
                            </div>
                            <div class="col-md-3 ">
                                <a href=# data-toggle="modal" data-target="#myModal"><img style=" width:100%; height: 150px; border: 1px #ccc solid; " src="assets/img/T2.png"></a>
                            </div>

                        </div>
                        <a href="#" class="pull-right">view more</a>
                        <!-- Modal -->
                        <div class="modal fade" id="myModal" role="dialog">
                            <div class="modal-dialog">

                                <!-- Modal content-->
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                        <h4 class="modal-title">Modal Header</h4>
                                    </div>
                                    <div class="modal-body">
                                        <img style=" border: 1px #ccc solid; " src="assets/img/T2.png">
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-primary" data-dismiss="modal">Select</button>
                                        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="one_quarter">
                        <?php
                            $stmtje=$db->prepare("SELECT * FROM content_writer LIMIT 4"); $stmtje->execute(); while($row=$stmtje->fetch(PDO::FETCH_ASSOC)) { ?>


                            <article class="material-card Cyan">
                                <h2>
                    <span><?php echo $row['User_name']; ?></span>
                    <strong>
                        <i class="fa fa-fw fa-star"></i>
                        <i class="fa fa-fw fa-star"></i>
                        <i class="fa fa-fw fa-star"></i>
                        <i class="fa fa-fw fa-star"></i>
                        <i class="fa fa-fw fa-star"></i>
                    </strong>
                </h2>
                                <div class="mc-content">
                                    <div class="img-container">
                                        <img class="img-responsive" src="https://lh3.googleusercontent.com/-W3E2_6WcwAg/VuEY6f7m3xI/AAAAAAAAABE/YaJ6Bjd3p8EUOxjhA4SYn5wgdbKcvQUrgCL0B/w561-h563-no/11872072_140846389587317_7934122158675082122_o.jpg">
                                    </div>
                                    <div class="mc-description">
                                        <?php echo $row['Profile_summary']; ?>
                                    </div>
                                </div>
                                <a class="mc-btn-action">
                                    <i class="fa fa-bars"></i>
                                </a>
                                <div class="mc-footer">

                                    <a class="fa fa-fw fa-shopping-cart"></a>
                                    <a class="fa fa-fw fa-paper-plane"></a>
                                    <a class="fa fa-fw fa-star"></a>
                                </div>
                            </article>


                            <?php 
  // $i=$i+1;
     }
                            
	  ?>
                                <h4 align="right"><a href="#">more...</a></h4>
                    </div>



                </div>
            </main>
        </div>

        <?php include 'footer.php';  ?>
