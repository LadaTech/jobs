<div class="wrapper row2">
    <div id="breadcrumb" class="hoc clear">

        <ul>
            <li><a href="#">Home</a></li>
            <li><a href="#">Lorem</a></li>
            <li><a href="#">Ipsum</a></li>
            <li><a href="#">Dolor</a></li>
        </ul>

    </div>
</div>

</div>
<!-- End Top Background Image Wrapper -->

<div class="wrapper row3">
    <main class="hoc container clear">

        <div class="group demo">
            <div class="one_quarter first">
                one
            </div>
            <div class="two_quarter">
                two
            </div>
            <div class="one_quarter">
                three
            </div>



        </div>
    </main>
</div>