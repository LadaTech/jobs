<?php
include_once '../db.php';
?>


    </div>
    <!-- End Top Background Image Wrapper -->

    <div class="wrapper row3">
        <main class="hoc container clear">

            <div class="group demo">
                <div class="three_quarter first">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>sno</th>
                                <th>Content Writer</th>
                                <th>Query</th>
                                <th>Reply</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                    $stmt = $db->prepare('SELECT * FROM js_enquiries where js_job_seeker_id="'.$_SESSION['Job_Seeker_Id'].'" order by js_enquiry_id asc');
                $stmt->execute();
                        $update = $db->prepare('update js_enquiries set is_read_js=0 where is_read_js=1 and js_job_seeker_id="'.$_SESSION['Job_Seeker_Id'].'" ');
                $update->execute();
                $i =1;
                if ($stmt->rowCount() > 0):

                while($row=$stmt->fetch(PDO::FETCH_ASSOC)):
                
                     ?>
                                <tr>
                                    <td>
                                        <?php echo $i ?>
                                    </td>
                                    <td>
                                        <?php $stmtcw = $db->prepare("SELECT * FROM content_writer WHERE Content_writer_id='".$row['js_content_writer_id']."'"); $stmtcw->execute();$cw=$stmtcw->fetch(PDO::FETCH_ASSOC);
                                    echo $cw['First_name']; ?>
                                    </td>
                                    <td>
                                        <?php echo $row['js_message']; ?>
                                    </td>
                                    <?php $count = $db->prepare('SELECT * FROM js_enquiry_detail where js_enquiry_id="'.$row['js_enquiry_id'].'" and is_read=1 and js_receiver="'.$_SESSION['Job_Seeker_Id'].'"'); $count->execute(); ?>
                                        <td><a href="jobseeker.php?type=ed&n=<?php echo $row['js_enquiry_id'] ?>"><span class="fa fa-reply"></span>/view(<?php echo $count->rowCount(); ?>)</a></td>
                                </tr>

                                <?php
                        $i++;
                    endwhile;
                    endif;
                    ?>
                        </tbody>
                    </table>

                </div>
                <div class="one_quarter">

                </div>



            </div>
        </main>
    </div>
