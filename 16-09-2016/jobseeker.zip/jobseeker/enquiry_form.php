<?php 

include_once '../db.php';

ob_start(); 

include_once 'jobseeker_model.php';

$jobseeker = new jobseeker($db); 

?>


    </div>
    <!-- End Top Background Image Wrapper -->

    <div class="wrapper row3">
        <main class="hoc container clear">
            <?php
	 
                            if(isset($_POST['enq_frm']))
                            {

                            $js_email_id = $_POST['js_email_id'];	
                            $js_id = $_POST['js_id'];
                            $js_name = $_POST['js_name'];
                            $CW_ID = $_POST['CW_ID'];
                            $js_subject = $_POST['js_subject'];	
                            $js_message = $_POST['js_message'];

                            if($jobseeker->send_quiries($js_email_id, $js_id, $js_name, $CW_ID, $js_subject, $js_message))
                            {		//echo("add");
                                $msg = "<div class='alert alert-info'>
                                        your <strong>Query</strong>  successfully sent to Content Writer !
                                        </div>";	

                            }
                            else
                            {
                                $msg = "<div class='alert alert-warning'>
                                        <strong>SORRY!</strong> ERROR while inserting record !
                                        </div>";
                            }


                        }
                        $stmtje=$db->prepare("SELECT * FROM job_seeker WHERE Job_Seeker_Id ='".$_SESSION['Job_Seeker_Id']."'");

                        $stmtje->execute();

                        $js=$stmtje->fetch(PDO::FETCH_ASSOC);


                                // parse_str(urldecode($_SERVER['QUERY_STRING']));

                                 $n = htmlspecialchars($_GET["n"]);


                        //echo $email = $js['Email_id']; 


                        ?>
                <div class="group demo">
                    <div class="three_quarter first">
                        <form method="post" name="enq_frm" class="form-floating">
                            <fieldset>
                                <div class="">
                                    <?php
                                            if(isset($msg))
                                            {
                                                echo $msg;
                                            }   

                                            ?>
                                </div>
                                <div class="clearfix"></div>
                                <div class="form-group">
                                    <label for="inputEmail" class="control-label">Email</label>
                                    <input type="text" name="js_email_id" value="<?php echo $js['Email_id']; ?>" readonly class="form-control"> </div>
                                <div class="form-group">
                                    <label for="inputSubject" class="control-label">subject</label>
                                    <input type="text" name="js_subject" required value="" class="form-control" id="inputSubject">

                                    <input type="hidden" name="js_id" value="<?php echo $js['Job_Seeker_Id']; ?>" class="form-control" id="inputSubject">
                                    <input type="hidden" name="js_name" value="<?php echo $js['User_name']; ?>" class="form-control" id="inputSubject">
                                    <input type="hidden" name="CW_ID" value="<?php echo $n; ?>" class="form-control" id="inputSubject"> </div>


                                <div class="form-group">
                                    <label for="textArea" class="control-label">Query</label>
                                    <textarea name="js_message" value="" required class="form-control vertical" rows="3" id="textArea"></textarea>
                                </div>

                                <div class="form-group">
                                    <button type="submit" name="enq_frm" class="btn btn-primary">Submit</button>
                                    <button type="reset" class="btn btn-default">Cancel</button>
                                </div>
                            </fieldset>
                        </form>
                    </div>
                    <div class="one_quarter">

                    </div>

                </div>
        </main>
    </div>
