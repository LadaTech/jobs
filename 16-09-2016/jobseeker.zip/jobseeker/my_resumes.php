</div>
<!-- End Top Background Image Wrapper -->

<div class="wrapper row3">
    <main class="hoc container clear">

        <div class="group demo">
            <div class="three_quarter first">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Sno</th>
                            <th>Date</th>
                            <th>Resume Name</th>
                            <th>Download</th>
                            <th>Price</th>
                        </tr>
                    </thead>
                    <tbody>

                        <?php
	$i = 1;  
$dirname = "files/";
$images = glob($dirname."*.pdf");
$iterator = new FilesystemIterator('files/');

foreach($iterator as $fileInfo){
	$cTime = new DateTime();
    $cTime->setTimestamp($fileInfo->getCTime());
	
	
	
	
	?>
                            <tr>
                                <td>
                                    <?php echo $i; ?>
                                </td>
                                <td>
                                    <?php echo $fileInfo->getFileName(); ?>
                                </td>
                                <td>
                                    <?php echo $cTime->format('Y-m-d h:i:s'); ?>
                                </td>
                                <td>
                                    <?php echo $fileInfo->getFileName(); ?>
                                </td>
                                <td><a href="test.php"><i class="glyphicon glyphicon-download"></i>click</a></td>
                                <!-- <td>12,000</td> -->
                            </tr>

                            <?php
}
$i++;
?>

                    </tbody>
                </table>
            </div>
            <div class="one_quarter">

            </div>



        </div>
    </main>
</div>
