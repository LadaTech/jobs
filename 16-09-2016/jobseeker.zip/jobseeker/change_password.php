<?php 

include_once '../db.php';

ob_start(); 

include_once 'jobseeker_model.php';

$jobseeker = new jobseeker($db); 

?>

    <div class="wrapper row2">
        <div id="breadcrumb" class="hoc clear">

            <ul>
                <li><a href="#">Home</a></li>
                <li><a href="#">Lorem</a></li>
                <li><a href="#">Ipsum</a></li>
                <li><a href="#">Dolor</a></li>
            </ul>

        </div>
    </div>

    </div>
    <!-- End Top Background Image Wrapper -->

    <div class="wrapper row3">
        <main class="hoc container clear">

            <div class="group demo">
                <div class="three_quarter first">
                    <?php
	 include 'functions.php';
	  $stmtjs=$db->prepare("SELECT * FROM job_seeker WHERE job_seeker_id ='".$_SESSION['Job_Seeker_Id']."'");
	
	$stmtjs->execute();
	
	$js=$stmtjs->fetch(PDO::FETCH_ASSOC);
	 
	 if(isset($_POST['submit']))
{
		
	$old_password = $_POST['old_password'];
	
	


	$new_password = $_POST['new_password'];
	
	
	$cfrm_password = $_POST['cfrm_password'];



	$id = $_SESSION['Job_Seeker_Id'];
	
	$errors = array();
	
	
	
	 if($jobseeker->change_password($new_password, $cfrm_password, $id))
	{		//echo("add");
		$msg = "<div class='alert alert-info'>
				your <strong>Password</strong>  successfully Changed, Please login with new Password!
				</div>";	
				
	}
	
	 
	
}

$stmtje=$db->prepare("SELECT * FROM job_seeker WHERE Job_Seeker_Id ='".$_SESSION['Job_Seeker_Id']."'");
	
$stmtje->execute();
	
$js=$stmtje->fetch(PDO::FETCH_ASSOC);
?>
                        <form method="post" id="register-form" name="cp_frm" class="form-floating">
                            <fieldset>
                                <div class="">
                                    <?php
if(isset($msg))
{
	echo $msg;
}   
	
?>
                                </div>

                                <input id="c_pswd" name="c_pswd" type="hidden" class="form-control" value="<?php echo $js['Confirm_password']; ?>">

                                <div class="clearfix"></div>
                                <div class="form-group">
                                    <label for="password" class="control-label">Old Password</label>
                                    <input id="old_password" type="password" name="old_password" value="" required class="form-control"> </div>
                                <div class="form-group">
                                    <label for="password" class="control-label">New Password</label>
                                    <input type="password" name="new_password" value="" required class="form-control" id="inputSubject">


                                </div>


                                <div class="form-group">
                                    <label for="password" class="control-label">Confirm Password</label>
                                    <input type="password" name="cfrm_password" value="" required class="form-control" id="inputSubject">
                                </div>

                                <div class="form-group">
                                    <button type="submit" id="change_password" name="submit" class="btn btn-primary">Submit</button>
                                    <button type="reset" class="btn btn-default">Cancel</button>
                                </div>
                            </fieldset>
                        </form>
                </div>
                <div class="one_quarter">
                    three
                </div>



            </div>
        </main>
    </div>

    <script type="text/javascript">
        $(document).ready(function() {
            $("#register-form").validate();
        });

    </script>
    <style type="text/css">
        .error {
            color: red;
        }

    </style>
