<?php 

include_once '../db.php';

ob_start(); 

include_once 'jobseeker_model.php';

$jobseeker = new jobseeker($db); 

?>
    <div class="wrapper row2">
        <div id="breadcrumb" class="hoc clear">

            <ul>
                <li><a href="#">Home</a></li>
                <li><a href="#">Lorem</a></li>
                <li><a href="#">Ipsum</a></li>
                <li><a href="#">Dolor</a></li>
            </ul>

        </div>
    </div>

    </div>
    <!-- End Top Background Image Wrapper -->

    <div class="wrapper row3">
        <main class="hoc container clear">

            <div class="group demo">
                <div class="one_quarter first">
                    <div style="  padding: 10px; ">
                        <p>&nbsp;</p>
                        <div class="row">
                            <div class="col-md-12">
                                <button type="button" class="btn btn-default col-md-12">Template's List</button>
                            </div>
                        </div>
                        <p>&nbsp;</p>
                        <div class="row">
                            <div class="col-md-12">
                                <button type="button" class="btn btn-success col-md-12">Profile Details</button>
                            </div>
                        </div>
                        <p>&nbsp;</p>
                        <div class="row">
                            <div class="col-md-12">
                                <button type="button" class="btn btn-info col-md-12">Payment Process</button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="two_quarter">
                    <?php 
	if(isset($_POST['pick-temp']))
	{
	$temp_image =  $_POST['pick-temp'];
	if($temp_image == T1)
	{
		$id = $_GET['id'];
		
	header("Location: jobseeker.php?type=profile_valid&t_id=$id&inserted");	
	}
	}
	?>
                        <?php
echo $id = $_GET['id'];
?>
                            <form method="post" name="enq_frm" class="form-floating">

                                <div class="row">
                                    <div class="col-md-3">
                                        <a href=# data-toggle="modal" data-target="#myModal"><img style=" width:100%; height: 150px; border: 1px #ccc solid; " src="templates\img\templates/T2.png"></a>
                                    </div>
                                    <div class="col-md-3 ">
                                        <a href=# data-toggle="modal" data-target="#myModal"><img style=" width:100%; height: 150px; border: 1px #ccc solid; " src="templates\img\templates/T2.png"></a>
                                    </div>
                                    <div class="col-md-3 ">
                                        <a href=# data-toggle="modal" data-target="#myModal"><img style=" width:100%; height: 150px; border: 1px #ccc solid; " src="templates\img\templates/T2.png"></a>
                                    </div>
                                    <div class="col-md-3 ">
                                        <a href=# data-toggle="modal" data-target="#myModal"><img style=" width:100%; height: 150px; border: 1px #ccc solid; " src="templates\img\templates/T2.png"></a>
                                    </div>

                                </div>
                                <br />
                                <div class="row">
                                    <div class="col-md-3">
                                        <a href=# data-toggle="modal" data-target="#myModal"><img style=" width:100%; height: 150px; border: 1px #ccc solid; " src="templates\img\templates\T2.png"></a>
                                    </div>
                                    <div class="col-md-3 ">
                                        <a href=# data-toggle="modal" data-target="#myModal"><img style=" width:100%; height: 150px; border: 1px #ccc solid; " src="templates\img\templates/T2.png"></a>
                                    </div>
                                    <div class="col-md-3 ">
                                        <a href=# data-toggle="modal" data-target="#myModal"><img style=" width:100%; height: 150px; border: 1px #ccc solid; " src="templates\img\templates/T2.png"></a>
                                    </div>
                                    <div class="col-md-3 ">
                                        <a href=# data-toggle="modal" data-target="#myModal"><img style=" width:100%; height: 150px; border: 1px #ccc solid; " src="templates\img\templates/T2.png"></a>
                                    </div>

                                </div>
                                <a href="#" class="pull-right">view more</a>
                                <!-- Modal -->
                                <div class="modal fade" id="myModal" role="dialog">
                                    <div class="modal-dialog">

                                        <!-- Modal content-->
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                <h4 class="modal-title">Modal Header</h4>
                                            </div>
                                            <div class="modal-body">
                                                <img style=" border: 1px #ccc solid; " src="templates\img\templates/T2.png">
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-primary" data-dismiss="modal">Select</button>
                                                <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                                            </div>
                                        </div>

                                    </div>
                                </div>

                                <div class="clearfix"></div>

                            </form>
                </div>
                <div class="one_quarter">
                    three
                </div>



            </div>
        </main>
    </div>
