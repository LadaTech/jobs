<!DOCTYPE html>

<?php ob_start(); 
error_reporting(0); 
include_once '../db.php';
session_start(); 

 

		
 ?>




    </div>
    <!-- End Top Background Image Wrapper -->

    <div class="wrapper row3">
        <main class="hoc container clear">

            <div class="group demo">
                <?php

        $total = $db->query('
        SELECT
            COUNT(*)
        FROM
            content_writer
    ')->fetchColumn();

    $limit = 6;

    $pages = ceil($total / $limit);

    $page = min($pages, filter_input(INPUT_GET, 'page', FILTER_VALIDATE_INT, array(
        'options' => array(
            'default'   => 1,
            'min_range' => 1,
        ),
    )));

    $offset = ($page - 1)  * $limit;

    $start = $offset + 1;
    $end = min(($offset + $limit), $total);

    $prevlink = ($page > 1) ? '<a href="jobseeker.php?type=cwl&page=1" title="First page">&laquo;</a> <a href="jobseeker.php?type=cwl&page=' . ($page - 1) . '" title="Previous page">&lsaquo;</a>' : '<span class="disabled">&laquo;</span> <span class="disabled">&lsaquo;</span>';

    $nextlink = ($page < $pages) ? '<a href="jobseeker.php?type=cwl&page=' . ($page + 1) . '" title="Next page">&rsaquo;</a> <a href="jobseeker.php?type=cwl&page=' . $pages . '" title="Last page">&raquo;</a>' : '<span class="disabled">&rsaquo;</span> <span class="disabled">&raquo;</span>';

    echo '<div id="paging"><p>', $prevlink, ' Page ', $page, ' of ', $pages, ' pages ', $start, '-', $end, ' of ', $total, ' results ', $nextlink, ' </p></div>';

    $stmt = $db->prepare('
        SELECT
            *
        FROM
            content_writer        
        LIMIT
            :limit
        OFFSET
            :offset
    ');

    $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
    $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();

    if ($stmt->rowCount() > 0) {
     
        while($row=$stmt->fetch(PDO::FETCH_ASSOC))
        {
            ?>
                    <div class="one_quarter">
                        <article class="material-card Cyan">
                            <h2>
                    <span><?php echo $row['User_name']; ?></span>
                    <strong>
                        <i class="fa fa-fw fa-star"></i>
                        <i class="fa fa-fw fa-star"></i>
                        <i class="fa fa-fw fa-star"></i>
                        <i class="fa fa-fw fa-star"></i>
                        <i class="fa fa-fw fa-star"></i>
                    </strong>
                </h2>
                            <div class="mc-content">
                                <div class="img-container">
                                    <img class="img-responsive" src="https://lh3.googleusercontent.com/-W3E2_6WcwAg/VuEY6f7m3xI/AAAAAAAAABE/YaJ6Bjd3p8EUOxjhA4SYn5wgdbKcvQUrgCL0B/w561-h563-no/11872072_140846389587317_7934122158675082122_o.jpg">
                                </div>
                                <div class="mc-description">
                                    <?php echo $row['Profile_summary']; ?>
                                </div>
                            </div>
                            <a class="mc-btn-action">
                                <i class="fa fa-bars"></i>
                            </a>
                            <div class="mc-footer">

                                <a class="fa fa-fw fa-shopping-cart"></a>
                                <a class="fa fa-fw fa-paper-plane"></a>
                                <a class="fa fa-fw fa-star"></a>
                            </div>
                        </article>

                    </div>


                    <?php
            
        }


     }
    
	  ?>

            </div>
        </main>
    </div>
