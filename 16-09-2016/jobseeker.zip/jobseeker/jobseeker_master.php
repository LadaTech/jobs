<?php
include_once '../db.php';

include_once 'jobseeker_model.php';

$jobseeker = new jobseeker($db);
?>
    <?php // include_once 'header.php'; ?>

        <div class="clearfix"></div>

        <?php
if(isset($_GET['inserted']))
{
	?>
            <div class="container">
                <div class="alert alert-info">
                    <strong>Record was inserted successfully..</strong>
                </div>
            </div>
            <?php
}
else if(isset($_GET['in_failure']))
{
	?>
                <div class="container">
                    <div class="alert alert-warning">
                        <strong>SORRY!</strong> ERROR while inserting record !
                    </div>
                </div>
                <?php
}
?>
                    <?php
if(isset($_GET['updated']))
{
	?>
                        <div class="container">
                            <div class="alert alert-info">
                                <strong>Record was updated successfully..</strong>
                            </div>
                        </div>
                        <?php
}
else if(isset($_GET['up_failure']))
{
	?>
                            <div class="container">
                                <div class="alert alert-warning">
                                    <strong>SORRY!</strong> ERROR while updating record !
                                </div>
                            </div>
                            <?php
}
?>

                                <?php
	if(isset($_GET['deleted']))
	{
		?>
                                    <div class="alert alert-success">
                                        <strong>Success!</strong> record was deleted...
                                    </div>
                                    <?php
	}
	
	?>
                                        <div class="clearfix"></div>
                                        <br />



                                        <div class="clearfix"></div>
                                        <br />

                                        <div class="container">



                                            <?php
		$query = "SELECT * FROM job_seeker where Job_Seeker_Id='".$_SESSION['Job_Seeker_Id']."'";       
	
		//$jobseeker->dataview($query);
		
		$stmt = $db->prepare($query);
		$stmt->execute();
	
		if($stmt->rowCount()>0)
		{
			
			while($row=$stmt->fetch(PDO::FETCH_ASSOC))
			{
				?>
                                                <a href="edit_jobseeker.php?edit_id=<?php print($row['Job_Seeker_Id']); ?>"><i class="">EDIT JOBSEEKER</i></a>
                                                <br/>
                                                <a href="view_jobseeker.php?view_id=<?php print($row['Job_Seeker_Id']); ?>"><i class="">View Profile</i></a>
                                                <br/>
                                                <a href="change_password.php?edit_id=<?php print($row['Job_Seeker_Id']); ?>"><i class="">changed Password</i></a>
                                                <br />
                                                <a href="personal_Profile.php?edit_id=<?php print($row['Job_Seeker_Id']); ?>"><i class="">Personal Profile</i></a>
                                                <br />
                                                <a href="Education_Profile.php?edit_id=<?php print($row['Job_Seeker_Id']); ?>"><i class="">Eduction Profile</i></a>
                                                <br />
                                                <a href="Experience.php?edit_id=<?php print($row['Job_Seeker_Id']); ?>"><i class="">Experience Profile</i></a>
                                                <br />
                                                <a href="skills.php?edit_id=<?php print($row['Job_Seeker_Id']); ?>"><i class="">Skills Profile</i></a>
                                                <br />
                                                <a href="Objective.php?edit_id=<?php print($row['Job_Seeker_Id']); ?>"><i class="">Objective Profile</i></a>
                                                <br />
                                                <a href="hobbies.php?edit_id=<?php print($row['Job_Seeker_Id']); ?>"><i class="">Skills Profile</i></a>
                                                <br />
                                                <?php  		
				}
		}
		else
		{
			?>
                                                    <tr>
                                                        <td>No Data found...</td>
                                                    </tr>
                                                    <?php
		}
		
		
		
		
		
		
		
		
	 ?>





                                        </div>

                                        <?php //include_once 'footer.php'; ?>
