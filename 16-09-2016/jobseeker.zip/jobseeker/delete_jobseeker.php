<?php
include_once '../db.php';

if(isset($_POST['btn-del']))
{
	$id = $_GET['delete_id'];
	$jobseeker->delete($id);
	header("Location: jobseeker_master.php?deleted");	
}

?>

<?php include_once 'header.php'; ?>

<div class="clearfix"></div>

<div class="container">

		
</div>

<div class="clearfix"></div>

<div class="container">
 	
	 <?php
	 if(isset($_GET['delete_id']))
	 {
		 ?>
         <table class='table table-bordered'>
         <tr>
         <th>S.No</th>
         <th>Username</th>
        
         <th>E - mail ID</th>
		 
		 
         <th>Phone No</th>
		  <th>Domain</th>
         </tr>
         <?php
         $stmt = $DB_con->prepare("SELECT * FROM job_seeker WHERE Job_Seeker_Id=:id");
         $stmt->execute(array(":id"=>$_GET['delete_id']));
         while($row=$stmt->fetch(PDO::FETCH_BOTH))
         {
             ?>
             <tr>
             <td><?php print($row['Job_Seeker_Id']); ?></td>
             <td><?php print($row['User_name']); ?></td>
             <td><?php print($row['Email_id']); ?></td>
             <td><?php print($row['Phone_No']); ?></td>
         	 <td><?php print($row['Domain']); ?></td>
             </tr>
             <?php
         }
         ?>
         </table>
         <?php
	 }
	 ?>
</div>

<div class="container">
<p>
<?php
if(isset($_GET['delete_id']))
{
	?>
  	<form method="post">
    <input type="hidden" name="id" value="<?php echo $row['Job_Seeker_Id']; ?>" />
    <button class="btn btn-large btn-primary" type="submit" name="btn-del"><i class="glyphicon glyphicon-trash"></i> &nbsp; YES</button>
    <a href="jobseeker_master.php" class="btn btn-large btn-success"><i class="glyphicon glyphicon-backward"></i> &nbsp; NO</a>
    </form>  
	<?php
}
else
{
	?>
    <a href="jobseeker_master.php" class="btn btn-large btn-success"><i class="glyphicon glyphicon-backward"></i> &nbsp; Back</a>
    <?php
}
?>
</p>
</div>	
<?php include_once 'footer.php'; ?>