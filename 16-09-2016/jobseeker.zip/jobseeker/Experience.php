<?php
include_once '../db.php';

//session_start();
include_once 'jobseeker_model.php';

$jobseeker = new jobseeker($db);
?>


<?php

$stmtje=$db->prepare("SELECT * FROM  js_work_experience");
	
$stmtje->execute();
	
$row_js=$stmtje->fetch(PDO::FETCH_ASSOC);

$row = $row_js['js_work_experience_id'];

?>

<?php

if(empty($row)){
if(isset($_POST['btn-add']))
{
	$id = $_GET['edit_id'];		
	$Company_Name = $_POST['Company_Name'];
	$Designation = $_POST['Designation'];
	$Start_date = $_POST['Start_date'];
	$End_date = $_POST['End_date'];
	$Current_CTC = $_POST['Current_CTC'];
	$Expected_CTC = $_POST['Expected_CTC'];

	if($jobseeker->Experience_profile($id,$Company_Name,$Designation,$Start_date,$End_date,$Current_CTC,$Expected_CTC))
	{		
		  header("Location: jobseeker_dashboard.php?js_id=27");		
	}
	else
	{
		$msg = "<div class='alert alert-warning'>
		<strong>SORRY!</strong> ERROR while inserted record !
		</div>";
	}
}

}
else {
 if(isset($_POST['btn-add']))
{
	$id = $_GET['edit_id'];
		
	$Company_Name = $_POST['Company_Name'];
	$Designation = $_POST['Designation'];
	$Start_date = $_POST['Start_date'];
	$End_date = $_POST['End_date'];
	$Current_CTC = $_POST['Current_CTC'];
	$Expected_CTC = $_POST['Expected_CTC'];
	if($jobseeker->Experience_profile_update($id, $Company_Name, $Designation, $Start_date, $End_date, $Current_CTC, $Expected_CTC))
	{		
		  header("Location: jobseeker_master.php?updated");		
	
	}
	else
	{
		$msg = "<div class='alert alert-warning'>
				<strong>SORRY!</strong> ERROR while updating record !
				</div>";
	}
}
}
if(isset($_GET['edit_id']))
{
	$id = $_GET['edit_id'];
	extract($jobseeker->getID($id));	
}

?>
<?php include_once 'header.php'; ?>

<div class="clearfix"></div>

<div class="container">
<?php
if(isset($msg))
{
	echo $msg;
}   
	
?>
		
</div>

<?php

$stmtje=$db->prepare("SELECT * FROM js_work_experience WHERE Job_Seeker_Id ='".$_SESSION['Job_Seeker_Id']."'");
	
$stmtje->execute();
	
$js=$stmtje->fetch(PDO::FETCH_ASSOC);
?>

<div class="clearfix"></div><br />

<div class="container">
	 
     <form method='post'>
 
    <table class='table table-bordered'>
 
        <tr>
            <td>Company Name</td>
           <td><input type='text' name='Company_Name' class='form-control'  value="<?php echo $js['Company_Name']; ?>" ></td>
       
            <td>Designation</td>
            <td><input type='text' name='Designation' class='form-control'  value="<?php echo $js['Designation']; ?>" ></td>
        </tr>
 
        
			<tr><td>Start date</td>
            <td><input type='date' name='Start_date' class='form-control'  value="<?php echo $js['Start_date']; ?>" ></td>
			<td>End date</td>
            <td><input type='date' name='End_date' class='form-control' value="<?php echo $js['End_date']; ?>" ></td>
        </tr>
      <tr><td>Current CTC</td>
            <td><input type='text' name='Current_CTC' class='form-control'  value="<?php echo $js['Current_CTC']; ?>" ></td>
         <td>Expected_CTC</td>
            <td><input type='text' name='Expected_CTC' class='form-control'  value="<?php echo $js['Expected_CTC']; ?>" ></td> 
		           
        </tr> 
 		
        <tr>
            <td colspan="2">
                <button type="submit" class="btn btn-primary" name="btn-add">
    			<span class="glyphicon glyphicon-edit"></span>  Submit
				</button>
                <a href="jobseeker_master.php" class="btn btn-large btn-success"><i class="glyphicon glyphicon-backward"></i> &nbsp; CANCEL</a>
            </td>
        </tr>
 
    </table>
</form>
     
     
</div>

<?php include_once 'footer.php'; ?>

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<script type="text/javascript">
var rowCount = 1;
function addMoreRows(frm) {
rowCount ++;
var recRow = '<p id="rowCount'+rowCount+'"><table><tr><td><input name="language_name" type="text" size="17%"  maxlength="120" /></td><td><select name="profficiency_level"  maxlength="120" style="margin: 4px 5px 0 5px;"/></select></td><td><input name="" type="text" maxlength="120" style="margin: 4px 10px 0 0px;"/></td></tr> </table><a href="javascript:void(0);" onclick="removeRow('+rowCount+');">Delete</a></p>';
jQuery('#addedRows').append(recRow);
}

function removeRow(removeNum) {
jQuery('#rowCount'+removeNum).remove();
}
</script>