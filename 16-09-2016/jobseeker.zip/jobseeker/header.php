<!DOCTYPE html>
<?php error_reporting(0); 
 ?>

<html>

<head>
    <title>Resume Services</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <link href="layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
    <link rel="stylesheet" href="layout/styles/smk-accordion.css" />
    <link rel="stylesheet" href="layout/styles/material-cards.css" />
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" />
    <script src="layout/scripts/jquery-1.11.3.min.js"></script>
</head>

<body id="top">

    <div class="bgded overlay" style="background-image:url('../images/demo/backgrounds/01.png');">
        <!-- ################################################################################################ -->
        <div class="wrapper row1">
            <header id="header" class="hoc clear">
                <?php
    include_once '../db.php';

    include_once 'jobseeker_model.php';

    $jobseeker = new jobseeker($db);
    session_start();

	$query = "SELECT * FROM job_seeker where Job_Seeker_Id='".$_SESSION['Job_Seeker_Id']."'";       
	
	//$jobseeker->dataview($query);
		
	$stmt = $db->prepare($query);
		
	$stmt->execute();
	
	//$stmt->rowCount();		
			
	$row=$stmt->fetch(PDO::FETCH_ASSOC);
		
	?>


                    <?php  $stmt = $db->prepare('SELECT * FROM js_enquiries where is_read_js=1 and js_job_seeker_id="'.$_SESSION['Job_Seeker_Id'].'"'); $stmt->execute(); $ad=$stmt->fetch(PDO::FETCH_ASSOC); ?>

                        <div id="logo" class="fl_left">
                            <h1><a href="../index.html">Resume Services</a></h1>
                        </div>
                        <nav id="mainav" class="fl_right">
                            <ul class="clear">
                                <li><a href="jobseeker.php?type=home">Dashboard</a></li>
                                <li><a href="jobseeker.php?type=res_tem">Templates</a></li>
                                <li><a href="jobseeker.php?type=cwl">Content Writers</a></li>
                                <li><a href="jobseeker.php?type=my_resume">My Resumes</a></li>
                                <li><a href="jobseeker.php?type=not">Notifications(<?php echo $stmt->rowCount(); ?>)</a></li>
                                <li><a class="drop" href="#">My Account</a>
                                    <ul>
                                        <li>
                                            <a href="jobseeker.php?type=edit_profile">Edit Profile</a></li>
                                        <li><a href="jobseeker.php?type=home">Transactions</a></li>
                                        <li><a href="jobseeker.php?type=change_password">Change Password</a></li>
                                        <li><a href="jobseeker.php?type=logout">Logout</a></li>
                                    </ul>
                                </li>

                            </ul>
                        </nav>

            </header>
        </div>
