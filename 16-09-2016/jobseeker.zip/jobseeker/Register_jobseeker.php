<!DOCTYPE html>

<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="">
<meta name="author" content="">
<title>Resume Services</title>


<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!--[if lt IE 9]>  <script src="//oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>  <script src="//oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>  <![endif]-->
<link href="../assets/css/vendors.min.css" rel="stylesheet">
<link href="../assets/css/styles.min.css" rel="stylesheet">
<script charset="utf-8" src="//maps.google.com/maps/api/js?sensor=true"></script>
<style type="text/css">
.full { width: 100% !important; }
.circle-mask { background-image: url(assets/img/icon_user.png); background-repeat: no-repeat; background-size: 96px auto; border-radius: 50%; display: block; height: 96px; margin-bottom: 10px; margin-left: auto; margin-right: auto; overflow: hidden; transition: opacity 0.075s ease 0s; width: 96px; z-index: 100; }
#canvas { opacity: 0.01; transition: opacity 0.075s ease 0s; }
.circle { background-position: center center; background-repeat: no-repeat; border-radius: 50%; height: 96px; opacity: 0.99; overflow: hidden; position: absolute; width: 96px; z-index: 101; }
.header { background: #7ed1f6; width: 100%; border-bottom: 1px solid #001291; }
h1 { font-size: 21px !important; padding-top: 10px !important; margin-top: 0PX !important; }
.footer { position: fixed; bottom: 0px; left: 0px;  background: #f4f4f4 none repeat scroll 0 0; border-top: 1px solid #cccccc; line-height: 25px; padding: 0 20px;  width: 100%; }
.card .card-header { padding: 10px !important; }
.nav{ width: 100%; float: left; margin: 0px; padding: 0px; }
.nav li {
    float: left;
   list-style-type: none;
}
.nav li a {
    color: #000000;
}
.nav li a:hover {
    color: #020170;
}
</style>
</head>
<body init-ripples="">
<div class="container-fluid header">
  <div class="navbar-header pull-left">
      <h1>Resume Services</h1>
  </div>
 
</div>
<div class="center" style="margin:2% auto;">
  <div class="card bordered z-depth-2" style="margin:0% auto; max-width:400px;">
   <div class="card-header">
      <div class="brand-logo">
        <h2>Jobseeker Registration</h2>
      </div>
    </div>
    <div class="card-content">
	  <?php
include '../db.php'; 
include_once 'jobseeker_model.php';

$jobseeker = new jobseeker($db);

include_once '../db.php';
if(isset($_POST['btn-save']))
{
	$First_name = $_POST['First_name'];
	$Last_name = $_POST['Last_name'];
	$Email_id = $_POST['Email_id'];
	$User_name = $_POST['User_name'];
	$Password = $_POST['Password'];
	$Confirm_password = $_POST['Confirm_password'];	
	$Phone_No = $_POST['Phone_No'];
	$Experience_level = $_POST['Experience_level'];
	$Domain = $_POST['Domain'];
	$usertype_id = $_POST['usertype_id'];
	
	
	if($jobseeker->create($First_name,$Last_name,$Email_id,$User_name,$Password,$Confirm_password,$Phone_No,$Experience_level,$Domain,$usertype_id))
	{
		header("Location: register_jobseeker.php?inserted");
	}
	else
	{
		header("Location: register_jobseeker.php?failure");
	}
}
?>
      
      <form method='post' class="form-floating">
	
<div class="clearfix"></div>

			<?php
			if(isset($_GET['inserted']))
			{
			?>
			<div class="">
			<div class="alert alert-info">
			<strong>Thank you!</strong>  Your Registration successfully completed.  <a href="../login.php" style="color:red;">click here for Login</a>
			</div>
			</div>
			<?php
			}
			else if(isset($_GET['in_failure']))
			{
			?>
			<div class="">
			<div class="alert alert-warning">
			<strong>SORRY!</strong> ERROR while inserting record !
			</div>
			</div>
			<?php
			}
			?>
			<div class="clearfix"></div>
        <div class="form-group">
          <label for="inputCurrent Password "  class="control-label">First Name</label>
          <input type="text" name='First_name' required class="form-control">
        </div>
         <div class="form-group">
          <label for="inputEnter New Password" class="control-label">Last Name</label>
         <input type="text" name='Last_name' required class="form-control">
        </div>
          <div class="form-group">
          <label for="inputEnter New Password" class="control-label">Email ID</label>
         <input type="email" name='Email_id' required class="form-control">
        </div>
		<div class="form-group">
          <label for="inputEnter New Password" class="control-label">User Name</label>
         <input type="text" name='User_name' required class="form-control">
        </div>	
          
          <div class="form-group">
          <label for="inputEnter New Password" class="control-label">Password </label>
         <input type="password" name='Password' required class="form-control">
        </div>
        <div class="form-group">
          <label for="inputEnter New Password" class="control-label">Confirm Password </label>
         <input type="password" name='Confirm_password' required class="form-control">
        </div>
		<div class="form-group">
          <label for="inputEnter New Password" class="control-label">Contact Number</label>
         <input type="text" name='Phone_No' required class="form-control">
        </div>
        <div class="form-group">
                      
                        <div class="radio">
                          <label>
                            <input type="radio" name='Experience_level' checked="" value="Fresher" id="optionsRadios1" > Fresher </label>
                        </div>
                        <div class="radio">
                          <label>
                            <input type="radio" name='Experience_level' value="Experience" id="optionsRadios2" > Experienced </label>
                        </div>
                      </div>
					  
					  
         <div class="form-group">
        <!--  <label for="inputConfirm Passsword " required class="control-label">Domain </label> -->
		  
         <select  class="form-control" id="Domain" name="Domain">
                            <option value="">Select Domain</option>
                            <?php
            
					$sql_dom='SELECT * FROM js_template_domains';
					$stmt_dom = $db->prepare($sql_dom);
					$stmt_dom->execute();


					while($row_dom = $stmt_dom->fetch(PDO::FETCH_ASSOC)){
						echo $row_dom['domain_name']; ?>
					
                            <option  value="<?php echo $row_dom['domain_id']; ?>"><?php echo $row_dom['domain_name']; ?></option>
                            <?php
						}
						?>
            </select> 
		  <input type='hidden' name='usertype_id' class='form-control' value="4">
        <div class="form-group">
        <button type="submit" name="btn-save" class="btn btn-success btn-flat-borde full">REGISTER</button>
      </div>
      </form>
    </div>
  </div>
</div>
<div class="footer">
<div class="container-fluid ">
  <div class="pull-left"> <a href="http://virtuelltech.com/">virtuelltech</a> © 2016. </div>
  <div class="pull-right">Powered by <a href="http://virtuelltech.com/">virtuelltech</a> </div>
</div>
</div>
<script charset="utf-8" src="../assets/js/vendors.min.js"></script> 
<script charset="utf-8" src="../assets/js/app.min.js"></script>
</body>
</html>
  