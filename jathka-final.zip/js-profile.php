<?php
ob_start();
include "header.php";
$page = "dashboard";
?>

<section class="inner_page_info">
    <div class="gmap-area1">

        <div class="container">
            <div class="row profile">
                <div class="col-sm-8">
                    <h3 class="main-heading">Complete Your Profile</h3>



                    <div class="tabs-wrap profile_tabs_wrapper">
                        <ul class="nav nav-tabs" role="tablist">
                            <li role="presentation" class="active">
                                <a href="#personal_details" aria-controls="personal_details" role="tab" data-toggle="tab" aria-expanded="true">Personal Details</a>
                            </li>
                            <li>
                                <a href="#educational_details" aria-controls="educational_details" role="tab" data-toggle="tab" aria-expanded="false">Educational Details</a>
                            </li>
                            <li>
                                <a href="#experience" aria-controls="experience" role="tab" data-toggle="tab" aria-expanded="false">Experience Details</a>
                            </li>
                            <li>
                                <a href="#skills" aria-controls="skills" role="tab" data-toggle="tab" aria-expanded="false">Skills</a>
                            </li>

                            <li>
                                <a href="#objective" aria-controls="objective" role="tab" data-toggle="tab" aria-expanded="false">Objective</a>
                            </li>

                        </ul>

                        <div class="tab-content">

                            <div role="tabpanel" class="tab-pane active" id="personal_details">

                                <form name="submenus" action="<?php echo $my_path; ?>/job-seeker/edit-profile.aspx" method="post" class="form-horizontal" id="identicalForm" enctype="multipart/form-data">      
                                    <div class="form-group">
                                        <div class="col-lg-6">
                                            <label class="control-label" for="address">First Name <span class="imp">*</span> </label>
                                            <input type="text" name="fname" id="" placeholder="First Name" value="<?php echo $user_info["First_name"]; ?>" class="form-control" required="required"> 
                                        </div>
                                        <div class="col-lg-6">
                                            <label class="control-label" for="address">Last Name <span class="imp">*</span> </label>
                                            <input type="text" name="lname" id="" placeholder="Last Name" value="<?php echo $user_info["Last_name"]; ?>" class="form-control" required="required"> 
                                        </div>    
                                        <div class="clear"></div>
                                    </div>  
                                    <div class="form-group email_weapper">
                                        <div class="col-lg-6">
                                            <label class="control-label" for="address">Email <span class="imp">*</span> </label>
                                            <input type="email" name="email" id="email_a" placeholder="Email" value="<?php echo $user_info["Email_id"]; ?>" class="form-control" required="required" autocomplete="off" readonly>
                                            <p class="progress_bar"><span class="m_error mail_check"><input type="hidden" name="cf" id="email_check" value="2"></span>
                                            </p>
                                            <span class="email-block imp" style="display: none;">Please enter a the Valid Email.</span>      

                                        </div>
                                        <div class="col-lg-6">
                                            <label class="control-label" for="address">Alternate Email </label>
                                            <input type="email" name="Alternate_email" id="Alternate_email" placeholder="Alternate_email" value="<?php echo $user_info["Alternate_email"]; ?>" class="form-control"  autocomplete="off">
                                        </div>    
                                        <div class="clear"></div>
                                    </div>  


                                    <div class="form-group">
                                        <div class="col-lg-6">
                                            <label class="control-label" for="address">Contact Number <span class="imp">*</span> </label>

                                            <input type="text" name="Phone_No" id="popupDatepicker" placeholder="Contact Number" value="<?php echo $user_info["Phone_No"]; ?>" class="form-control form-style-small" required="required" autocomplete="off">
                                        </div>    

                                        <div class="col-lg-6">
                                            <label class="control-label" for="address">Alternate Contact Number </label>

                                            <input type="text" name="Alternate_Phone_no" id="popupDatepicker" placeholder="Alternate Contact Number" value="<?php echo $user_info["Alternate_Phone_no"]; ?>" class="form-control form-style-small"  autocomplete="off">
                                        </div>    
                                        <div class="clear"></div>
                                    </div>  

                                    <div class="form-group">
                                        <div class="col-lg-6">
                                            <label class="control-label" for="address">Profile Type <span class="imp">*</span> </label> <br/>

                                            <div class="padding-10">  <input type="radio"  id="ptype" name="Experience_level" class="" value="Fresher" required="" <?php if ($user_info["Experience_level"] == "Fresher") {
    echo "checked";
} ?>> Fresher
                                                &nbsp;&nbsp;&nbsp;
                                                <input type="radio"  id="ptype" name="Experience_level" class="" value="Experienced" required="" <?php if ($user_info["Experience_level"] == "Experienced") {
    echo "checked";
} ?>> Experienced </div>

                                        </div>
                                        <div class="col-lg-6">
                                            <label class="control-label" for="address">Domain <span class="imp">*</span> </label>

                                            <select class="form-control" id="Domain" name="Domain">
                                                <option value="">Select Domain</option>
                                                <?php
                                                $sql_dom = 'SELECT * FROM js_template_domains';
                                                $stmt_dom = $db->query($sql_dom);
//$stmt_dom->execute();

                                                if ($stmt_dom->fetchColumn() > 0) {
                                                    while ($row_dom = $stmt_dom->fetch(PDO::FETCH_ASSOC)) {
                                                        echo $row_dom['domain_name'];
                                                        ?>

                                                        <option  value="<?php echo $row_dom['domain_id']; ?>" <?php if ($user_info["Domain"] == $row_dom['domain_id']) {
                                                    echo "selected";
                                                } ?>><?php echo $row_dom['domain_name']; ?></option>
        <?php
    }
}
?>
                                            </select>
                                        </div>    
                                        <div class="clear"></div>
                                    </div>  


                                    <div class="form-group">
                                        <div class="col-lg-6">
                                            <label class="control-label" for="address">Father Name </label>

                                            <input type="text" name="Father_Name" id="popupDatepicker" placeholder="Father Name" value="<?php echo $user_info["Father_Name"]; ?>" class="form-control form-style-small"  autocomplete="off">
                                        </div>    

                                        <div class="col-lg-6">
                                            <label class="control-label" for="address">Address </label>
                                            <textarea class="form-control vertical" id="textArea" placeholder="Address" rows="1" name="Address"><?php echo $user_info["Address"]; ?></textarea>
                                        </div>    
                                        <div class="clear"></div>
                                    </div>   


                                    <div id="Language1" class="clonedInput_3">
                                        <h4 id="reference" name="reference" class="heading-reference">Language #1</h4>
                                        <fieldset>
                                            <!-- Select Basic -->
                                            <div class="form-group">
                                                <div class="col-sm-4">   
                                                    <label class="control-label">Language Name</label>
                                                    <input type="text" name="language_name" placeholder="Language Name" data-error="This field is required" value="hfghgf" required="" class="form-control">
                                                </div>
                                                <div class="col-sm-4">   
                                                    <label class="control-label">Profficiency Level</label>
                                                    <select data-error="This field is required" required="" name="profficiency_level" class="form-control">
                                                        <option value="Beginner">
                                                            Beginner                                                                    </option>
                                                        <option value="Beginner">Beginner</option>
                                                        <option value="Intermediate">Intermediate</option>
                                                        <option value="Expert">Expert</option>
                                                        <option value="Profossional">Profossional</option>
                                                    </select>
                                                </div>

<div class="col-sm-4"> 
   <label class="control-label">Language Skills</label><br/>
<label>
    <input type="checkbox" name="speak3" value="S"> Read </label> &nbsp;

<label>
    <input type="checkbox" name="speak3" value="S"> Speak </label> &nbsp;
<label>
    <input type="checkbox" name="write2" value="W"> Write </label> &nbsp;
</div>
                                                <div class="clearfix"></div>
                                            </div>

                              


                                    </div><!-- end #entry1 -->
                                    <div class="form-group">
                                        <div class="col-sm-6">    
                                            <button type="button" id="btnAdd_3" name="btnAdd_2" class="btn btn-info btn-full">add section</button>
                                        </div><div class="col-sm-6">   
                                            <button type="button" id="btnDel_3" name="btnDel_2" class="btn btn-danger  btn-full">remove section above</button> </div>  <div class="clearfix"></div>
                                    </div>   
                                    <div class="clearfix"></div>            


                                    <div class="form-group">
                                        <div class="col-sm-6 col-sm-offset-6">
                                            <input type="button" name="submit" value="Continue"  class="btn btn-primary btn-full open2 continue"/>
                                        </div>
                                    </div>     

                                </form>
                            </div>

                            <div role="tabpanel" class="tab-pane" id="educational_details">


                                <div id="Education1" class="clonedInput_2">
                                    <h4 id="reference" name="reference" class="heading-reference">Education #1</h4>
                                    <fieldset>
                                        <!-- Select Basic -->
                                        <div class="form-group">
                                            <div class="col-sm-6">   
                                                <label class="control-label">Choose Education</label>
                                                <select class="form-control" name="profficiency_level" value="">
                                                    <option value="">Select</option>
                                                    <option value="Post Graduation">Ph.D</option>
                                                    <option value="Post Graduation">Post Graduation</option>
                                                    <option value="Graduation">Graduation</option>
                                                    <option value="Diploma">Diploma</option>
                                                    <option value="Intermediate">Intermediate</option>
                                                    <option value="SSC">SSC</option>
                                                </select>
                                            </div>
                                            <div class="col-sm-6">   
                                                <label class="control-label">Course</label>
                                                <input type="text" data-error="This field is First Name " name="js_course" class="form-control" value="">
                                            </div>
                                            <div class="clearfix"></div>
                                        </div>
                                        <div class="form-group">
                                            <div class="col-sm-6">   
                                                <label class="control-label">Institute Name  </label>
                                                <input type="text" data-error="This field is First Name " required="" name="js_institution_name" class="form-control" value="">
                                            </div>
                                            <div class="col-sm-6">   
                                                <label class="control-label">% or CGPA </label>
                                                <input type="text" name="js_percentage" class="form-control" value="">
                                            </div>
                                            <div class="clearfix"></div>
                                        </div>

                                        <div class="form-group">
                                            <div class="col-sm-6">   
                                                <label class="control-label">Start date  </label>
                                                <input type="date" data-error="Start date" name="Start_date" class="form-control" value="00-00-0000">
                                            </div>
                                            <div class="col-sm-6">   
                                                <label class="control-label">End date</label>
                                                <input type="date" data-error="End date " name="End_date" class="form-control" value="00-00-0000">
                                            </div>
                                            <div class="clearfix"></div>
                                        </div>        


                                </div><!-- end #entry1 -->
                                <div class="form-group">
                                    <div class="col-sm-6">    
                                        <button type="button" id="btnAdd_2" name="btnAdd_2" class="btn btn-info btn-full">add section</button>
                                    </div><div class="col-sm-6">   
                                        <button type="button" id="btnDel_2" name="btnDel_2" class="btn btn-danger  btn-full">remove section above</button> </div>  <div class="clearfix"></div>
                                </div>   
                                <div class="clearfix"></div>     


                                <div class="form-group">
                                    <div class="col-sm-3 col-sm-offset-6">
                                        <input type="button" name="submit" value="Back"  class="btn btn-primary btn-full open2 back"/>
                                    </div>
                                    <div class="col-sm-3">
                                        <input type="button" name="submit" value="Continue"  class="btn btn-primary btn-full open2 continue"/>
                                    </div> 
                                    <div class="clearfix"></div>
                                </div>   
                            </div>

                            <div role="tabpanel" class="tab-pane" id="experience">
                                <div id="entry1" class="clonedInput_1">
                                    <h4 id="reference" name="reference" class="heading-reference">Company #1</h4>
                                    <fieldset>
                                        <!-- Select Basic -->
                                        <div class="form-group">
                                            <div class="col-sm-6">   
                                                <label class="control-label">Company Name</label>
                                                <input type="text" data-error="Company Name" name="Company_Name" class="form-control" value="">
                                            </div>
                                            <div class="col-sm-6">   
                                                <label class="control-label">Current CTC</label>
                                                <input type="text" data-error="Current CTC" name="Current_CTC" class="form-control" value="">
                                            </div>
                                            <div class="clearfix"></div>
                                        </div>
                                        <div class="form-group">
                                            <div class="col-sm-6">   
                                                <label class="control-label">Designation </label>
                                                <input type="text" data-error="Designation " name="Designation" class="form-control" value="">
                                            </div>
                                            <div class="col-sm-6">   
                                                <label class="control-label">Expected  CTC</label>
                                                <input type="text" data-error="Expected  CTC" name="Expected_CTC" class="form-control" value="">
                                            </div>
                                            <div class="clearfix"></div>
                                        </div>

                                        <div class="form-group">
                                            <div class="col-sm-6">   
                                                <label class="control-label">Start date  </label>
                                                <input type="date" data-error="Start date" name="Start_date" class="form-control" value="00-00-0000">
                                            </div>
                                            <div class="col-sm-6">   
                                                <label class="control-label">End date</label>
                                                <input type="date" data-error="End date " name="End_date" class="form-control" value="00-00-0000">
                                            </div>
                                            <div class="clearfix"></div>
                                        </div>        


                                </div><!-- end #entry1 -->
                                <div class="form-group">
                                    <div class="col-sm-6">    
                                        <button type="button" id="btnAdd_1" name="btnAdd_1" class="btn btn-info btn-full">add section</button>
                                    </div><div class="col-sm-6">   
                                        <button type="button" id="btnDel_1" name="btnDel_1" class="btn btn-danger  btn-full">remove section above</button> </div>  <div class="clearfix"></div>
                                </div>   
                                <div class="clearfix"></div>

                                <div class="form-group">
                                    <div class="col-sm-3 col-sm-offset-6">
                                        <input type="button" name="submit" value="Back"  class="btn btn-primary btn-full open2 back"/>
                                    </div>
                                    <div class="col-sm-3">
                                        <input type="button" name="submit" value="Continue"  class="btn btn-primary btn-full open2 continue"/>
                                    </div> 
                                    <div class="clearfix"></div>
                                </div>   
                            </div>
                            <div role="tabpanel" class="tab-pane" id="skills">
                                <div class="form-group">
                                    <div class="col-lg-12">
                                        <label class="control-label" for="address">Skills  </label>

                                        <textarea  name="skills" id="" placeholder="Skills" value="<?php echo $user_info["Phone_No"]; ?>" class="form-control form-style-small" ></textarea>
                                    </div>       
                                    <div class="clear"></div>
                                </div>  

                                <div class="form-group">
                                    <div class="col-sm-3 col-sm-offset-6">
                                        <input type="button" name="submit" value="Back"  class="btn btn-primary btn-full open2 back"/>
                                    </div>
                                    <div class="col-sm-3">
                                        <input type="button" name="submit" value="Continue"  class="btn btn-primary btn-full open2 continue"/>
                                    </div> 
                                    <div class="clearfix"></div>
                                </div>  
                            </div>  

                            <div role="tabpanel" class="tab-pane" id="objective">
                                <div class="form-group">
                                    <div class="col-lg-12">
                                        <label class="control-label" for="address">Objective  </label>

                                        <textarea  name="objective" id="" placeholder="Objective" value="<?php echo $user_info["Phone_No"]; ?>" class="form-control form-style-small" ></textarea>
                                    </div>       
                                    <div class="clear"></div>
                                </div>  

                                <div class="form-group">
                                    <div class="col-sm-3 col-sm-offset-6">
                                        <input type="button" name="submit" value="Back"  class="btn btn-primary btn-full open2 back"/>
                                    </div>
                                    <div class="col-sm-3">
                                        <input type="button" name="submit" value="Continue"  class="btn btn-primary btn-full open2 continue"/>
                                    </div> 
                                    <div class="clearfix"></div>
                                </div>  
                            </div>  
                            </form>
                        </div></div>





                </div>
                <div class="col-sm-4">

<?php require_once 'js_sidebar.php'; ?>      

                </div>

            </div>
        </div>
    </div>
</section>  <!--/gmap_area -->

<?php
include "footer.php";
?>
<script type="text/javascript" src="<?php echo $my_path; ?>/js/clone-form-td-multiple.js"></script>