<?php
ob_start();
$page="dashboard";
include "header.php";
?>
<section class="inner_page_info">
<div class="gmap-area1">

<div class="container">
<div class="row profile">
    <div class="col-sm-8">
        <h3 class="main-heading">Dashboard</h3>
        
        
        
<div class="row dashboard">



<div class="col-lg-4 col-xs-6">
<!-- small box -->
<div class="small-box bg-green">
<div class="inner">
<h3>
75%                       
</h3>
<p>Profile Completion</p>
</div>
<div class="icon">
<i class="ion fa fa-user"></i>
</div>
    <a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
</div>
</div><!-- ./col -->


<div class="col-lg-4 col-xs-6">
<!-- small box -->
<div class="small-box bg-purple">
<div class="inner">
<h3>
35                        
</h3>
<p>Resumes</p>
</div>
<div class="icon">
<i class="fa fa-file-text"></i>
</div>
    <a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
</div>
</div><!-- ./col -->



<div class="col-lg-4 col-xs-6">
<!-- small box -->
<div class="small-box bg-red">
<div class="inner">
<h3>
15                        
</h3>
<p>Content Writer</p>
</div>
<div class="icon">
<i class="fa  fa-users"></i>
</div>
    <a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
</div>
</div><!-- ./col -->

<div class="col-lg-4 col-xs-6">
<!-- small box -->
<div class="small-box bg-maroon">
<div class="inner">
<h3>
21                        
</h3>
<p>Notifications</p>
</div>
<div class="icon">
<i class="fa fa-bell"></i>
</div>
    <a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
</div>
</div><!-- ./col -->

<div class="col-lg-4 col-xs-6">
<div class="small-box bg-yellow">
<div class="inner">
<h3>
11                        
</h3>
<p>Invitations</p>
</div>
<div class="icon">
<i class="fa fa fa-weibo"></i>
</div>
    <a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
</div>
</div>

<div class="col-lg-4 col-xs-6">
<div class="small-box bg-aqua">
<div class="inner">
<h3>
40                        
</h3>
<p>Views</p>
</div>
<div class="icon">
<i class="fa fa fa-eye"></i>
</div>
    <a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
</div>
</div>

</div>
       
        
        
        
      
    </div>
    <div class="col-sm-4">
      
  <?php require_once 'js_sidebar.php'; ?>      
        
    </div>
    
</div>
</div>
</div>
</section>  <!--/gmap_area -->

<?php
include "footer.php";
?>