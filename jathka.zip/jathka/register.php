<?php
ob_start();
$page="";
include "header.php";
include "jobseeker_model.php";
?>

<section class="inner_page_info">
<div class="gmap-area1">
<div class="center banner">                
<h2>Register</h2>
</div>

<div class="container  home_content">
<div class="row projects_wrapper  gallery_page">
<div class="row projects_inner">



<div class="col-md-3 col-sm-3">
</div>   
<div class="col-md-6 col-sm-6 login_form">
<?php
if(isset($_GET['msg']))
{
$msg=$_GET['msg'];
if($msg=='exist')
{
//echo "<p class='rmsg'>Sorry, unable to add new user</p>";
?>
<div class="alert alert-danger alert-dismissable">
<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
<h4>	<i class="icon fa fa-times"></i> Sorry, This Email already exist!</h4>

</div>
<?php   
}
if($msg=='fail')
{
//echo "<p class='rmsg'>Sorry, unable to add new user</p>";
?>
<div class="alert alert-danger alert-dismissable">
<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
<h4>	<i class="icon fa fa-times"></i> Sorry, Unable to create your profile please try again!</h4>

</div>
<?php   
}
}
?>  
    <form name="submenus" action="<?php echo $my_path; ?>/register.aspx" method="post" class="form-horizontal" id="identicalForm" enctype="multipart/form-data" onsubmit="return validateform();"> 
<div class="form-group">
<div class="col-lg-6">
<label class="control-label" for="address">First Name <span class="imp">*</span> </label>
<input type="text" name="fname" id="" placeholder="First Name" value="" class="form-control" required="required"> 
</div>
<div class="col-lg-6">
<label class="control-label" for="address">Last Name <span class="imp">*</span> </label>
<input type="text" name="lname" id="" placeholder="Last Name" value="" class="form-control" required="required"> 
</div>    
<div class="clear"></div>
</div>  
<div class="form-group email_weapper">
<div class="col-lg-12">
<label class="control-label" for="address">Email <span class="imp">*</span> </label>
<input type="email" name="email" id="email_a" placeholder="Email" value="" class="form-control" required="required" autocomplete="off">
<p class="progress_bar"><span class="m_error mail_check"><input type="hidden" name="cf" id="email_check" value="2"></span>
</p>
<span class="email-block imp" style="display: none;">Please enter a the Valid Email.</span>      

</div>
<div class="clear"></div>
</div>  


<div class="form-group">
<div class="col-lg-6">
<label class="control-label" for="address">Password <span class="imp">*</span> </label>

<input type="password" placeholder="Password" id="address" name="password" class="form-control" autocomplete="off" required="">

</div>
<div class="col-lg-6">
<label class="control-label" for="address">Contact Number <span class="imp">*</span> </label>

<input type="text" name="Phone_No" id="popupDatepicker" placeholder="Contact Number" value="" class="form-control form-style-small" required="required" autocomplete="off">
</div>    
<div class="clear"></div>
</div>  

<div class="form-group">
<div class="col-lg-6">
<label class="control-label" for="address">Profile Type <span class="imp">*</span> </label> <br/>

<div class="padding-10">  <input type="radio"  id="ptype" name="Experience_level" class="" value="Fresher" required=""> Fresher
&nbsp;&nbsp;&nbsp;
<input type="radio"  id="ptype" name="Experience_level" class="" value="Experienced" required=""> Experienced </div>

</div>
    <div class="col-lg-6">
<label class="control-label" for="address">Industry <span class="imp">*</span> </label>

<select class="form-control" id="Industry" name="Industry" required>
    <option value="">Select Industry</option>
    <?php
    $sql_dom = 'SELECT * FROM industry';
    $stmt_dom = $db->query($sql_dom);
//$stmt_dom->execute();

    if ($stmt_dom->rowCount() > 0) {
        while ($row_dom = $stmt_dom->fetch(PDO::FETCH_ASSOC)) {
            echo $row_dom['domain_name'];
            ?>

            <option  value="<?php echo $row_dom['id']; ?>"><?php echo $row_dom['name']; ?></option>
<?php
}
}
?>
</select>
</div>  
 <div class="col-lg-6">
<label class="control-label" for="address">Domain <span class="imp">*</span> </label>

<select class="form-control" id="Domain" name="Domain" required>
    <option value="">Select Domain</option>
</select>
</div>    
<div class="clear"></div>
</div> 

<div class="form-group">
<div class="col-lg-7">
<!-- open1 is given in the class that is binded with the click event -->
<p class="new_Account">Already User? <a href="login.aspx">Login</a> here.</p>
</div>
<div class="col-lg-4">
<!-- open1 is given in the class that is binded with the click event -->
<input type="submit" name="submit" class="btn btn-primary open2" value="Register">
</div>
<div class="clear"></div>
</div>        

</form>   

</div>   
<div class="col-md-3 col-sm-3">
</div>   
</div>



</div>  

</div>
</div>
</section>


<?php
include "footer.php";
?>    

<script type="text/javascript" language="javascript">

function validateform(){
var email_check=document.getElementById("email_check");
if(email_check.value == "1")
{
$(".email-block").css("display", "block");
return false;
}
else{
$(".help-block").css("display", "none");
}
return true;
}
</script>  

<?php
include "db.php";
?>
<?php
ob_start();
if(isset($_POST['submit']))
{
$fname=  ucwords($_POST['fname']);
$lname=ucwords($_POST['lname']);
$email=$_POST['email'];
$password=md5($_POST["password"]);
$Industry=$_POST["Industry"];
$Domain=$_POST["Domain"];
$Phone_No=$_POST["Phone_No"];
$Experience_level=$_POST['Experience_level'];
//$new_to=$_POST["new_to"];
//$years=$_POST["years"];
//$months=mysql_real_escape_string($_POST["months"]);
$status=1;
$regex = '/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$/';
if(preg_match($regex, $email))
{
$activation=md5($email.time());
$email_check=$db->prepare("select * from job_seeker where Email_id='$email'");
echo $email_check->execute();
if($email_check->rowCount()==0){
$jobseeker = new jobseeker($db);    
$jsinsert=$jobseeker->job_seeker_insert($fname,$lname,$email,$password,$Phone_No,$Industry,$Domain,$Experience_level);    
if($jsinsert)
	{    
$pa=$my_path."/register/success.aspx";
header("Location: $pa");
}
else {
$pa=$my_path."/register/fail.aspx";
header("Location: $pa");
}
}
else {
     $pa=$my_path."/register/email-exist.aspx";
     header("Location: $pa");
 }
 }
else {
     $pa=$my_path."/register/fail.aspx";
     header("Location: $pa");
 }
}
ob_end_flush();
?>  
<script type="text/javascript">
//  alert();
$(document).ready(function()
{
$("#email_a").on('keyup blur', function(){
$(".mail_check").empty().append("<image src='images/spinner.gif' />");
var id=$(this).val();
//  alert("ff");
$.ajax({
type:"get",
url:"<?php echo $my_path; ?>/get_check_email.php",
data:{"q":id},
success:function(data){
//  alert(data);
$(".mail_check").empty().append(data);
}
});
});

$("#Industry").on('change', function(){
$("#Domain").empty().append("<image src='images/spinner.gif' />");
var id=$(this).val();
//  alert("ff");
$.ajax({
type:"get",
url:"<?php echo $my_path; ?>/get_domains.php",
data:{"q":id},
success:function(data){
//  alert(data);
$("#Domain").empty().append(data);
}
});
});
})
</script>

