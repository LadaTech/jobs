<?php
/*Loop Starts Here 

/*
 * batch
 * 
 */
if($loop_page=='industry') {
?>
<?php
	if($rs->rowCount()=='0')
{
    echo "<tr><td colspan='4'><p class='alert alert-danger alert-dismissable'>Sorry no information found</p></td></tr>";
}
else{
	 while($res=$rs->fetch(PDO::FETCH_ASSOC))
     {
?>		
 <tr>

<td><?php echo $res['name']; ?></td>
<td width="300px"> 
<!--    <a href="view_jobs.php?uid=<?php echo $res['id']; ?>"><i class="fa fa-list-alt"></i> View</a>&nbsp;&nbsp;&nbsp;-->
<a href="edit_industry.php?uid=<?php echo $res['id']; ?>"><i class="fa fa-edit"></i> Edit</a>&nbsp;&nbsp;&nbsp;
	<a href="delete_hub.php?pname=industry&uid=<?php echo $res['id']; ?>"  onclick="javascript:return confirm('Do you want Delete This?');"><i class="fa fa-trash"></i> Delete</a>
	</td>
</tr>
 <?php
	 }
}
}
/*
 *  End batch
 */

/*
 * domains
 * 
 */
if($loop_page=='domains') {
?>
<?php
	if($rs->rowCount()=='0')
{
    echo "<tr><td colspan='4'><p class='alert alert-danger alert-dismissable'>Sorry no information found</p></td></tr>";
}
else{
	 while($res=  $rs->fetch(PDO::FETCH_ASSOC))
     {
?>		
 <tr>

<td><?php echo $res['name']; ?></td>
<td><?php echo $res['i_name']; ?></td>

<td width="300px"> 
<!--    <a href="view_jobs.php?uid=<?php echo $res['id']; ?>"><i class="fa fa-list-alt"></i> View</a>&nbsp;&nbsp;&nbsp;-->
<a href="edit_domains.php?uid=<?php echo $res['id']; ?>"><i class="fa fa-edit"></i> Edit</a>&nbsp;&nbsp;&nbsp;
	<a href="delete_hub.php?pname=domains&uid=<?php echo $res['id']; ?>"  onclick="javascript:return confirm('Do you want Delete This?');"><i class="fa fa-trash"></i> Delete</a>
	</td>
</tr>
 <?php
	 }
}
}
/*
 *  End City
 */


/*
 * job_seeker
 * 
 */
if($loop_page=='job_seeker') {
?>
<?php
	if($rs->rowCount()=='0')
{
    echo "<tr><td colspan='4'><p class='alert alert-danger alert-dismissable'>Sorry no information found</p></td></tr>";
}
else{
	 while($res=  $rs->fetch(PDO::FETCH_ASSOC))
     {
?>		
 <tr>

<td><?php echo $res['First_name']." ".$res['Last_name']; ?></td>
<td><?php echo $res['Email_id']; ?></td>
<td><?php echo $res['Experience_level']; ?></td>
<td><div class="onoffswitch">
	 <input type="checkbox" data-value="<?php echo $res['Job_Seeker_Id']; ?>"  name="onoffswitch" class="onoffswitch-checkbox myonoffswitch" id="myonoffswitch<?php echo $res['Job_Seeker_Id']; ?>" 
	 <?php
if($res['status']=="1")
{
echo "checked";
}
?>>
<label class="onoffswitch-label" for="myonoffswitch<?php echo $res['Job_Seeker_Id']; ?>">
<div class="onoffswitch-inner"></div>
<div class="onoffswitch-switch"></div>
</label></div>
	</td>
<td width="300px"> 
<!--    <a href="view_jobs.php?uid=<?php echo $res['Job_Seeker_Id']; ?>"><i class="fa fa-list-alt"></i> View</a>&nbsp;&nbsp;&nbsp;-->
<a href="edit_jobseeker.php?uid=<?php echo $res['Job_Seeker_Id']; ?>"><i class="fa fa-edit"></i> Edit</a>&nbsp;&nbsp;&nbsp;
	<a href="delete_hub.php?pname=jobseeker&uid=<?php echo $res['Job_Seeker_Id']; ?>"  onclick="javascript:return confirm('Do you want Delete This?');"><i class="fa fa-trash"></i> Delete</a>
	</td>
</tr>
 <?php
	 }
}
}
/*
 *  End job_seeker
 */


/*
 * template
 * 
 */
if($loop_page=='template') {
?>
<?php
	if($rs->rowCount()=='0')
{
    echo "<tr><td colspan='4'><p class='alert alert-danger alert-dismissable'>Sorry no information found</p></td></tr>";
}
else{
	 while($res=  $rs->fetch(PDO::FETCH_ASSOC))
     {
?>		
 <tr>
<td><img src="../images/templates/<?php echo $res['image1']; ?>" alt="" width="100px"/></td>
<td><?php echo $res['name']; ?></td>
<td><?php echo $res['iname']; ?></td>
<td width="140px"> 
<!--    <a href="view_jobs.php?uid=<?php echo $res['id']; ?>"><i class="fa fa-list-alt"></i> View</a>&nbsp;&nbsp;&nbsp;-->
<a href="edit_template.php?uid=<?php echo $res['id']; ?>"><i class="fa fa-edit"></i> Edit</a>&nbsp;&nbsp;&nbsp;
	<a href="delete_hub.php?pname=template&uid=<?php echo $res['id']; ?>"  onclick="javascript:return confirm('Do you want Delete This?');"><i class="fa fa-trash"></i> Delete</a>
	</td>
</tr>
 <?php
	 }
}
}
/*
 *  End template
 */

/*
 * bookings
 * 
 */
if($loop_page=='bookings') {
?>
<?php
	if($rs->rowCount()=='0')
{
    echo "<tr><td colspan='4'><p class='alert alert-danger alert-dismissable'>Sorry no information found</p></td></tr>";
}
else{
	 while($res=  $rs->fetch(PDO::FETCH_ASSOC))
     {
?>		
 <tr>
 <td><?php echo $res['sname']; ?></td>    
<td><?php echo $res['oid']; ?></td>
<td><?php echo $res['flight_id']; ?></td>
<td><?php echo date("d-M-Y", strtotime($res['flight_date'])); ?></td>
<td><?php echo $res['fly_from']; ?></td>
<td><?php echo $res['departure_time']; ?></td>
<td><?php echo $res['fly_to']; ?></td>
<td><?php echo $res['arrival_time']; ?></td>
<td><?php echo $res['name']; ?></td>
<td><?php echo $res['price_class']; ?></td>
<td><?php echo $res['tickets']; ?></td>
<td><i class="fa fa-rupee"></i> <?php echo $res['price']; ?></td>
<td><i class="fa fa-rupee"></i> <?php echo $res['total']; ?></td>
<!--<td>
<a href="<?php echo $my_path; ?>/order-<?php echo $res['oid']; ?>/delete-order.html"  onclick="javascript:return confirm('Do you want Delete This?');"><i class="fa fa-trash"></i> Delete</a>
</td>-->
</tr>
 <?php
	 }
}
}
/*
 *  End bookings
 */

?>