  <div class="widgets resume-teplates">
            <h3>Resume Templates</h3>
           <form name="" method="post" action="<?php echo $my_path; ?>/job-seeker/resume-templates.aspx">
<div class="form-group">                
<div class="col-sm-12">
<label class="control-label" for="address">Profile Type <span class="imp">*</span> </label>

<select class="form-control" id="Domain" name="p_type">
      <option value="">Select Profile Type</option>
      <option value="Fresher">Fresher</option>
      <option value="Experienced">Experienced</option>
</select>
</div>
    <div class="clear"></div>
 </div>   <div class="clear"></div>
                <div class="form-group">
<div class="col-sm-12">
<label class="control-label" for="address">Industry <span class="imp">*</span> </label>

<select class="form-control" id="Domain" name="Domain">
      <option value="">Select Industry</option>
<?php

$sql_dom='SELECT * FROM industry';
$stmt_dom = $db->query($sql_dom);
//$stmt_dom->execute();

if ($stmt_dom->rowCount() > 0){
while($row_dom = $stmt_dom->fetch(PDO::FETCH_ASSOC)){
  //  echo $row_dom['domain_name']; ?>

<option  value="<?php echo $row_dom['id']; ?>"><?php echo $row_dom['name']; ?></option>
<?php
    }
}
    ?>
</select>
</div><div class="clear"></div>
    </div>  
              <div class="form-group">
<div class="col-sm-12">
    <input type="submit" name="submit" value="Get Resumes"  class="btn btn-primary btn-full open2"/>
</div>
              </div>
            <div class="clear"></div>
            </form>
        </div>
        
         <div class="widgets resume-teplates">
            <h3>Content Writers</h3>
            
            <div class="single-profile">
                <div class="avatar">
                    <img alt="" class="img-circle" src="http://lorempixel.com/100/100/people/9/">
                </div>
                 <div class="info">
                    <div class="title">
                        Script Eden
                    </div>
                    <div class="desc">Passionate designer</div>
                    <div class="desc">Curious developer</div>
                    <div class="desc">Tech geek</div>
                      <div class="stars starrr" data-rating="2"></div>
                </div>
                <div class="buttons">
                    <div class="col-sm-6"> <a class="btn btn-primary open2 btn-full"><i class="fa fa-shopping-cart" aria-hidden="true"></i> Order Now</a></div>
                    <div class="col-sm-6"> <a class="btn btn-primary open2 btn-full"><i class="fa fa-text-width" aria-hidden="true"></i> Send Enquiry</a></div>
                      <div class="clear"></div>
                </div>
            </div>
         </div>
