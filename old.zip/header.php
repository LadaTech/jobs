<?php
@session_start();
include "db.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Jatka.in</title>
	
	<!-- core CSS -->
    <link href="<?php echo $my_path; ?>/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo $my_path; ?>/css/font-awesome.min.css" rel="stylesheet">
    <link href="https://necolas.github.io/normalize.css/4.1.1/normalize.css" rel="stylesheet" >
    <link href="<?php echo $my_path; ?>/css/main.css" rel="stylesheet">
    <link href="<?php echo $my_path; ?>/css/responsive.css" rel="stylesheet">
    
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->       
    <link rel="shortcut icon" href="<?php echo $my_path; ?>/images/fav.png">
</head><!--/head-->

<body class="homepage">

    <header id="header">
        <div class="top-bar">
            <div class="container">
                <div class="row">
                    <div class="col-sm-6 col-xs-4">
<!--                         <div class="social">
                            <ul class="social-share">
                                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                <li><a href="#"><i class="fa fa-linkedin"></i></a></li> 
                                <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                                <li><a href="#"><i class="fa fa-skype"></i></a></li>
                            </ul>
                            
                       </div>-->
                    </div>
                    <div class="col-sm-6 col-xs-8">
                        <div class="pull-right">
<?php
if(isset($_SESSION["uid"])){
$stmt = $db->prepare("SELECT * FROM job_seeker where Job_Seeker_Id=$_SESSION[uid]") or die(mysql_error());
$stmt->execute();
if($stmt->rowCount()==1){
$user_info=$stmt->fetch(PDO::FETCH_ASSOC); 
}
else{
$p_a=$my_path."/login.aspx"; // not valid details
header("Location: $p_a"); 
}
?>
 <ul class="account_menu">
     
<li><i class="fa fa-user"></i> Welcome <a href="<?php echo $my_path; ?>/job-seeker/<?php
$clean = iconv('UTF-8', 'ASCII//TRANSLIT', $user_info['First_name']);
$clean = preg_replace("/[^a-zA-Z0-9\/_|+ -]/", '', $clean);
$clean = strtolower(trim($clean, '-'));
$clean = preg_replace("/[\/_|+ -]+/", "-", $clean);
echo $clean;
?>.aspx"> <b><?php echo ucfirst(strtolower($user_info["First_name"])); ?></b></a></li>
<li  class="">
 <div class="dropdown account-menu-dropdown">
     <a href="#" class="dropdown-toggle after_login" data-toggle="dropdown"><i class="fa fa-gear"></i></a>
    <ul class="dropdown-menu">
        <i class="fa fa-sort-up" aria-hidden="true"></i>
        <li><a href="<?php echo $my_path; ?>/job-seeker/dashboard.aspx"><i class="fa fa-home"></i> Dashboard</a></li>
      
    <li>
<a href="<?php echo $my_path; ?>/job-seeker/edit-profile.aspx">
<i class="glyphicon glyphicon-user"></i>
Edit Profile</a>
</li>     
       <li>
<a href="<?php echo $my_path; ?>/change-password.aspx">
<i class="glyphicon glyphicon-lock"></i>
Change Password </a>
</li>
        <li class="li-my-account"><a href="<?php echo $my_path; ?>/logout.aspx"><i class="fa fa-lock"></i> Logout</a></li>
    </ul>
                            </div>  </li>
</ul>
<?php    
}
else{
?>
<a href="<?php echo $my_path; ?>/login.aspx" class="b1">Log In</a>  <a href="<?php echo $my_path; ?>/register.aspx"  class="b2">Register</a>
<?php } ?>                        
                        </div>
                            
                    </div>
                </div>
            </div><!--/.container-->
        </div><!--/.top-bar-->

        <nav class="navbar navbar-inverse" role="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href=" <?php
 if(isset($_SESSION["uid"])){
  ?><?php echo $my_path; ?>/job-seeker/dashboard.aspx<?php   
 } else { ?><?php echo $my_path; }?>"><img src="<?php echo $my_path; ?>/images/logo_new.png" alt="logo"></a>
                </div>
				
                <div class="collapse navbar-collapse navbar-right">
                    <ul class="nav navbar-nav">
 <?php
 if(isset($_SESSION["uid"])){
 ?>
 <li <?php if($page=="dashboard") { ?>class="active" <?php } ?>><a href="<?php echo $my_path; ?>/job-seeker/dashboard.aspx">Dashboard</a></li>
 <li <?php if($page=="resume-templates") { ?>class="active" <?php } ?>><a href="<?php echo $my_path; ?>/job-seeker/resume-templates.aspx">Resume Templates</a></li>
  <li><a href="#">Our Experts</a></li>
   <li><a href="#">My Resumes</a></li>
   <li><a href="#">Notifications (21)</a></li>
<?php                        
 }
 else{
 ?>
 <li class="active"><a href="<?php echo $my_path; ?>">Home</a></li>
 <li><a href="#">About Us</a></li>
 <li><a href="#">Services</a></li>
 <li><a href="#">Portfolio</a></li>
<!--                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Pages <i class="fa fa-angle-down"></i></a>
                            <ul class="dropdown-menu">
                                <li><a href="blog-item.html">Blog Single</a></li>
                               
                            </ul>
                        </li>-->
                        <li><a href="#">Blog</a></li> 
                        <li><a href="#">Contact</a></li>     
 <?php } ?>                        
                    </ul>
                </div>
            </div><!--/.container-->
        </nav><!--/nav-->
		
    </header><!--/header-->