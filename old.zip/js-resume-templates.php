<?php
ob_start();
$page="resume-templates";
include "header.php";

?>
<section class="inner_page_info">
<div class="gmap-area1">

<div class="container">
<div class="row profile">
<div class="col-sm-12">
<h3 class="main-heading">Resume Templates</h3>

<div class="resume-search-form">
   <form name="" method="post" action="<?php echo $my_path; ?>/job-seeker/resume-templates.aspx">
<div class="form-group">                
<div class="col-sm-4">
<label class="control-label" for="address">Profile Type <span class="imp">*</span> </label>

<select class="form-control" id="Domain" name="p_type">
      <option value="">Select Profile Type</option>
      <option value="Fresher" <?php if(isset($_POST["p_type"])) { if($_POST["p_type"]=="Fresher") { echo "selected"; }} ?>>Fresher</option>
      <option value="Experienced" <?php if(isset($_POST["p_type"])) { if($_POST["p_type"]=="Experienced") { echo "selected"; }} ?>>Experienced</option>
</select>
</div>
<div class="col-sm-4">
<label class="control-label" for="address">Domain <span class="imp">*</span> </label>

<select class="form-control" id="Domain" name="Domain">
      <option value="">Select Domain</option>
<?php

$sql_dom='SELECT * FROM js_template_domains';
$stmt_dom = $db->query($sql_dom);
//$stmt_dom->execute();

if ($stmt_dom->fetchColumn() > 0){
while($row_dom = $stmt_dom->fetch(PDO::FETCH_ASSOC)){
   // echo $row_dom['domain_name']; ?>

<option  value="<?php echo $row_dom['domain_id']; ?>" <?php if(isset($_POST["Domain"])) { if($_POST["Domain"]==$row_dom['domain_id']) { echo "selected"; }} ?>> <?php echo $row_dom['domain_name']; ?></option>
<?php
    }
}
    ?>
</select>
</div>    
    <div class="col-sm-4">
    <input type="submit" name="submit" value="Get Resumes"  class="btn btn-primary btn-full open2"/>
</div>
    <div class="clear"></div>
 </div>   <div class="clear"></div>
            </form>
</div>

<div class="row dashboard resumes-wrapper">

    <div class="col-sm-3">
        <a href="http://jathka.in/jobseeker/jobseeker.php?type=res_tem"><img class="thumb template-T1 img-responsive" data-key="T1" src="http://jathka.in/jobseeker/templates/img/templates/T1.png?d19" ></a></a>
    </div>  
     <div class="col-sm-3">
        <a href="http://jathka.in/jobseeker/jobseeker.php?type=res_tem"><img class="thumb template-T1 img-responsive" data-key="T1" src="http://jathka.in/jobseeker/templates/img/templates/T2.png?d19" ></a>
    </div>  
     <div class="col-sm-3">
        <a href="http://jathka.in/jobseeker/jobseeker.php?type=res_tem"><img class="thumb template-T1 img-responsive" data-key="T1" src="http://jathka.in/jobseeker/templates/img/templates/T3.png?d19" ></a>
    </div>  
     <div class="col-sm-3">
        <a href="http://jathka.in/jobseeker/jobseeker.php?type=res_tem"><img class="thumb template-T1 img-responsive" data-key="T1" src="http://jathka.in/jobseeker/templates/img/templates/T4.png?d19" >
    </div>  
    
     <div class="col-sm-3">
        <a href="http://jathka.in/jobseeker/jobseeker.php?type=res_tem"><img class="thumb template-T1 img-responsive" data-key="T1" src="http://jathka.in/jobseeker/templates/img/templates/T5.png?d19" ></a>
    </div>  
    
     <div class="col-sm-3">
        <a href="http://jathka.in/jobseeker/jobseeker.php?type=res_tem"><img class="thumb template-T1 img-responsive" data-key="T1" src="http://jathka.in/jobseeker/templates/img/templates/T6.png?d19" ></a>
    </div>  
    
     <div class="col-sm-3">
       <a href="http://jathka.in/jobseeker/jobseeker.php?type=res_tem"> <img class="thumb template-T1 img-responsive" data-key="T1" src="http://jathka.in/jobseeker/templates/img/templates/T7.png?d19" ></a>
    </div>  
    
     <div class="col-sm-3">
       <a href="http://jathka.in/jobseeker/jobseeker.php?type=res_tem"> <img class="thumb template-T1 img-responsive" data-key="T1" src="http://jathka.in/jobseeker/templates/img/templates/T8.png?d19" ></a>
    </div>  
<div class="">

</div>

</div>





</div>


</div>
</div>
</div>
</section>  <!--/gmap_area -->

<?php
include "footer.php";
?>