<?php
$my_path="http://jatka.in";
$path="http://jatka.in/";
$DB_host = "localhost";
$compnay_name="Jatka.in";
$DB_user = "nagendra_jin";
$DB_pass = "nagendra@ipl";
$DB_name = "nagendra";
try
{
	$db = new PDO("mysql:host={$DB_host};dbname={$DB_name}",$DB_user,$DB_pass);
	$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch(PDOException $e)
{
	echo $e->getMessage();
}
?>
