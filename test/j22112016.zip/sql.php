<?php
include ("db.php");
$sql_dom="ALTER TABLE `invitations` ADD `cwread` INT(10) NOT NULL ;";
$stmt_dom = $db->query($sql_dom);
?>

ALTER TABLE `cw_payment_info` ADD `did` INT(10) NOT NULL AFTER `iid`;

ALTER TABLE `cw_payment_info` ADD `expected_special_delivery` VARCHAR(10) NOT NULL , ADD `expected_delivery` VARCHAR(10) NOT NULL ;


ALTER TABLE `templates` ADD `did` INT(10) NOT NULL ;
