<?php
include ("db.php");
$sql_dom="ALTER TABLE `invitations` ADD `cwread` INT(10) NOT NULL ;";
$stmt_dom = $db->query($sql_dom);
?>
ALTER TABLE `chat_info` ADD `del` INT(10) NOT NULL AFTER `jsread`;

ALTER TABLE `js_skills` ADD `skill_title` TEXT NOT NULL AFTER `updated_time`;