</div><!-- /.content-wrapper -->
      <footer class="main-footer">
        
        <strong>Copyright &copy; <?php echo date("Y"); ?> <a href="<?php echo $company_url; ?> " target='_blank'><?php echo $compnay_name; ?>  </a></strong> All rights reserved.
      </footer>
      
     
      <!-- Add the sidebar's background. This div must be placed
           immediately after the control sidebar -->
     
    </div><!-- ./wrapper -->

    <!-- jQuery 2.1.4 -->
    <script src="js/jQuery-2.1.4.min.js"></script>
	
	<script src='js/script.js'></script>
    <!-- jQuery UI 1.11.2 -->
    <script src="js/jquery-ui.min.js" type="text/javascript"></script>
    <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
    <script>
      $.widget.bridge('uibutton', $.ui.button);
    </script>
      <script type="text/javascript" src="js/summernote.js"></script>
    <!-- Bootstrap 3.3.2 JS -->
    <script src="js/bootstrap.min.js" type="text/javascript"></script>    
   
    
   
    <!-- jvectormap -->
    <script src="js/jquery-jvectormap-1.2.2.min.js" type="text/javascript"></script>
    <script src="js/jquery-jvectormap-world-mill-en.js" type="text/javascript"></script>
    <!-- jQuery Knob Chart -->
    <script src="js/jquery.knob.js" type="text/javascript"></script>
   
     <script type="text/javascript" src="js/summernote.js"></script>
    <!-- Slimscroll -->
    <script src="js/jquery.slimscroll.min.js" type="text/javascript"></script>
    <!-- FastClick -->
    <script src='js/fastclick.min.js'></script>
	
    <!-- AdminLTE App -->
    <script src="js/app.min.js" type="text/javascript"></script>    
    
   
    
    <!-- AdminLTE for demo purposes -->
    <script src="js/demo.js" type="text/javascript"></script>
  </body>
</html>